"""Anlam kontrolü (ikinci tur): model kaynakla çeviriyi yan yana okur ve yalnızca anlamı yanlış
ya da Türkçesi bozuk satırları düzeltilmiş hâliyle geri verir.

Kural yazarak "anlam yanlış" tespit edilemez ("my pocket" -> "cebinde", "未婚" -> "evli");
bunları ancak ikinci bir okuma yakalar. Düzeltmeler Python'da denetlenir: hitap eki, yer tutucu,
biçim etiketi, Elfçe/isim gibi aynen kopyalanmış satırlar korunmuyorsa düzeltme atılır.
"""
from __future__ import annotations

import difflib
import json
import re

from .textprep import (Prepared, TAG_RE, check_translation, count_tags, has_letters, honorifics_in_output,
                       honorifics_in_source, norm_line, normalize_model_text, similar_meaning, visible_len)
from .prompts import REVIEW_SYSTEM  # noqa: F401  (metinler prompts.py'de)

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "fixes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"id": {"type": "integer"}, "text": {"type": "string"},
                               "problem": {"type": "string"},
                               "certainty": {"type": "string", "enum": ["certain", "unsure"]}},
                "required": ["id", "text", "problem", "certainty"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["fixes"],
    "additionalProperties": False,
}

def review_payload(check: list[dict], before: list[dict], after: list[dict],
                   glossary: dict[str, str] | None, scene: list | str = "") -> str:
    payload: dict = {}
    if scene:
        payload["scenes"] = scene
    if glossary:
        payload["glossary"] = glossary
    if before:
        payload["context_before"] = before
    payload["check"] = check
    if after:
        payload["context_after"] = after
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _copied_lines(src_text: str, translation: str) -> set[str]:
    """Çeviride kaynaktan harfi harfine kopyalanmış satırlar (Elfçe, isim, "Gandalf!" gibi)."""
    src_keys = {norm_line(x) for x in src_text.split("\n")}
    out = set()
    for ln in translation.split("\n"):
        k = norm_line(ln)
        if k and len(k) >= 3 and k in src_keys and has_letters(k):
            out.add(k)
    return out


# Latin dışı yazı sistemleri (Japonca, Çince, Korece, Kiril, Arap, İbrani, Yunan, Tay)
_NON_LATIN_RE = re.compile(r"[\u0370-\u03FF\u0400-\u04FF\u0590-\u05FF\u0600-\u06FF\u0E00-\u0E7F"
                           r"\u3040-\u30FF\u3400-\u9FFF\uAC00-\uD7AF\uFF66-\uFF9F]")


def _name_in(name: str, text: str) -> bool:
    """Ad metinde geçiyor mu? Büyük/küçük harfe duyarlı; son sözcükte Türkçe ek ve ünsüz
    yumuşamasına izin verir (Desmond'ın, Tek Yüzüğü, Ulusal Birlik Partisi'nin)."""
    words = name.split()
    if not words:
        return False
    last = words[-1]
    stem = last if len(last) < 5 else last[:max(4, len(last) - 2)]
    pat = r"\s+".join([re.escape(w) for w in words[:-1]] + [re.escape(stem)])
    return re.search(r"(?<!\w)" + pat, text) is not None or re.search(r"(?<!\w)" + pat.upper(), text) is not None


def _same_content(a: str, b: str) -> bool:
    return similar_meaning(TAG_RE.sub("", a), TAG_RE.sub("", b))


_END_RE = re.compile(r"[.!?。！？\"”»’)）♪]\s*$")


def is_fragment(text: str, next_text: str = "") -> bool:
    """Kaynak satırın cümlesi bir sonraki altyazıda devam ediyor mu?
    ("which is to attend" / "the reception where..." ya da "任務が…")
    Satırın "..." ile BAŞLAMASI yalnızca öncekinin devamı olduğunu gösterir, sonrakiyle ilgisi yoktur
    ("...the great realm of Dwarrowdelf." / "Now there's an eye opener." ayrı cümlelerdir)."""
    plain = TAG_RE.sub("", text).strip()
    nxt = TAG_RE.sub("", next_text).strip()
    if not plain:
        return False
    if plain.endswith(("...", "…", "—", "–", "-", ",")):
        return True
    if nxt.startswith(("...", "…")):
        return True
    if not re.search(r"[A-Za-z]", plain):           # Japonca vb.: noktalama kullanılmaz
        return False
    return not _END_RE.search(plain) or (nxt[:1].islower() and nxt[:1].isalpha())


REASON_NEIGHBOR = "komşu satırın içeriğini taşımış (bölünmüş cümle)"
REASON_REWRITE = "bölünmüş cümlede satırı baştan yazmış"
SPLIT_REASONS = (REASON_NEIGHBOR, REASON_REWRITE)


def _repeated_pairs(text: str) -> set[tuple[str, str]]:
    """Metinde iki kez geçen ardışık sözcük çiftleri (sözcük kökü = ilk 5 harf, ekler sayılmaz)."""
    words = [w[:5] for w in re.findall(r"[^\W\d_]+", TAG_RE.sub("", text).casefold().replace("'", ""))]
    pairs = list(zip(words, words[1:]))
    return {p for p in pairs if pairs.count(p) > 1}


def validate_fix(src: Prepared, original: str, fix: str, names: set[str] | None,
                 neighbors: tuple[str, ...] = (), keep_terms: tuple[str, ...] = (),
                 fragment: bool = False) -> tuple[str | None, str]:
    """(kabul edilen metin ya da None, red sebebi).
    neighbors: önceki/sonraki blokların çevirisi (bölünmüş cümlede kelime taşıma kontrolü için).
    keep_terms: özgün çeviride geçen ve düzeltmede de kalması gereken yazımlar (sözlük adları)."""
    fix = normalize_model_text(fix).strip()
    fix = "\n".join(ln.strip() for ln in fix.split("\n") if ln.strip())
    if not fix:
        return None, "boş"
    if fix == original.strip():
        return None, "değişiklik yok"
    if _NON_LATIN_RE.search(fix) and not _NON_LATIN_RE.search(original):
        return None, "kaynak dilin harfleri var"
    if norm_line(fix) == norm_line(src.send_text) and norm_line(original) != norm_line(src.send_text):
        return None, "kaynak metni kopyalamış"
    for n in neighbors:
        if n and _same_content(fix, n) and not _same_content(original, n):
            return None, REASON_NEIGHBOR
    if fragment and difflib.SequenceMatcher(None, original, fix).ratio() < 0.6:
        # Bölünmüş cümlede çevirmen kelimeleri satırlar arasında taşıyabilir; burada yalnızca
        # küçük düzeltmeler (yazım, ek, tek sözcük) alınır, satırı baştan yazan düzeltme alınmaz.
        return None, REASON_REWRITE
    if _repeated_pairs(fix) - _repeated_pairs(original):
        # "...Cüce Şehri'nin görkemli diyarı ve cüce şehri." gibi aynı ifadeyi ikinci kez ekleyen düzeltme
        return None, "aynı ifadeyi satırda iki kez yazmış"
    for t in keep_terms:
        if _name_in(t, original) and not _name_in(t, fix):
            return None, f"çevirideki ad düşmüş: {t}"
    hard, _ = check_translation(src, fix, names)
    if hard:
        return None, "; ".join(hard)
    want = honorifics_in_source(src.send_text, names)
    if want and honorifics_in_output(fix) < len(want):
        return None, "hitap eki düşmüş"
    if count_tags(fix) != count_tags(original):
        return None, "biçim etiketi değişmiş"
    fix_keys = {norm_line(x) for x in fix.split("\n")}
    lost = _copied_lines(src.send_text, original) - fix_keys
    if lost:
        return None, f"aynen kalması gereken satır değişmiş: {sorted(lost)[:2]}"
    if visible_len(TAG_RE.sub("", fix)) > 2 * visible_len(TAG_RE.sub("", original)) + 30:
        return None, "çok uzun"
    return fix, ""
