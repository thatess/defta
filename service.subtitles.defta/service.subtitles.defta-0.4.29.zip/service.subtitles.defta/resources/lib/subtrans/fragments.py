"""Kısa, fiilsiz repliklerin ("Common gods.", "Same blood.") ayrı ve dar kontrolü.

Düşünmeden çeviren model bu satırlarda çok anlamlı kelimeyi sık geçen anlamıyla okuyabiliyor
("Common gods." -> "Sıradan tanrılar"). Bu tur yalnızca o satırları, komşu satırları ve sahne özetiyle
birlikte, kısa düşünen bir sağlayıcıya sorar; model önce satırın ne demek istediğini yazar ("means"),
taslak bunu söylemiyorsa düzeltir. Yalnızca anlam hataları değişir; uzun satırlara dokunulmaz."""
from __future__ import annotations

import asyncio
import json
import logging

from .common import FatalError
from .config import lang_name
from .provider import ProviderError
from .review import validate_fix
from .textprep import is_verbless_line

log = logging.getLogger("subtrans")

FRAGMENT_SYSTEM = """You check short subtitle lines (fragments without a verb) translated from {src} into {tgt}.
Each item has the source line "text", its {tgt} draft "draft", the nearby lines ("before" / "after": source and their {tgt} translation) and the "scene" summary.
For each item:
1. "means": in English, at most 15 words: what the speaker is saying in this exchange (who or whose is implied, which sense of each ambiguous word fits the scene).
2. "verdict": "ok" if the draft says that; "fix" if the draft takes a word in the wrong sense or misses what the line means here.
3. "text": for "fix", a short natural {tgt} line with that meaning; a short full sentence is fine ('Same blood.' given as a reason -> 'Aynı kandanız.'). For "ok", repeat the draft exactly.
"fix" ONLY when the draft reads a word in a sense that is wrong for this scene, or says something false about who or whose. Everything else is "ok": a free but correct rendering, a draft that adds the implied verb or person, a shorter or longer wording.
In a fix never: add facts or words taken from the neighbouring lines, change who is spoken to or who speaks (you / we / I), drop part of the meaning, or restyle. Keep names, tags and placeholders exactly as in the draft.
Return JSON: {{"items": [{{"id": <number>, "means": "...", "verdict": "ok" | "fix", "text": "..."}}]}} with one item for every input item."""

FRAGMENT_SCHEMA = {
    "type": "object",
    "properties": {"items": {"type": "array", "items": {
        "type": "object",
        "properties": {"id": {"type": "integer"}, "means": {"type": "string"},
                       "verdict": {"type": "string", "enum": ["ok", "fix"]}, "text": {"type": "string"}},
        "required": ["id", "means", "verdict", "text"], "additionalProperties": False}}},
    "required": ["items"],
    "additionalProperties": False,
}

GROUP = 20          # istek başına satır


class FragmentMixin:
    fragment_provider = None

    def _fragment_targets(self, job) -> list[int]:
        if not job.src_lang.lower().startswith("en"):
            return []
        out = []
        for i in job.translate_pos:
            p = job.prepared[i]
            if p.passthrough or p.romanize or p.romanize_both or p.song or not job.results.get(i):
                continue
            if not is_verbless_line(p.send_text) or len(p.send_text.split()) > 3:
                continue
            # Bölünmüş cümlenin parçası değil: önceki satır cümleyi bitirmiş, sonraki büyük harfle başlıyor
            prev = job.prepared[i - 1].send_text.strip() if i > 0 else "."
            nxt = job.prepared[i + 1].send_text.strip() if i + 1 < len(job.prepared) else "A"
            if not prev.endswith((".", "!", "?", "\u2026", '"')) or (nxt[:1].islower()):
                continue
            out.append(i)
        return out

    def _fragment_item(self, job, i: int) -> dict:
        n = len(job.prepared)

        def ctx(k: int) -> dict:
            d = {"text": job.prepared[k].send_text}
            if job.results.get(k):
                d["translation"] = job.results[k]
            return d
        d = {"id": i + 1, "text": job.prepared[i].send_text, "draft": job.results[i],
             "before": [ctx(k) for k in range(max(0, i - 4), i)],
             "after": [ctx(k) for k in range(i + 1, min(n, i + 3))]}
        for sc in (job.analysis or {}).get("scenes") or []:
            if sc["from"] <= i + 1 <= sc["to"]:
                d["scene"] = sc["summary"]
                break
        return d

    async def _fragment_pass(self, job) -> None:
        prov = self.fragment_provider
        if prov is None or not job.results:
            return
        targets = self._fragment_targets(job)
        if not targets:
            return
        system = FRAGMENT_SYSTEM.format(src=lang_name(job.src_lang), tgt=lang_name(self.s["language"]["target"]))
        groups = [targets[k:k + GROUP] for k in range(0, len(targets), GROUP)]
        names = self._names(job)
        fixed = 0

        async def run(group: list[int]) -> None:
            nonlocal fixed
            user = json.dumps({"items": [self._fragment_item(job, i) for i in group]}, ensure_ascii=False,
                              separators=(",", ":"))
            data = None
            for attempt in range(3):
                try:
                    async with self.limiter:
                        data, usage = await prov.complete_json(system, user, 300 + 120 * len(group),
                                                               schema=FRAGMENT_SCHEMA, schema_name="fragment_check")
                    job.usage.add(usage)
                    await self.limiter.on_success()
                    break
                except ProviderError as e:
                    if e.kind == "fatal":
                        log.warning("Kısa replik kontrolü yapılamadı (%s); atlandı.", e)
                        return
                    if e.kind == "rate_limit":
                        await self.limiter.on_rate_limit()
                    await asyncio.sleep((1.5 ** attempt) * self.backoff_scale)
            items = data.get("items") if isinstance(data, dict) else None
            if not isinstance(items, list):
                return
            want = {i + 1: i for i in group}
            for it in items:
                if not isinstance(it, dict) or it.get("verdict") != "fix":
                    continue
                try:
                    pos = want.get(int(it.get("id")))
                except (TypeError, ValueError):
                    continue
                if pos is None:
                    continue
                orig = job.results[pos]
                ok, why = validate_fix(job.prepared[pos], orig, str(it.get("text") or ""), names)
                if ok is None:
                    log.debug("%s blok %d: kısa replik önerisi alınmadı (%s): %r", job.rel, pos + 1, why, it.get("text"))
                    continue
                log.debug("%s blok %d: kısa replik düzeltildi (%s): %r -> %r", job.rel, pos + 1,
                          it.get("means", ""), orig, ok)
                job.results[pos] = ok
                fixed += 1

        try:
            await asyncio.gather(*(run(g) for g in groups))
        except FatalError:
            raise
        log.debug("%s: kısa replik kontrolü: %d satır, %d düzeltme", job.rel, len(targets), fixed)
