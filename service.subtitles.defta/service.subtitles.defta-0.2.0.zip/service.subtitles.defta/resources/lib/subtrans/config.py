"""Ayar dosyası (config.toml) ve dil kural paketlerinin yüklenmesi."""
from __future__ import annotations

import copy
import os
try:
    import tomllib
except ImportError:  # Python < 3.11 (Kodi): kural paketleri JSON'dan okunur
    tomllib = None
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "paths": {"source": "kaynak", "target": "ceviri", "recursive": True, "logs": "logs"},
    "language": {"target": "tr", "source": "auto", "established_names": "ask"},
    "provider": {
        "type": "openai_compatible",
        "base_url": "https://api.openai.com/v1",
        "model": "gpt-6-luna",
        "api_key_env": "OPENAI_API_KEY",
        "reasoning_effort": "none",
        "temperature": None,
        "timeout_seconds": 120,
        "max_output_tokens": 128000,
        "max_tokens_param": "max_completion_tokens",
        "review_base_url": "",
        "review_api_key_env": "",
        "prompt_cache": "auto",
        "batch": False,
    },
    "run": {"mode": "translate", "confirm_cost": True, "time_shift_seconds": 0.0, "cache": True},
    "chunking": {
        "chunk_size": "auto",
        "chunk_mode": "flexible",
        "context_before": "auto",
        "context_after": "auto",
        "chunk_order": "parallel",
        "parallel": "auto",
        "scene_gap_seconds": 2.0,
    },
    "sdh": {"sound_notes": "ask", "speaker_labels": "ask", "speaker_dashes": "ask", "lyrics": "ask",
            "note_only_blocks": "delete"},
    "output": {"bom": False, "log_level": "info", "progress": "detailed", "position_codes": "remove",
               "credit": "", "format": "srt", "suspect_report": True},
    "glossary": {"enabled": True, "folder": "sozlukler", "series": "auto"},
    "conlang": {"display": "original+translation"},
    "quality": {"review": True, "review_model": "", "review_reasoning_effort": "", "episode_analysis": True},
    "retry": {"max_api_retries": 6, "max_validation_attempts": 3},
    "prices": {},
}


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


@dataclass
class Settings:
    raw: dict[str, Any]
    base_dir: Path

    def __getitem__(self, section: str) -> dict[str, Any]:
        return self.raw[section]

    def path(self, key: str) -> Path:
        p = Path(self.raw["paths"][key]).expanduser()
        return p if p.is_absolute() else (self.base_dir / p)

    def price(self, model: str) -> dict[str, float] | None:
        return self.raw.get("prices", {}).get(model)

    def is_auto(self, section: str, key: str) -> bool:
        return str(self.raw[section][key]).lower() == "auto"


def load_settings(config_path: Path, overrides: dict[str, dict[str, Any]] | None = None) -> Settings:
    data: dict[str, Any] = {}
    if config_path.exists():
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    raw = _merge(DEFAULTS, data)
    if overrides:
        raw = _merge(raw, {s: {k: v for k, v in d.items() if v is not None}
                           for s, d in overrides.items()})
    return Settings(raw=raw, base_dir=config_path.resolve().parent)


# Hangi ortam değişkeni nereden geldi (".env" / "sistem")
ENV_SOURCES: dict[str, str] = {}
DOTENV_NOTES: list[str] = []


def load_dotenv(path: Path) -> None:
    """Basit .env okuyucu (KEY=VALUE).

    .env dosyasındaki değer, Windows'ta daha önce tanımlanmış aynı adlı ortam
    değişkeninin önüne geçer (eski bir anahtar yanlışlıkla kullanılmasın diye).
    """
    for k in os.environ:
        ENV_SOURCES.setdefault(k, "sistem ortam değişkeni")
    if not path.exists():
        for alt in (path.with_name(".env.txt"), path.with_name("env"), path.with_name("env.txt")):
            if alt.exists():
                DOTENV_NOTES.append(f"'{alt.name}' bulundu ama okunmadı: dosyanın adı tam olarak '.env' olmalı "
                                    "(Windows uzantıyı gizlemiş olabilir).")
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        if k.startswith("export "):
            k = k[len("export "):].strip()
        v = v.strip().strip('"').strip("'").strip()
        if not k:
            continue
        if k in os.environ and os.environ[k] != v and ENV_SOURCES.get(k) == "sistem ortam değişkeni":
            DOTENV_NOTES.append(f"{k} hem sistemde hem .env'de tanımlı; .env'deki kullanılıyor.")
        os.environ[k] = v
        ENV_SOURCES[k] = ".env dosyası"


def describe_key(env_name: str) -> str:
    """Anahtarı göstermeden teşhis bilgisi verir: baş/son karakterler, uzunluk, kaynak."""
    key = os.environ.get(env_name, "")
    if not key:
        return f"{env_name} tanımlı değil"
    masked = f"{key[:8]}…{key[-4:]}" if len(key) > 14 else "(çok kısa)"
    issues = []
    if any(ch.isspace() for ch in key):
        issues.append("içinde boşluk var")
    if not key.startswith("sk-"):
        issues.append("'sk-' ile başlamıyor")
    if len(key) < 40:
        issues.append("normalden çok kısa, eksik kopyalanmış olabilir")
    if any(ord(ch) > 127 for ch in key):
        issues.append("Türkçe/özel karakter içeriyor")
    src = ENV_SOURCES.get(env_name, "bilinmiyor")
    out = f"kullanılan anahtar {masked}, {len(key)} karakter, kaynak: {src}"
    if issues:
        out += " — " + ", ".join(issues)
    return out


# ------------------------------------------------------------------ dil kural paketleri

RULES_DIR = Path(__file__).resolve().parent.parent / "rules"

LANG_NAMES = {
    "tr": "Turkish", "en": "English", "ja": "Japanese", "de": "German", "fr": "French",
    "es": "Spanish", "it": "Italian", "pt": "Portuguese", "ru": "Russian", "ar": "Arabic",
    "zh-cn": "Chinese (Simplified)", "zh-tw": "Chinese (Traditional)", "zh": "Chinese",
    "ko": "Korean", "nl": "Dutch", "pl": "Polish", "sv": "Swedish", "uk": "Ukrainian",
    "el": "Greek", "he": "Hebrew", "fa": "Persian", "hi": "Hindi", "id": "Indonesian",
    "th": "Thai", "vi": "Vietnamese", "cs": "Czech", "hu": "Hungarian", "ro": "Romanian",
    "da": "Danish", "no": "Norwegian", "fi": "Finnish",
}


def lang_name(code: str) -> str:
    return LANG_NAMES.get(code.lower(), code)


CREDIT_LABELS = {
    "tr": "Altyazı çevirisi", "en": "Subtitles by", "de": "Untertitel", "fr": "Sous-titres",
    "es": "Subtítulos", "it": "Sottotitoli", "pt": "Legendas", "nl": "Ondertiteling",
    "ru": "Субтитры", "ja": "字幕翻訳", "ko": "자막", "zh": "字幕", "ar": "ترجمة",
}


def credit_label(code: str) -> str:
    return CREDIT_LABELS.get(code.lower(), CREDIT_LABELS.get(code.lower().split("-")[0], "Subtitles by"))


@dataclass
class RulePack:
    code: str
    name: str
    max_line_length: int
    max_lines: int
    token_expansion: float
    instructions: str
    is_default: bool
    credit_label: str = ""
    lowercase_races: bool = False


def load_rule_pack(code: str) -> RulePack:
    # Masaüstü: .toml. Kodi eklentisi: paketlerken üretilen .json (eski Python'da tomllib yok)
    ext = ".toml" if tomllib is not None and (RULES_DIR / "default.toml").exists() else ".json"
    path = RULES_DIR / f"{code.lower()}{ext}"
    is_default = not path.exists()
    if is_default:
        path = RULES_DIR / f"default{ext}"
    if ext == ".toml":
        with open(path, "rb") as f:
            d = tomllib.load(f)
    else:
        d = json.loads(path.read_text(encoding="utf-8"))
    return RulePack(
        code=code.lower(),
        name=d.get("name", lang_name(code)) if not is_default else lang_name(code),
        max_line_length=int(d.get("max_line_length", 42)),
        max_lines=int(d.get("max_lines", 2)),
        token_expansion=float(d.get("token_expansion", 1.5)),
        instructions=d.get("instructions", "").strip(),
        is_default=is_default,
        credit_label=str(d.get("credit_label", "")).strip() if not is_default else "",
        lowercase_races=bool(d.get("lowercase_races", False)),
    )
