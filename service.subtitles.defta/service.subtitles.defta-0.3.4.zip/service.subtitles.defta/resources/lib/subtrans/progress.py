"""Canlı ilerleme: terminalin altında güncellenen ilerleme çubuğu ve parça olayları.

Konsol:  → gönderilen parça, ← gelen parça, ! yeniden deneme / bölme
Alt satır: [██████░░░░] %54 | 371/712 blok | parça 9/16 (yolda 4) | 18.2K token $0.003 | 0:07 kalan ~0:06
Log dosyasına her olay, konsol ayarından bağımsız olarak yazılır.
"""
from __future__ import annotations

import logging
import shutil
import sys
import time

from .tokens import fmt_cost, fmt_tokens

log = logging.getLogger("subtrans")


def fmt_clock(s: float) -> str:
    s = max(0, int(round(s)))
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


class ProgressConsoleHandler(logging.StreamHandler):
    """Log satırı yazmadan önce ilerleme çubuğunu siler, sonra yeniden çizer."""

    progress: "Progress | None" = None

    def emit(self, record):
        p = self.progress
        if p is not None and p.bar_on:
            try:
                self.stream.write("\r\033[K")
            except Exception:
                pass
        super().emit(record)
        if p is not None and p.bar_on:
            p.redraw()


class Progress:
    def __init__(self, mode: str, price: dict | None):
        self.mode = mode if mode in ("detailed", "bar", "off") else "detailed"
        self.price = price
        self.bar_on = False
        self.interactive = sys.stdout.isatty()
        self.total_blocks = self.done_blocks = 0
        self.total_chunks = self.done_chunks = 0
        self.inflight = self.retries = self.splits = 0
        self.review_total = self.review_done_n = 0
        self.in_tokens = self.out_tokens = self.cached_tokens = 0
        self.t0 = time.monotonic()
        self.limiter = None
        self._last_plain = 0.0

    # ------------------------------------------------------------ yaşam döngüsü

    def begin(self, jobs, limiter=None) -> None:
        self.total_blocks = sum(len(j.translate_pos) for j in jobs)
        self.total_chunks = sum(len(j.chunks) for j in jobs)
        self.limiter = limiter
        self.t0 = time.monotonic()
        self.bar_on = self.mode != "off" and self.interactive
        self.redraw()

    def finish(self) -> None:
        if self.bar_on:
            sys.stdout.write("\r\033[K" + self._bar_text() + "\n")
            sys.stdout.flush()
        self.bar_on = False
        log.debug("İlerleme son durum: %s", self._bar_text(plain=True))

    # ------------------------------------------------------------ olaylar

    def _event(self, msg: str) -> None:
        if self.mode == "detailed":
            log.info(msg)
        else:
            log.debug(msg)

    @staticmethod
    def _name(job) -> str:
        n = job.rel.name
        return n if len(n) <= 34 else n[:15] + "…" + n[-18:]

    @staticmethod
    def _range(job, c) -> str:
        a = job.srt.blocks[c.targets[0]].index
        b = job.srt.blocks[c.targets[-1]].index
        return f"blok {a}–{b} ({len(c.targets)})"

    def _cl(self, job, c) -> str:
        return f"parça {c.number}{c.part}/{len(job.chunks)}"

    def sent(self, job, c, attempt: int) -> None:
        self.inflight += 1
        extra = f" · {attempt}. deneme" if attempt > 1 else ""
        self._event(f"  → {self._name(job)} {self._cl(job, c)} gönderildi · {self._range(job, c)}{extra}")
        self.redraw()

    def received(self, job, c, secs: float, usage=None, error: str = "") -> None:
        self.inflight = max(0, self.inflight - 1)
        if usage is not None:
            self.in_tokens += usage.input_tokens
            self.out_tokens += usage.output_tokens
            self.cached_tokens += usage.cached_input_tokens
        if error:
            self._event(f"  ✗ {self._name(job)} {self._cl(job, c)} hata · {secs:.1f} sn · {error[:120]}")
        else:
            tok = (usage.input_tokens + usage.output_tokens) if usage else 0
            self._event(f"  ← {self._name(job)} {self._cl(job, c)} geldi · {secs:.1f} sn · {fmt_tokens(tok)} token")
        self.redraw()

    def chunk_ok(self, job, c) -> None:
        self.done_blocks += len(c.targets)
        self.done_chunks += 1
        self.redraw()

    def retry(self, job, c, reason: str) -> None:
        self.retries += 1
        self._event(f"  ! {self._name(job)} {self._cl(job, c)} doğrulanamadı, yeniden deneniyor: {reason[:120]}")

    def split(self, job, c) -> None:
        self.splits += 1
        self.total_chunks += 1  # bir parça ikiye bölündü
        self._event(f"  ! {self._name(job)} {self._cl(job, c)} ikiye bölünüp tekrar deneniyor")

    def review_begin(self, job, n_chunks: int) -> None:
        if self.review_total == 0:
            self._event("  ▶ anlam kontrolü başladı")
        self.review_total += n_chunks
        self.redraw()

    def review_done(self, job, c) -> None:
        self.review_done_n += 1
        if self.review_done_n == self.review_total:
            self._event(f"  ✓ anlam kontrolü bitti ({self.review_total} parça)")
        self.redraw()

    def note(self, msg: str) -> None:
        self._event(msg)

    # ------------------------------------------------------------ çizim

    def _bar_text(self, plain: bool = False) -> str:
        total = max(1, self.total_blocks)
        frac = min(1.0, self.done_blocks / total)
        elapsed = time.monotonic() - self.t0
        eta = ""
        if 0 < self.done_blocks < self.total_blocks:
            eta = f" kalan ~{fmt_clock(elapsed / self.done_blocks * (self.total_blocks - self.done_blocks))}"
        cost = ""
        if self.price:
            from .provider import Usage
            c = Usage(input_tokens=self.in_tokens, cached_input_tokens=self.cached_tokens,
                      output_tokens=self.out_tokens).cost(self.price)
            cost = f" {fmt_cost(c)}"
        lim = f" eşzamanlı {self.limiter.limit}" if self.limiter is not None else ""
        width = 20
        filled = int(round(frac * width))
        bar = "█" * filled + "░" * (width - filled)
        parts = [
            f"[{bar}] %{frac * 100:3.0f}",
            f"{self.done_blocks}/{self.total_blocks} blok",
            f"parça {self.done_chunks}/{self.total_chunks} (yolda {self.inflight}{lim})",
            f"{fmt_tokens(self.in_tokens + self.out_tokens)} token{cost}",
            f"{fmt_clock(elapsed)}{eta}",
        ]
        if self.retries:
            parts.insert(3, f"tekrar {self.retries}")
        if self.review_total:
            parts.insert(3, f"kontrol {self.review_done_n}/{self.review_total}")
        text = " | ".join(parts)
        if not plain:
            cols = shutil.get_terminal_size((120, 20)).columns
            if len(text) > cols - 1:
                text = text[: cols - 2] + "…"
        return text

    def redraw(self) -> None:
        if self.bar_on:
            sys.stdout.write("\r\033[K" + self._bar_text())
            sys.stdout.flush()
        elif self.mode != "off" and not self.interactive:
            # Terminal değilse (örn. çıktı dosyaya yönlendirildi) 10 sn'de bir düz satır
            now = time.monotonic()
            if now - self._last_plain >= 10:
                self._last_plain = now
                log.info("İlerleme: %s", self._bar_text(plain=True))
