"""Kaynak dil tespiti (LLM kullanılmaz)."""
from __future__ import annotations

import re

from .srt_io import Block

_STRIP_RE = re.compile(r"<[^>]+>|\{[^}]*\}|\[[^\]]*\]|\([^)]*\)|♪|#")


def detect_language(blocks: list[Block]) -> tuple[str, float]:
    """(dil kodu, olasılık) döndürür. Tespit edilemezse ("unknown", 0)."""
    try:
        from langdetect import DetectorFactory, detect_langs
    except ImportError:
        return "unknown", 0.0
    DetectorFactory.seed = 0  # her çalıştırmada aynı sonuç
    sample = " ".join(_STRIP_RE.sub(" ", b.text) for b in blocks[:400])
    sample = re.sub(r"\s+", " ", sample).strip()
    if len(sample) < 20:
        return "unknown", 0.0
    try:
        best = detect_langs(sample[:20000])[0]
        return best.lang, float(best.prob)
    except Exception:
        return "unknown", 0.0
