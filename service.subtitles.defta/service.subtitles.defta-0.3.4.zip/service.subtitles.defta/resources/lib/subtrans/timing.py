"""Zaman kaydırma. LLM'den tamamen bağımsız, deterministik."""
from __future__ import annotations

from .srt_io import Block


def shift_blocks(blocks: list[Block], seconds: float) -> tuple[list[Block], list[int]]:
    """Tüm blokları aynı miktarda kaydırır. Sıfırın altına düşen zamanlar 0'a kırpılır.

    (yeni bloklar, kırpılan blokların numaraları) döndürür.
    """
    delta = round(seconds * 1000)
    out, clipped = [], []
    for b in blocks:
        s, e = b.start_ms + delta, b.end_ms + delta
        if s < 0 or e < 0:
            clipped.append(b.index)
        out.append(Block(pos=b.pos, index=b.index, start_ms=max(0, s), end_ms=max(0, e),
                         text=b.text, tail=b.tail))
    return out, clipped
