"""Komut satırı uygulaması: dosyaları tara, sor, tahmin et, çevir, doğrula, yaz, özetle."""
from __future__ import annotations

import argparse
import json
import asyncio
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from .config import Settings, lang_name, load_dotenv, load_rule_pack, load_settings
from .engine import Engine, FatalError, FileJob
from .glossary import Glossary, english_vocab, series_from_path, similar, slugify
from .provider import Usage, make_provider, ProviderError
from .srt_io import output_name, verify_structure
from .subformats import SUPPORTED_EXTS, output_format, output_path, read_subtitle, write_atomic
from .cache import CachedProvider, Store, sha
from .assemble import memory_key
from .langdetect_util import detect_language
from .textprep import (SDH_CATEGORIES, SDH_DEFAULTS, SDH_OPTIONS, detect_sdh, option_label,
                       resolve_decisions)
from .timing import shift_blocks
from .tokens import fmt_cost, fmt_tokens, is_exact
from .progress import Progress, ProgressConsoleHandler

log = logging.getLogger("subtrans")
NON_TTY_DEFAULTS = SDH_DEFAULTS
CONSOLE: ProgressConsoleHandler | None = None


# ---------------------------------------------------------------- yardımcılar

def setup_logging(settings: Settings) -> Path:
    logs_dir = settings.path("logs")
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_path = logs_dir / f"run_{datetime.now():%Y%m%d_%H%M%S}.log"
    log.setLevel(logging.DEBUG)
    log.handlers.clear()
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(message)s"))
    global CONSOLE
    ch = ProgressConsoleHandler(sys.stdout)
    CONSOLE = ch
    level = str(settings["output"].get("log_level", "info")).upper()
    ch.setLevel(getattr(logging, level, logging.INFO))
    ch.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(fh)
    log.addHandler(ch)
    for noisy in ("httpx", "openai", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    return log_path


def say(msg: str = "") -> None:
    """Hem konsola hem log dosyasına yazar."""
    log.info(msg)


def ask(prompt: str, options: list[str], category: str = "") -> str:
    """Terminalden seçim ister. Numara veya ilk harf kabul edilir."""
    while True:
        try:
            ans = input(prompt).strip().lower()
        except EOFError:
            return options[0]
        if ans == "":
            return options[0]  # Enter = varsayılan
        if ans.isdigit() and 1 <= int(ans) <= len(options):
            return options[int(ans) - 1]
        for o in options:
            if ans and (ans == o or option_label(category, o).startswith(ans) or o.startswith(ans)):
                return o
        print("  Geçersiz seçim, numara girin.")


def confirm(prompt: str) -> bool:
    try:
        ans = input(prompt).strip().lower()
    except EOFError:
        return False
    return ans in ("", "e", "evet", "y", "yes")


def find_files(src: Path, recursive: bool, exclude: Path) -> list[Path]:
    it = src.rglob("*") if recursive else src.glob("*")
    files = []
    for p in it:
        if not p.is_file() or p.suffix.lower() not in SUPPORTED_EXTS:
            continue
        if any(part.startswith(".") for part in p.relative_to(src).parts[:-1]):
            continue                      # .subtrans gibi gizli klasörler
        try:
            p.resolve().relative_to(exclude.resolve())
            continue  # hedef klasör kaynağın içindeyse kendi çıktılarımızı tekrar okumayalım
        except ValueError:
            pass
        files.append(p)
    return sorted(files)


def glossary_folder(settings: Settings) -> Path:
    p = Path(str(settings["glossary"].get("folder", "sozlukler"))).expanduser()
    return p if p.is_absolute() else settings.base_dir / p


def existing_series(folder: Path, target_lang: str) -> list[str]:
    names = []
    for f in sorted(folder.glob(f"*.{target_lang}.json")) if folder.exists() else []:
        try:
            names.append(json.loads(f.read_text(encoding="utf-8-sig")).get("series") or f.stem.rsplit(".", 1)[0])
        except (OSError, ValueError):
            log.debug("Sözlük okunamadı: %s", f)
    return names


def assign_series(rels: list[Path], settings: Settings, args: argparse.Namespace,
                  target_lang: str) -> dict[Path, str]:
    """Her dosyayı bir seriye bağlar. Benzer adlar (Spy Family / Spy x Family) tek seride toplanır."""
    cfg_series = str(settings["glossary"].get("series", "auto")).strip()
    fixed = args.series or ("" if cfg_series.lower() == "auto" else cfg_series)
    if fixed:
        return {r: fixed for r in rels}
    folder = glossary_folder(settings)
    known = existing_series(folder, target_lang)
    groups: list[list] = []        # [ad, [dosyalar]]
    for r in sorted(rels, key=str):
        name = series_from_path(r)
        name = next((k for k in known if similar(k, name)), name)
        for g in groups:
            if similar(g[0], name):
                g[1].append(r)
                if g[0] not in known and (name in known or len(name) > len(g[0])):
                    g[0] = name
                break
        else:
            groups.append([name, [r]])

    say("\nSeri sözlükleri (isimler her bölümde aynı yazılsın diye):")
    out: dict[Path, str] = {}
    for name, files in groups:
        path = folder / f"{slugify(name)}.{target_lang}.json"
        info = "mevcut sözlük" if path.exists() else "yeni sözlük"
        say(f"  {name}  ← {len(files)} dosya  ({info}: {path.name})")
        if sys.stdin.isatty():
            try:
                typed = input(f"  Seri adı [Enter = {name}]: ").strip()
            except EOFError:
                typed = ""
            if typed:
                name = next((k for k in known if slugify(k) == slugify(typed)), typed)
        for r in files:
            out[r] = name
    return out


def series_instructions(settings: Settings, series: str) -> str:
    """Seri talimat dosyası: sozlukler/<seri>.talimat.txt (# ile başlayan satırlar not sayılır, gönderilmez).
    Örn. "Anya kendinden üçüncü şahısla bahseder." / "Bond'a herkes 'Bay Bond' der." """
    if not series:
        return ""
    path = glossary_folder(settings) / f"{slugify(series)}.talimat.txt"
    try:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return ""
    text = "\n".join(ln.rstrip() for ln in lines if ln.strip() and not ln.lstrip().startswith("#"))
    if text:
        log.debug("Seri talimatı okundu (%s): %d karakter", path.name, len(text))
    return text[:4000]


def memory_series(job: FileJob) -> str:
    return slugify(job.series) if job.series else ""


def _rel_key(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except ValueError:
        return str(path)


def learn_user_edits(store: Store, jobs: list[FileJob], dst_dir: Path) -> int:
    """Önceki çalışmada yazılan çıktıyı kullanıcı elle düzelttiyse farkları çeviri hafızasına ekler.
    Eşleştirme zaman koduyla yapılır; yalnızca metni değişen bloklar öğrenilir."""
    learned = 0
    for job in jobs:
        rec = store.get_written(_rel_key(job.out_path, dst_dir))
        if rec is None or not job.out_path.exists():
            continue
        _, rows = rec
        try:
            cur = read_subtitle(job.out_path)
        except OSError:
            continue
        # Eşleştirme: blok sayısı aynıysa sırayla (zamanı da tutmalı); değilse yalnızca dosyada tek olan
        # zaman koduyla. Aynı zamanda birden çok blok olabilir (ASS tabela + konuşma), karıştırılmaz.
        pairs: list[tuple[list, str]] = []
        if len(cur.blocks) == len(rows):
            pairs = [(row, b.text) for row, b in zip(rows, cur.blocks)
                     if (row[0], row[1]) == (b.start_ms, b.end_ms)]
        else:
            count_now: dict[tuple, int] = {}
            for b in cur.blocks:
                count_now[(b.start_ms, b.end_ms)] = count_now.get((b.start_ms, b.end_ms), 0) + 1
            count_rec: dict[tuple, int] = {}
            for row in rows:
                count_rec[(row[0], row[1])] = count_rec.get((row[0], row[1]), 0) + 1
            by_time = {(b.start_ms, b.end_ms): b.text for b in cur.blocks}
            pairs = [(row, by_time[(row[0], row[1])]) for row in rows
                     if count_now.get((row[0], row[1])) == 1 and count_rec[(row[0], row[1])] == 1]
        series = memory_series(job)
        for (start, end, src_text, out_text), text in pairs:
            if " ".join(text.split()) == " ".join(out_text.split()):
                continue
            if not text.strip():
                continue
            store.remember(series, memory_key(src_text), text)
            learned += 1
            log.debug("%s: düzeltme öğrenildi: %r -> %r", job.rel, out_text, text)
    return learned


def record_written(store: Store, job: FileJob, blocks: list, dst_dir: Path) -> None:
    """Yazılan çıktıyı (yeniden okunmuş hâliyle, karşılaştırma aynı biçimde yapılsın) kaydeder."""
    try:
        back = read_subtitle(job.out_path).blocks
    except OSError:
        return
    if len(back) != len(blocks):
        return
    rows = [[nb.start_ms, nb.end_ms, job.srt.blocks[b.pos].text, nb.text] for b, nb in zip(blocks, back)]
    store.put_written(_rel_key(job.out_path, dst_dir), memory_series(job), rows)


def write_suspects(engine: Engine, job: FileJob, dst_dir: Path) -> None:
    report = engine.suspect_report(job)
    path = dst_dir / "_supheli" / (str(job.rel.with_suffix("")) + ".txt")
    if not report:
        try:
            path.unlink()
        except OSError:
            pass
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(report, encoding="utf-8")
    except OSError as e:
        log.debug("şüpheli satır raporu yazılamadı: %s", e)


def fmt_secs(s: float) -> str:
    m, s = divmod(int(round(s)), 60)
    return f"{m}:{s:02d}" if m else f"{s} sn"


# ---------------------------------------------------------------- argümanlar

def parse_args(argv: list[str]) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="AI altyazı çevirici")
    ap.add_argument("--config", default="config.toml", help="ayar dosyası (varsayılan: config.toml)")
    ap.add_argument("--source", help="kaynak klasör")
    ap.add_argument("--target", help="hedef klasör")
    ap.add_argument("--lang", help="hedef dil kodu (örn. tr, en, de)")
    ap.add_argument("--model", help="çeviri modeli (örn. gpt-6-luna)")
    ap.add_argument("--review-model", help='anlam kontrolü modeli (örn. gpt-6.1-sol; "yok" = kontrol yapılmaz)')
    ap.add_argument("--mode", choices=["translate", "estimate_only", "shift_only"])
    ap.add_argument("--chunk-size", help="'auto' veya sayı")
    ap.add_argument("--parallel", help="'auto' veya sayı")
    ap.add_argument("--order", choices=["parallel", "sequential"], help="chunk sırası")
    ap.add_argument("--shift", type=float, help="zaman kaydırma (saniye, örn. 3 veya -2.5)")
    ap.add_argument("--yes", "-y", action="store_true", help="maliyet onayını sorma")
    ap.add_argument("--series", help='tüm dosyalar için seri sözlüğü adı (örn. "Spy x Family")')
    ap.add_argument("--no-glossary", action="store_true", help="seri sözlüğünü kullanma")
    ap.add_argument("--no-review", action="store_true", help="anlam kontrolü turunu atla (daha hızlı, daha ucuz)")
    ap.add_argument("--format", choices=["srt", "ass", "vtt", "kaynak"],
                    help="çıktı biçimi (varsayılan config.toml [output] format = srt)")
    ap.add_argument("--fresh", action="store_true",
                    help="önbelleği kullanma: her şeyi yeniden gönder (yeni yanıtlar yine önbelleğe yazılır)")
    ap.add_argument("--offline", action="store_true",
                    help="API'ye hiç bağlanma, yalnızca önbellekteki yanıtlarla çalış (test / yeniden oluşturma)")
    ap.add_argument("--review-only", action="store_true",
                    help="çeviriyi yeniden yapma, kayıtlı çeviriye yalnızca anlam kontrolü uygula "
                         "(örn. --review-model gpt-6.1-sol ile)")
    ap.add_argument("--batch", action="store_true", help="toplu istek (Batch API): %%50 ucuz, yanıt birkaç dakika sürer")
    ap.add_argument("--test-key", action="store_true",
                    help="çeviri yapmadan API anahtarını ve model erişimini dene (token harcamaz)")
    return ap.parse_args(argv)


def test_key(settings: Settings) -> int:
    from .config import DOTENV_NOTES, describe_key
    env_name = settings["provider"].get("api_key_env", "OPENAI_API_KEY")
    say(f"Anahtar kontrolü — model: {settings['provider']['model']}, adres: {settings['provider']['base_url']}")
    for n in DOTENV_NOTES:
        say(f"  ! {n}")
    say(f"  {describe_key(env_name)}")

    async def go():
        prov = make_provider(settings["provider"])
        try:
            return await prov.check()
        finally:
            await prov.close()
    try:
        say("  " + asyncio.run(go()))
        return 0
    except ProviderError as e:
        say(f"  HATA: {e}")
        return 1


# ---------------------------------------------------------------- ana akış

def main(argv: list[str] | None = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # Windows konsolunda Türkçe karakterler
    except Exception:
        pass
    if os.name == "nt":
        os.system("")  # Windows konsolunda renk/satır silme kodlarını (ANSI) etkinleştirir
    args = parse_args(sys.argv[1:] if argv is None else argv)
    cfg_path = Path(args.config)
    if not cfg_path.is_absolute():
        cfg_path = (Path.cwd() / cfg_path)
    if not cfg_path.exists():
        alt = Path(__file__).resolve().parent.parent / args.config
        if alt.exists():
            cfg_path = alt
    load_dotenv(cfg_path.parent / ".env")
    settings = load_settings(cfg_path, {
        "paths": {"source": args.source, "target": args.target},
        "language": {"target": args.lang},
        "provider": {"model": args.model},
        "run": {"mode": args.mode, "time_shift_seconds": args.shift},
        "output": {"format": args.format},
        "chunking": {"chunk_size": args.chunk_size, "parallel": args.parallel, "chunk_order": args.order},
    })
    log_path = setup_logging(settings)
    if args.test_key:
        return test_key(settings)
    from .config import DOTENV_NOTES
    for n in DOTENV_NOTES:
        say(f"! {n}")
    choose_models(settings, args)
    try:
        return run(settings, args, log_path)
    except KeyboardInterrupt:
        say("\nKullanıcı tarafından durduruldu. Tamamlanan dosyalar yazıldı, yarım kalanlar yazılmadı.")
        return 130


_NO_REVIEW = ("yok", "kapalı", "kapali", "hayır", "hayir", "none", "off", "0")


def choose_models(settings: Settings, args: argparse.Namespace) -> None:
    """Anlam kontrolü modelini belirler (soru sorulmaz). Öncelik: --review-model, sonra config.toml'daki
    [provider] review_model (ya da [quality] review_model). Boş = çeviri modeliyle aynı, "yok" = kontrol yapılmaz."""
    q = settings.raw.setdefault("quality", {})
    value = getattr(args, "review_model", None)
    if value is None:
        value = settings.raw.get("provider", {}).get("review_model") or q.get("review_model") or ""
    value = str(value).strip()
    effort = settings.raw.get("provider", {}).get("review_reasoning_effort")
    if effort is not None and not q.get("review_reasoning_effort"):
        q["review_reasoning_effort"] = effort
    if value.lower() in _NO_REVIEW:
        q["review"] = False
    elif value:
        q["review_model"] = value
        if getattr(args, "review_model", None):
            q["review"] = True
    if getattr(args, "no_review", False):
        q["review"] = False
    log.debug("Modeller: çeviri=%s, kontrol=%s", settings["provider"]["model"],
              (q.get("review_model") or settings["provider"]["model"]) if q.get("review", True) else "yok")


class Phases:
    """Aşama süreleri: okuma, hazırlık, çeviri..."""

    def __init__(self):
        self.times: dict[str, float] = {}
        self._name = ""
        self._t = 0.0

    def start(self, name: str, msg: str = "") -> None:
        self.stop()
        self._name, self._t = name, time.monotonic()
        if msg:
            say(f"▶ {msg}")

    def stop(self) -> None:
        if self._name:
            self.times[self._name] = self.times.get(self._name, 0.0) + time.monotonic() - self._t
            log.debug("Aşama '%s' %.2f sn sürdü", self._name, time.monotonic() - self._t)
            self._name = ""

    def summary(self) -> str:
        return " · ".join(f"{k} {fmt_secs_precise(v)}" for k, v in self.times.items())


def fmt_secs_precise(s: float) -> str:
    return f"{s:.1f} sn" if s < 60 else fmt_secs(s)


def run(settings: Settings, args: argparse.Namespace, log_path: Path) -> int:
    t_start = time.monotonic()
    ph = Phases()
    src_dir, dst_dir = settings.path("source"), settings.path("target")
    mode = settings["run"]["mode"]
    target_lang = str(settings["language"]["target"]).lower()
    model = settings["provider"]["model"]
    shift = float(settings["run"].get("time_shift_seconds") or 0.0)

    say("=" * 64)
    q = settings.raw.get("quality", {})
    review_label = ((str(q.get("review_model") or "").strip() or model) if q.get("review", True) else "yok")
    say(f" AI Altyazı Çevirici  |  mod: {mode}  |  çeviri: {model}  |  kontrol: {review_label}"
        f"  |  hedef: {lang_name(target_lang)}")
    say(f" Kaynak: {src_dir}")
    say(f" Hedef : {dst_dir}")
    ch = settings["chunking"]
    say(f" Parça boyutu: {ch['chunk_size']}  |  sıra: {ch['chunk_order']}  |  eşzamanlı istek: {ch['parallel']}"
        + (f"  |  zaman kaydırma: {shift:+.3f} sn" if shift else ""))
    say("=" * 64)

    if not src_dir.exists():
        say(f"HATA: kaynak klasör yok: {src_dir}")
        return 1
    files = find_files(src_dir, bool(settings["paths"]["recursive"]), dst_dir)
    if not files:
        say("Kaynak klasörde altyazı dosyası (.srt / .ass / .ssa / .vtt) bulunamadı.")
        return 1
    kinds: dict[str, int] = {}
    for f in files:
        kinds[f.suffix.lower()[1:].upper()] = kinds.get(f.suffix.lower()[1:].upper(), 0) + 1
    say(f"{len(files)} altyazı dosyası bulundu (" + ", ".join(f"{v} {k}" for k, v in sorted(kinds.items())) + ").")
    out_choice = str(settings["output"].get("format", "srt") or "srt").lower()

    # ---- okuma
    ph.start("okuma", "Dosyalar okunuyor (encoding tespiti, biçim kontrolü)...")
    loaded = []
    for f in files:
        rel = f.relative_to(src_dir)
        try:
            srt = read_subtitle(f)
        except OSError as e:
            say(f"  ✗ {rel}: okunamadı ({e})")
            continue
        log.debug("%s: encoding=%s bom=%s güven=%.2f blok=%d", rel, srt.encoding, srt.had_bom,
                  srt.encoding_confidence, len(srt.blocks))
        if srt.encoding_confidence < 0.6:
            say(f"  ! {rel}: encoding tespiti belirsiz ({srt.encoding}, güven {srt.encoding_confidence:.0%})")
        for w in srt.warnings:
            log.debug("%s: parser: %s", rel, w)
        if srt.warnings:
            say(f"  ! {rel}: {len(srt.warnings)} biçim sorunu düzeltilerek okundu (ayrıntı logda)")
        if not srt.blocks:
            say(f"  ✗ {rel}: hiç altyazı bloğu bulunamadı, atlanıyor")
            continue
        loaded.append((rel, srt))

    # ---- yalnızca kaydırma modu
    if mode == "shift_only":
        if not shift:
            say("shift_only modu için time_shift_seconds (veya --shift) değeri verin.")
            return 1
        for rel, srt in loaded:
            blocks, clipped = shift_blocks(srt.blocks, shift)
            fmt = output_format(srt.doc.fmt if srt.doc is not None else "srt", out_choice)
            out = output_path(dst_dir / rel, fmt)
            write_atomic(out, blocks, fmt, srt.doc, bom=bool(settings["output"]["bom"]))
            note = f" ({len(clipped)} blok 0'a kırpıldı)" if clipped else ""
            say(f"  ✓ {rel} kaydırıldı{note}")
            if clipped:
                log.debug("%s: kırpılan bloklar: %s", rel, clipped)
        say(f"Bitti. Log: {log_path}")
        return 0

    # ---- dil tespiti
    ph.start("dil tespiti", "Kaynak dil tespit ediliyor...")
    rules = load_rule_pack(target_lang)
    if rules.is_default:
        say(f"! '{target_lang}' için kural paketi yok, genel varsayılan paket kullanılıyor.")
    configured_src = str(settings["language"]["source"]).lower()
    to_translate = []
    for rel, srt in loaded:
        if configured_src != "auto":
            lang, prob = configured_src, 1.0
        else:
            lang, prob = detect_language(srt.blocks)
            if lang == "unknown":
                say(f"  ! {rel}: kaynak dil tespit edilemedi, model kendisi anlayacak")
            elif prob < 0.8:
                say(f"  ! {rel}: kaynak dil belirsiz ({lang_name(lang)} %{prob * 100:.0f})")
        log.debug("%s: kaynak dil=%s olasılık=%.2f", rel, lang, prob)
        if lang.split("-")[0] == target_lang.split("-")[0]:
            say(f"  - {rel}: zaten {lang_name(target_lang)}, çevrilmeyecek")
            continue
        to_translate.append((rel, srt, lang if lang != "unknown" else "the source language"))
    if not to_translate:
        say("Çevrilecek dosya yok.")
        return 0

    # ---- SDH soruları
    ph.stop()
    totals = {k: [0, 0] for k in SDH_CATEGORIES}  # [blok, dosya]
    for _, srt, _ in to_translate:
        per_file = {k: 0 for k in SDH_CATEGORIES}
        for b in srt.blocks:
            for k, v in detect_sdh(b.text).items():
                per_file[k] += v
        for k, v in per_file.items():
            totals[k][0] += v
            totals[k][1] += 1 if v else 0
    decisions: dict[str, str] = {}
    asked_header = False
    for k, desc in SDH_CATEGORIES.items():
        val = str(settings["sdh"].get(k, "ask")).lower()
        blocks_n, files_n = totals[k]
        if val != "ask":
            decisions[k] = val
            continue
        if blocks_n == 0:
            decisions[k] = NON_TTY_DEFAULTS[k]
            continue
        if not sys.stdin.isatty():
            decisions[k] = NON_TTY_DEFAULTS[k]
            say(f"! {desc.split('  ')[0]}: terminal etkileşimsiz, varsayılan '{option_label(k, decisions[k])}' seçildi")
            continue
        if not asked_header:
            say("\nDosyalarda şunlar bulundu, ne yapılsın?")
            asked_header = True
        opts = SDH_OPTIONS[k]
        opt_str = "  ".join(f"[{i + 1}] {option_label(k, o)}" + (" (varsayılan)" if i == 0 else "")
                            for i, o in enumerate(opts))
        print(f"\n  {desc}\n  ({files_n} dosyada, {blocks_n} blokta)\n  {opt_str}")
        decisions[k] = ask(f"  Seçiminiz [Enter = {option_label(k, opts[0])}]: ", opts, k)
        log.debug("SDH cevabı: %s = %s", k, decisions[k])
    # ---- yerleşik karşılıklar (Orta Dünya, Kıyamet Dağı...)
    est = str(settings["language"].get("established_names", "ask")).lower()
    if est == "ask":
        if sys.stdin.isatty():
            opts = ["use", "keep"]
            print(f"\n  {lang_name(target_lang)} dilinde yerleşik karşılığı olan yer adı, unvan ve terimler"
                  f"\n  örn. Middle-earth → Orta Dünya, Mount Doom → Kıyamet Dağı (karakter adları hiçbir zaman çevrilmez)"
                  f"\n  [1] yerleşik karşılığı kullan (varsayılan)  [2] orijinal bırak")
            est = ask("  Seçiminiz [Enter = yerleşik karşılığı kullan]: ", opts, "established_names")
        else:
            est = "use"
    decisions["established_names"] = est
    decisions["note_only_blocks"] = str(settings["sdh"].get("note_only_blocks", "delete")).lower()
    decisions["format_tags"] = "remove" if str(settings["output"].get("format_tags", "keep")).lower() in (
        "remove", "kaldır", "false", "no") else "keep"
    say("Kararlar: " + ", ".join(f"{k}={option_label(k, decisions[k])}" for k in SDH_CATEGORIES)
        + f", yerleşik karşılıklar={option_label('established_names', est)}"
        + ", yalnız nottan oluşan bloklar=" + {"delete": "sil", "blank": "boş bırak", "translate": "çevir"}
        .get(decisions["note_only_blocks"], decisions["note_only_blocks"]))

    # ---- seri sözlüğü
    if getattr(args, "no_review", False):
        settings.raw.setdefault("quality", {})["review"] = False
    use_glossary = bool(settings["glossary"].get("enabled", True)) and not args.no_glossary
    series_of: dict[Path, str] = {}
    glossaries: dict[str, Glossary] = {}
    if use_glossary:
        series_of = assign_series([r for r, _, _ in to_translate], settings, args, target_lang)
        for name in sorted(set(series_of.values())):
            try:
                g = Glossary.load_or_new(glossary_folder(settings), name, target_lang)
            except (OSError, ValueError) as e:
                say(f"  ! '{name}' sözlüğü okunamadı ({e}), bu çalışmada sözlük kullanılmayacak")
                continue
            g.lower_races = rules.lowercase_races
            glossaries[slugify(name)] = g
            if g.removed_on_load:
                say(f"  ! '{g.series}' sözlüğünde {g.removed_on_load} bozuk kayıt temizlendi "
                    "(örn. Japonca harfle yazılmış hedef); bölümler yeniden taranacak.")
            if g.removed_keep:
                say(f"  ! '{g.series}' sözlüğünde İngilizce olduğu hâlde kurgusal dil sanılan "
                    f"{len(g.removed_keep)} satır listeden çıkarıldı, artık çevrilecek: "
                    + ", ".join(f'"{x}"' for x in g.removed_keep[:3]))
            log.debug("Sözlük %s: %d terim, %d işlenmiş dosya", g.path, len(g.terms), len(g.processed_files))

    # ---- plan + tahmin
    ph.start("hazırlık", "Parçalara bölünüyor, token ve maliyet hesaplanıyor...")
    engine = Engine(settings, None, rules, decisions)
    engine.review_only = bool(getattr(args, "review_only", False))
    jobs: list[FileJob] = []
    taken: dict[Path, Path] = {}
    for rel, srt, lang in to_translate:
        src_fmt = srt.doc.fmt if srt.doc is not None else "srt"
        fmt = output_format(src_fmt, out_choice)
        out_path = output_path(dst_dir / rel.parent / output_name(rel, target_lang), fmt)
        if out_path in taken:
            say(f"  ! {rel}: {taken[out_path]} ile aynı çıktı adına ({out_path.name}) yazılacaktı, atlandı")
            continue
        taken[out_path] = rel
        job = FileJob(srt=srt, rel=rel, out_path=out_path, src_lang=lang,
                      decisions=resolve_decisions(decisions, lang), out_fmt=fmt)
        if rel in series_of:
            job.series = series_of[rel]
            job.glossary = glossaries.get(slugify(job.series))
            job.instructions = series_instructions(settings, job.series)
        engine.plan(job)
        jobs.append(job)
        log.debug("%s: %d blok, %d çevrilecek, %d chunk (otomatik önerilen %d, kullanılan %d)",
                  rel, len(srt.blocks), len(job.translate_pos), len(job.chunks),
                  job.chunk_size_auto, job.chunk_size_used)

    g_jobs = [j for j in jobs if j.glossary is not None and j.rel.name not in j.glossary.processed_files]
    est_in = sum(j.est_input for j in jobs) + sum(j.glossary_est[0] for j in g_jobs)
    est_out = sum(j.est_output for j in jobs) + sum(j.glossary_est[1] for j in g_jobs)
    n_blocks = sum(len(j.translate_pos) for j in jobs)
    n_chunks = sum(len(j.chunks) for j in jobs)
    price = settings.price(model)
    est_cached = sum(j.est_cached for j in jobs)
    est_cost = Usage(input_tokens=est_in, cached_input_tokens=est_cached, output_tokens=est_out).cost(price)
    rmodel = str(settings.raw.get("quality", {}).get("review_model", "") or "").strip()
    if engine.review_on and rmodel and rmodel != model and est_cost is not None:
        r_in = sum(j.est_review[0] for j in jobs)
        r_out = sum(j.est_review[1] for j in jobs)
        r_price = settings.price(rmodel)
        if r_price:
            r = Usage(input_tokens=r_in, output_tokens=r_out)
            est_cost += (r.cost(r_price) or 0) - (r.cost(price) or 0)
    approx = "" if is_exact(model) else " (yaklaşık)"
    say("")
    ph.stop()
    say(f"Tahmin{approx}: {len(jobs)} dosya, {n_blocks} blok, {n_chunks} parça")
    say(f"  ~{fmt_tokens(est_in)} giriş / ~{fmt_tokens(est_out)} çıkış token  ≈ {fmt_cost(est_cost)}"
        + ("" if price else f"  (config.toml'da [prices.\"{model}\"] yok)"))
    say("  Yeniden denemeler bu tahmine dahil değildir."
        + (f" Sözlük isteği ({len(g_jobs)} dosya) dahildir." if g_jobs else "")
        + (" Anlam kontrolü dahildir." if engine.review_on else ""))

    if mode == "estimate_only":
        say(f"Yalnızca tahmin modu, API'ye hiçbir şey gönderilmedi. Log: {log_path}")
        return 0
    if settings["run"]["confirm_cost"] and not args.yes:
        if not sys.stdin.isatty() or not confirm("Devam edilsin mi? [E/h] "):
            say("İptal edildi.")
            return 0

    # ---- çeviri
    offline = bool(getattr(args, "offline", False))
    use_cache = bool(settings["run"].get("cache", True)) or offline or engine.review_only
    store = None
    if use_cache:
        try:
            store = Store(dst_dir / ".subtrans" / "proje.sqlite")
        except Exception as e:  # noqa: BLE001
            say(f"  ! önbellek açılamadı ({e}); önbelleksiz devam ediliyor")
            if offline or engine.review_only:
                return 1
    engine.store = store
    engine.main_price = price
    fresh = bool(getattr(args, "fresh", False))
    try:
        inner = None if offline else make_provider(settings["provider"])
        engine.provider = CachedProvider(inner, store, model, offline=offline, fresh=fresh) if store else inner
        q = settings.raw.get("quality", {})
        rmodel = str(q.get("review_model", "") or "").strip()
        pv = settings["provider"]
        r_url = str(pv.get("review_base_url", "") or "").strip()
        r_key = str(pv.get("review_api_key_env", "") or "").strip()
        if engine.review_on and ((rmodel and rmodel != model) or r_url):
            rmodel = rmodel or model
            rcfg = dict(pv, model=rmodel)
            if r_url:
                rcfg["base_url"] = r_url          # örn. OpenRouter: https://openrouter.ai/api/v1
            if r_key:
                rcfg["api_key_env"] = r_key
            if str(q.get("review_reasoning_effort", "") or "").strip():
                rcfg["reasoning_effort"] = str(q["review_reasoning_effort"]).strip()
            rinner = None if offline else make_provider(rcfg)
            engine.review_provider = CachedProvider(rinner, store, rmodel + "|" + (r_url or ""), offline=offline,
                                                    fresh=fresh) if store else rinner
            engine.review_price = settings.price(rmodel)
            say(f"  Anlam kontrolü modeli: {rmodel}"
                + ("" if engine.review_price else f"  (config.toml'da [prices.\"{rmodel}\"] yok, maliyete eklenmez)"))
    except ProviderError as e:
        say(f"HATA: {e}")
        return 1

    engine.batch = bool(getattr(args, "batch", False) or settings["provider"].get("batch", False)) \
        and store is not None and not offline
    if store is not None:
        learned = learn_user_edits(store, jobs, dst_dir)
        if learned:
            say(f"  Çeviri hafızası: önceki çıktılarda elle düzelttiğin {learned} satır öğrenildi "
                "(aynı kaynak satırda senin çevirin kullanılacak)")
        for j in jobs:
            j.memory = store.memory(memory_series(j))
    say("")
    ph.start("çeviri")
    try:
        asyncio.run(_translate_all(engine, jobs, settings, shift))
    except FatalError as e:
        say(f"\nHATA: {e}")
        if "401" in str(e):
            say("  Çözüm: README'deki 'API anahtarı' adımına bakın. Anahtarı denemek için: python main.py --test-key")
        say("Çalışma durduruldu. Tamamlanmış dosyalar yazıldı.")
        for j in jobs:
            if j.status != "tamam" and not j.errors:
                j.status = "durduruldu"
                j.errors.append("çalışma durduruldu, dosya yazılmadı")

    ph.stop()

    # ---- özet
    total = Usage()
    for j in jobs:
        total.add(j.usage)
    ok = [j for j in jobs if j.status == "tamam"]
    bad = [j for j in jobs if j.status != "tamam"]
    warn_n = sum(len(j.warnings) for j in jobs)
    say("")
    say("=" * 64)
    say(f" Bitti: {len(ok)} başarılı, {len(bad)} başarısız / {len(jobs)} dosya   süre {fmt_secs(time.monotonic() - t_start)}")
    say(f" Token: {fmt_tokens(total.input_tokens)} giriş ({fmt_tokens(total.cached_input_tokens)} cache)"
        f" / {fmt_tokens(total.output_tokens)} çıkış   {total.requests} istek")
    say(f" Aşamalar: {ph.summary()}")
    pr = engine.progress
    if pr is not None and (pr.retries or pr.splits):
        say(f" Yeniden deneme: {pr.retries}, ikiye bölünen parça: {pr.splits}")
    if total.reasoning_tokens:
        say(f" Akıl yürütme token'ı: {fmt_tokens(total.reasoning_tokens)} (çıkışa dahil)")
    say(f" Maliyet: {fmt_cost(total.cost(price))}   (tahmin {fmt_cost(est_cost)})")
    hits = sum(getattr(p, "hits", 0) for p in {id(x): x for x in (engine.provider, engine.review_provider)
                                               if x is not None}.values())
    if hits:
        saved = Usage()
        for p in {id(x): x for x in (engine.provider, engine.review_provider) if x is not None}.values():
            saved.add(getattr(p, "saved", Usage()))
        say(f" Önbellek: {hits} istek daha önce yapılmıştı, yeniden ödenmedi (≈ {fmt_cost(saved.cost(price))} tasarruf)")
    mem = sum(j.memory_used for j in ok)
    if mem:
        say(f" Çeviri hafızası: {mem} blok senin önceki düzeltmenle yazıldı")
    sus = [j for j in ok if j.suspects]
    if sus:
        say(f" Şüpheli satır raporu: {sum(len(j.suspects) for j in sus)} satır → {dst_dir / '_supheli'}")
    if warn_n:
        say(f" Uyarı: {warn_n} (ayrıntılar logda)")
    kept = sum(j.kept_verbatim for j in ok)
    if kept:
        both = sum(j.conlang_translated for j in ok)
        say(f" Kurgusal dil: {kept} blok aynen bırakıldı (Elfçe vb.)"
            + (f", {both} satırın altına Türkçesi eklendi" if both else ""))
    if engine.review_on:
        fixed = sum(j.review_fixes for j in ok)
        say(f" Anlam kontrolü: {fixed} blok düzeltildi" + (" (ayrıntılar logda)" if fixed else ""))
    hon = sum(j.honorific_issues for j in ok)
    if hon:
        say(f" ! Hitap eki: {hon} parçada yeniden denemeye rağmen eksik kaldı (ayrıntı logda)")
    misses = sum(j.glossary_misses for j in ok)
    if misses:
        log.debug("Sözlük yazımı %d yerde çeviride görülmedi (çoğu zamir kullanımıdır; ayrıntı DEBUG satırlarında)", misses)
    for j in bad:
        say(f"   ✗ {j.rel}: {'; '.join(j.errors)[:200] or j.status}")
    say(f" Log: {log_path}")
    if store is not None:
        store.close()
    say("=" * 64)
    return 0 if not bad else 2


async def _build_glossaries(engine: Engine, jobs: list[FileJob]) -> None:
    """Çeviriden önce her bölümün isim/terimlerini çıkarıp seri sözlüğüne ekler."""
    groups: dict[int, tuple[Glossary, list[FileJob]]] = {}
    for j in jobs:
        if j.glossary is not None:
            groups.setdefault(id(j.glossary), (j.glossary, []))[1].append(j)
    if not groups:
        return
    # Kurgusal dil listesinde aslında İngilizce olan satırlar varsa çıkarılır ("Isildur, hurry! Follow me.")
    for g, js in groups.values():
        vocab = english_vocab(b.text for j in js for b in j.srt.blocks)
        bad = g.prune_keep(vocab)
        if bad:
            say(f"  ! '{g.series}' sözlüğünde İngilizce olduğu hâlde kurgusal dil sanılan {len(bad)} satır "
                "listeden çıkarıldı, artık çevrilecek: " + ", ".join(f'"{x}"' for x in bad[:3]))
            try:
                g.save()
            except OSError as e:
                log.debug("sözlük kaydedilemedi: %s", e)
            for j in js:
                engine.plan(j)
    # Bölüm analizi (sahne özetleri, hitap biçimi) kaydedilir: aynı bölüm yeniden çevrilirken tekrar sorulmaz
    store = engine.store
    no_requests = engine.review_only or bool(getattr(engine.provider, "offline", False))
    an_key = {}
    for g, js in groups.values():
        for j in js:
            an_key[id(j)] = "an:" + sha(g.series, str(engine.s["provider"]["model"]),
                                        "\n".join(b.text for b in j.srt.blocks))
            if store is not None:
                saved = store.get_stage(an_key[id(j)])
                if saved:
                    j.analysis = saved
    todo = [j for g, js in groups.values() for j in js
            if not no_requests and (j.rel.name not in g.processed_files
                                    or (engine.analysis_on and store is not None and j.analysis is None))]
    t0 = time.monotonic()
    if todo:
        what = "isim/terimler, sahne özetleri ve hitap biçimi" if engine.analysis_on else "isim ve terimleri"
        say(f"▶ Bölüm analizi: {len(todo)} bölümün {what} çıkarılıyor...")
    results = await asyncio.gather(*(engine.extract_terms(j) for j in todo))
    found = {id(j): r for j, r in zip(todo, results)}
    for j in todo:
        if j.analysis is not None and store is not None:
            store.put_stage(an_key[id(j)], j.analysis)
        if j.analysis and j.glossary is not None:
            for ln, tr in (j.analysis.get("meanings") or {}).items():
                if not j.glossary.conlang_translation(ln):
                    j.glossary.keep_tr[ln] = tr
    for g, js in groups.values():
        added, notes, skipped, kept = 0, [], 0, 0
        for j in sorted(js, key=lambda x: str(x.rel)):      # bölüm sırasıyla: ilk geçen yazım kazanır
            if id(j) not in found:
                skipped += 1
                continue
            res = found[id(j)]
            if res is None:
                continue
            terms, keep = res
            a, n = g.merge(terms, "\n".join(b.text for b in j.srt.blocks))
            added += a
            notes += n
            kept += g.add_keep(keep)
            if j.rel.name not in g.processed_files:
                g.processed_files.append(j.rel.name)
        for n in notes:
            log.debug("Sözlük %s: %s", g.series, n)
        if added or kept or not g.existed or any(found.get(id(j)) is not None for j in js):
            try:
                g.save()
                g.existed = True
            except OSError as e:
                say(f"  ! sözlük kaydedilemedi: {e}")
        extra = f", {skipped} bölüm daha önce işlenmiş" if skipped else ""
        conflicts = [n for n in notes if "korundu" in n]
        say(f"  {g.series}: {added} yeni terim, toplam {len(g.terms)}{extra}  → {g.path.name}"
            + (f"  ({len(conflicts)} farklı öneri reddedildi, sözlükteki korundu)" if conflicts else ""))
        if g.keep_lines:
            say(f"    kurgusal dil (Elfçe vb.): {len(g.keep_lines)} satır hiç çevrilmeden aynen yazılacak"
                + (f" ({kept} yeni)" if kept else ""))
    # Elfçe satırların Türkçesi (altında gösterilecek): eksik olanlar tek istekle sorulur
    if engine.conlang_both and not no_requests:
        todo_g = [(g, js) for g, js in groups.values() if g.missing_translations()]
        if todo_g:
            n_lines = sum(len(g.missing_translations()) for g, _ in todo_g)
            say(f"▶ Kurgusal dil satırlarının Türkçesi hazırlanıyor ({n_lines} satır)...")
            counts = await asyncio.gather(*(engine.translate_conlang(g, js) for g, js in todo_g))
            for (g, _), n in zip(todo_g, counts):
                left = len(g.missing_translations())
                if n:
                    try:
                        g.save()
                    except OSError as e:
                        say(f"  ! sözlük kaydedilemedi: {e}")
                say(f"  {g.series}: {n} satırın Türkçesi eklendi"
                    + (f", {left} satır yalnızca orijinal gösterilecek" if left else ""))
    # Sözlük, aynen kalacak satırlar ve bölüm analizi artık belli: bölümler yeniden hazırlanır (API çağrısı yok)
    for j in jobs:
        engine.plan(j)
    if todo:
        log.debug("Sözlük aşaması %.1f sn sürdü", time.monotonic() - t0)


async def _translate_all(engine: Engine, jobs: list[FileJob], settings: Settings, shift: float) -> None:
    total = len(jobs)
    state = {"done": 0}
    price = settings.price(settings["provider"]["model"])
    bom = bool(settings["output"]["bom"])
    dst_dir = settings.path("target")
    report_on = bool(settings["output"].get("suspect_report", True))

    def write_job(job: FileJob) -> None:
        state["done"] += 1
        prefix = f"[{state['done']}/{total}]"
        for w in job.warnings:
            log.debug("%s: %s", job.rel, w)
        if job.status == "tamam":
            errs = verify_structure(job.srt.blocks, job.out_blocks, allow_empty=job.dropped)
            if errs:
                job.status = "başarısız"
                job.errors += errs
            else:
                blocks = engine.final_blocks(job)
                removed = len(job.out_blocks) - len(blocks)
                if removed:
                    job.warnings.append(f"yalnızca nottan oluşan {removed} blok silindi, numaralar yeniden verildi")
                if shift:
                    blocks, clipped = shift_blocks(blocks, shift)
                    if clipped:
                        job.warnings.append(f"kaydırmada {len(clipped)} blok 0'a kırpıldı: {clipped[:20]}")
                write_atomic(job.out_path, blocks, job.out_fmt, job.srt.doc, bom=bom)
                if engine.store is not None:
                    record_written(engine.store, job, blocks, dst_dir)
                if report_on:
                    write_suspects(engine, job, dst_dir)
        if job.status == "tamam":
            w = f"  ({len(job.warnings)} uyarı)" if job.warnings else ""
            say(f"{prefix} ✓ {job.rel.name} → {job.out_path.name} | {len(job.srt.blocks)} blok"
                + (f" ({len(job.srt.blocks) - len(job.dropped)} yazıldı)" if job.dropped and engine.final_blocks(job) is not job.out_blocks else "")
                + ", "
                f"{len(job.chunks)} parça, {fmt_tokens(job.usage.input_tokens + job.usage.output_tokens)} token, "
                f"{fmt_cost(job.usage.cost(price))}, {fmt_secs(job.elapsed)}{w}")
        else:
            for e in job.errors:
                log.debug("%s: HATA %s", job.rel, e)
            say(f"{prefix} ✗ {job.rel.name} BAŞARISIZ: {'; '.join(job.errors)[:160]}")

    progress = Progress(str(settings["output"].get("progress", "detailed")).lower(), price)
    engine.progress = progress
    if CONSOLE is not None:
        CONSOLE.progress = progress
    ticker = None
    try:
        # Önce anahtarı token harcamadan dene: yanlışsa hiçbir şey göndermeden dur
        check = getattr(engine.provider, "check", None)
        if check is not None:
            say("▶ API anahtarı ve model erişimi kontrol ediliyor...")
            try:
                say("  " + await check(strict=False))
            except ProviderError as e:
                raise FatalError(str(e)) from e
        await _build_glossaries(engine, jobs)
        n_chunks = sum(len(j.chunks) for j in jobs)
        order = "sırayla (kalite modu)" if engine.sequential else "paralel"
        if engine.review_only:
            say(f"▶ Yalnızca anlam kontrolü: {total} dosyanın kayıtlı çevirisi kontrol ediliyor")
        else:
            say(f"▶ Çeviri başladı: {total} dosya, {n_chunks} parça {order} gönderiliyor; "
                f"eşzamanlı istek {engine.limiter.limit}"
                + (" (otomatik artar/azalır)" if engine.limiter.maximum > engine.limiter.limit else ""))
        if engine.batch and not engine.review_only:
            await engine.prefill_batch(jobs, "translate", say)
        progress.begin(jobs, engine.limiter)

        async def tick():
            while True:
                await asyncio.sleep(0.5)
                progress.redraw()
        ticker = asyncio.create_task(tick())

        if engine.batch:
            # Toplu istek: önce tüm çeviriler, sonra anlam kontrolü tek toplu istekte
            await asyncio.gather(*(engine.translate_phase(j) for j in jobs))
            await engine.prefill_batch(jobs, "review", say)
            for job in jobs:
                await engine.finish_phase(job)
                write_job(job)
        else:
            async def one(job: FileJob) -> FileJob:
                await engine.translate_file(job)
                return job
            for fut in asyncio.as_completed([one(j) for j in jobs]):
                write_job(await fut)
    finally:
        if ticker is not None:
            ticker.cancel()
        progress.finish()
        if CONSOLE is not None:
            CONSOLE.progress = None
        for prov in {id(x): x for x in (engine.provider, engine.review_provider) if x is not None}.values():
            try:
                await prov.close()
            except Exception:  # noqa: BLE001
                pass
