"""Çeviri geldikten sonra Python'un yaptığı deterministik düzeltmeler (model çağrısı yok).

Hepsi tek yerden, `apply_fixes` ile uygulanır:
- sözlükteki özel adların büyük/küçük harfi ("tek yüzük" -> "Tek Yüzük")
- Türkçe: büyük harfli sözcükte kalan küçük i ("SAATLi" -> "SAATLİ")
- Türkçe: ırk adlarında kesme yok ("Elfler'e" -> "Elflere")
- Türkçe: çokluk ekinde kesme yok ("Proudfoot'lar" -> "Proudfootlar", TDK: Ahmetler)
- Türkçe: cins isimde kesme yok ("abla'ma" -> "ablama"), "Gaffer's'ın" -> "Gaffer'ın"
- Türkçe: kesme işareti tek tip (’ -> ')
"""
from __future__ import annotations

import re
from collections import Counter

from .textprep import norm_line

TAGS_STRIP_RE = re.compile(r"<[^>]+>|\{\\[^}]*\}")
# Büyük harfle yazılması gereken sözlük türleri (ırk ve genel terimler hariç: elf, hobbit)
CASE_TYPES = {"character", "place", "organization", "technique", "item", "title", "currency"}

_WORD_RE = re.compile(r"[A-Za-zÇĞİÖŞÜçğıöşü]+")
_L = r"[^\W\d_]"          # herhangi bir harf


def fix_tr_upper_i(text: str) -> str:
    """Büyük harfli Türkçe sözcükte kalan küçük 'i'yi 'İ' yapar: "SAATLi" -> "SAATLİ".
    ("iOS" gibi i ile başlayan adlara dokunmaz.)"""
    def fix(m: re.Match) -> str:
        w = m.group(0)
        if "i" in w[1:] and w[0] != "i" and sum(c.isupper() for c in w) >= 2 \
                and all(c.isupper() or c == "i" for c in w):
            return w.replace("i", "İ")
        return w
    return _WORD_RE.sub(fix, text)


def fix_term_case(text: str, terms: list[dict], src_counts: dict[str, int] | None = None) -> str:
    """Sözlükteki özel adın büyük/küçük harfini düzeltir: 'tek yüzük' -> 'Tek Yüzük'.

    src_counts (hedef yazım -> kaynakta kaç kez geçtiği) verilirse, çeviride kaynaktakinden
    fazla eşleşme varsa o terime dokunulmaz: "Doctor" adı ile "bir doktor" (cins isim)
    aynı blokta geçtiğinde cins isim büyük harfe çevrilmez."""
    for t in terms:
        tgt = t["target"]
        if t.get("type") not in CASE_TYPES or tgt == tgt.lower():
            continue
        pat = re.compile(r"(?<!\w)" + re.escape(tgt) + r"(?!\w)", re.I)
        if src_counts is not None and len(pat.findall(text)) > src_counts.get(tgt, 0):
            continue
        # BÜYÜK HARFLİ satırlara dokunma ("SHONEN JUMP PLUS'INDA", "PROJECT APPLE")
        text = pat.sub(lambda m: m.group(0) if m.group(0).isupper() else tgt, text)
    return text


def fix_tr_race_apostrophe(text: str, terms: list[dict]) -> str:
    """Irk adları Türkçede cins isimdir, eki kesmeyle ayrılmaz: "Elfler'e" -> "Elflere",
    "hobbit'in" -> "hobbitin"."""
    for t in terms:
        if t.get("type") != "race":
            continue
        stem = re.sub(r"(ler|lar)$", "", t["target"].split()[0].lower())
        if len(stem) < 3:
            continue
        text = re.sub(r"(?<!\w)(" + re.escape(stem) + r"\w*)['’](\w+)", r"\1\2", text, flags=re.I)
    return text


def fix_tr_apostrophes(text: str) -> str:
    """Kesme işaretini tek tip yapar (Grubb’un -> Grubb'un) ve çokluk ekinden önceki kesmeyi
    kaldırır: TDK'ya göre çokluk eki kesmeyle ayrılmaz (Proudfoot'lar -> Proudfootlar,
    Bolger'lara -> Bolgerlara). "Frodo'la" (ile) gibi ekler değişmez."""
    text = re.sub(rf"(?<={_L})’(?={_L})", "'", text)
    return re.sub(rf"(?<={_L})'(?=l[ae]r{_L}*(?!{_L}))", "", text)


_EN_CONTRACTIONS = {"s", "t", "re", "ll", "ve", "d", "m"}
_LOWER = "a-zçğıöşüâîû"
_COMMON_APOS_RE = re.compile(rf"(?<![\w'’\-])([{_LOWER}]{{2,}})'([{_LOWER}]{{1,6}})(?![\w'’])")


_BACK, _FRONT = "aıou", "eiöü"
# Ünlü uyumu yazımdan güvenle çıkarılabilen, sık geçen kurgu cins isimleri ("elf'ın" -> "elfin").
# "trol", "gol" gibi ince l ile biten ödünçlemeler yazıma uymadığı için listede yok.
HARMONY_STEMS = {"elf", "ork", "hobbit", "cüce", "goblin", "ejderha", "büyücü", "cadı"}


def harmonize_suffix(stem: str, suffix: str) -> str:
    """Ekin ünlülerini kökün son ünlüsüne uydurur: ("elf", "ın") -> "in", ("ork", "e") -> "a"."""
    vowels = [c for c in stem.lower() if c in _BACK + _FRONT]
    if not vowels:
        return suffix
    prev, out = vowels[-1], []
    for c in suffix:
        if c in "ae":
            c = "a" if prev in _BACK else "e"
        elif c in "ıiuü":
            c = {"a": "ı", "ı": "ı", "o": "u", "u": "u", "e": "i", "i": "i", "ö": "ü", "ü": "ü"}[prev]
        if c in _BACK + _FRONT:
            prev = c
        out.append(c)
    return "".join(out)


def _harmony_stems(terms: list[dict] | None) -> set[str]:
    """Bilinen kökler + sözlükteki küçük harfli cins isim hedefleri (çokluk eki atılmış: "elfler" -> "elf")."""
    stems = set(HARMONY_STEMS)
    for t in terms or ():
        tgt = t.get("target", "")
        if tgt and tgt == tgt.lower() and " " not in tgt and re.fullmatch(r"[a-zçğıöşü]+", tgt):
            stem = re.sub(r"l[ae]r$", "", tgt)
            if len(stem) >= 3 and not stem.endswith("l"):
                stems.add(stem)
    return stems


# Yalnızca bilinen ek dizileri (çokluk + hâl/iyelik): "orkestra", "elfçe" gibi sözcüklere dokunulmaz.
_SUFFIX_ONLY_RE = re.compile(r"(?=.)(?:l[ae]r)?(?:[ıiuü]n?|[ae]|[dt][ae]n?|l[ae]|y[ae]|yl[ae]|y[ıiuü]|n[ıiuü]n|nd[ae]n?|n[ae])?")


def fix_tr_common_apostrophe(text: str, terms: list[dict] | None = None) -> str:
    """Cins isme kesmeyle ek gelmez: "abla'ma" -> "ablama", "elf'in" -> "elfin";
    İngilizce iyelik + Türkçe ek: "Gaffer's'ın" -> "Gaffer'ın". Ünsüz yumuşaması gereken
    sözcüklere ("kitap'ı") ve "km'ye" gibi kısaltmalara dokunmaz.
    Bilinen kurgu cins isimlerinde (elf, ork, hobbit, sözlükteki ırklar) ekin ünlü uyumu da
    düzeltilir: model "elf'ın" ya da "elfın" yazsa da "elfin" olur."""
    text = re.sub(rf"({_L})'s'(?={_L})", r"\1'", text)
    stems = _harmony_stems(terms)

    def fix(m: re.Match) -> str:
        word, suf = m.group(1), m.group(2)
        if suf in _EN_CONTRACTIONS or not re.search(r"[aeıioöuüâîû]", word):
            return m.group(0)
        if word[-1] in "pçtk" and suf[0] in "aeıioöuüâîû":
            return m.group(0)
        return word + (harmonize_suffix(word, suf) if word in stems and _SUFFIX_ONLY_RE.fullmatch(suf) else suf)
    text = _COMMON_APOS_RE.sub(fix, text)

    def fix_bare(m: re.Match) -> str:
        word = m.group(0)
        low = word.lower()
        for stem in stems:
            if low.startswith(stem) and len(low) > len(stem) and _SUFFIX_ONLY_RE.fullmatch(low[len(stem):]):
                suf = word[len(stem):]
                good = harmonize_suffix(stem, suf.lower())
                if good != suf.lower() and suf.islower():
                    return word[:len(stem)] + good
        return word
    return re.sub(rf"(?<![\w'’\-])[{_LOWER}]{{4,}}(?![\w'’])", fix_bare, text)


_AFTER_BREAK_RE = re.compile(r"\n([a-zçğıöşü][^\W\d_]{2,})")


def fix_dropped_n(texts: list[str], keep_keys: set[str] = frozenset()) -> list[str]:
    """Model satır sonundan ("\\n") hemen sonra gelen sözcüğün baştaki n harfini bazen yutar:
    "yazı,\\neredeyse" (neredeyse). Satır başındaki küçük harfli sözcük dosyanın başka hiçbir yerinde
    geçmiyor ama başına "n" eklenmiş hâli geçiyorsa düzeltilir. Kurgusal dil satırlarına dokunulmaz."""
    words = Counter(w.lower() for t in texts for w in re.findall(r"[^\W\d_]+", TAGS_STRIP_RE.sub("", t)))

    def fix_text(t: str) -> str:
        def rep(m: re.Match) -> str:
            w = m.group(1)
            line_end = t.find("\n", m.end())
            line = t[m.start() + 1: line_end if line_end >= 0 else len(t)]
            if norm_line(line) in keep_keys:
                return m.group(0)
            if words[w.lower()] == 1 and words["n" + w.lower()] >= 1:
                return "\nn" + w
            return m.group(0)
        return _AFTER_BREAK_RE.sub(rep, t)
    return [fix_text(t) if "\n" in t else t for t in texts]


def apply_fixes(text: str, terms: list[dict], lang: str, src_counts: dict[str, int] | None = None) -> str:
    """Bir bloğun çevirisine tüm deterministik düzeltmeleri uygular."""
    text = fix_term_case(text, terms, src_counts)
    if lang.lower().startswith("tr"):
        text = fix_tr_common_apostrophe(fix_tr_apostrophes(fix_tr_race_apostrophe(fix_tr_upper_i(text), terms)), terms)
    return text
