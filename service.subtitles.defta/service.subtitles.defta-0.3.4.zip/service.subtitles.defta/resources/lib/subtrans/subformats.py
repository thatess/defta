"""SRT dışındaki altyazı biçimleri: ASS / SSA ve WebVTT okuma-yazma.

Hepsi aynı iç yapıya (Block listesi) çevrilir; çeviri motoru biçimi bilmez. Zaman kodları ve
sıra hiçbir zaman değişmez. ASS'te stil, konum ve efekt bilgileri kaynaktaki gibi korunur,
yalnızca metin alanı değişir.

- ASS yorum satırları (Comment:) çevrilmez, olduğu gibi kalır.
- Çizim satırları ({\\p1} ...) çevrilmez.
- Tabela / şarkı stilleri ve \\pos ile yerleştirilmiş yazılar satır düzeni bozulmasın diye
  yeniden satırlara bölünmez.
- Aynı zamanda aynı metni taşıyan katman kopyaları (gölge/parlama katmanları) bir kez çevrilir.
"""
from __future__ import annotations

import html
import os
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from .srt_io import Block, SrtFile, detect_and_decode, format_ms, parse_srt_text, render_srt

SUPPORTED_EXTS = (".srt", ".ass", ".ssa", ".vtt")

_ASS_TIME_RE = re.compile(r"^\s*(\d+):(\d{1,2}):(\d{1,2})[.:](\d{1,3})\s*$")
_OVERRIDE_RE = re.compile(r"\{[^}]*\}")
_SIGN_STYLE_RE = re.compile(r"(?i)sign|title|\bop\b|\bed\b|opening|ending|song|kara|lyric|insert|note|screen|"
                            r"typeset|logo|caption|^op|^ed")
_PLACED_RE = re.compile(r"\\(?:pos|move|org|clip|iclip)\s*\(")
_DRAWING_RE = re.compile(r"\\p[1-9]")
_KARAOKE_RE = re.compile(r"\\(?:k|K|kf|ko)\d+")


@dataclass
class AssEvent:
    line_no: int                # dosyadaki satır numarası
    kind: str                   # "Dialogue"
    fields: list[str]           # Text dışındaki alanlar (Format sırasıyla)
    style: str
    raw_text: str


@dataclass
class SubDoc:
    """Biçime özgü, yazarken gereken bilgiler."""
    fmt: str                                   # srt | ass | ssa | vtt
    lines: list[str] = field(default_factory=list)       # ASS: dosyanın tüm satırları
    fmt_fields: list[str] = field(default_factory=list)  # ASS: [Events] Format alanları
    events: list[AssEvent] = field(default_factory=list)  # blok pos -> olay
    nowrap: set[int] = field(default_factory=set)         # yeniden satıra bölünmeyecek bloklar
    drawing: set[int] = field(default_factory=set)        # çizim: çevrilmez
    vtt_header: list[str] = field(default_factory=list)   # WEBVTT satırı + STYLE / REGION blokları


# ---------------------------------------------------------------- genel

def read_subtitle(path: Path) -> SrtFile:
    raw = path.read_bytes()
    text, enc, bom, conf = detect_and_decode(raw)
    ext = path.suffix.lower()
    if ext in (".ass", ".ssa"):
        blocks, warnings, doc = parse_ass(text, ext[1:])
    elif ext == ".vtt":
        blocks, warnings, doc = parse_vtt(text)
    else:
        blocks, warnings = parse_srt_text(text)
        doc = SubDoc(fmt="srt")
    f = SrtFile(path=path, blocks=blocks, encoding=enc, had_bom=bom, encoding_confidence=conf, warnings=warnings)
    f.doc = doc
    return f


def output_format(src_fmt: str, wanted: str) -> str:
    w = (wanted or "srt").lower().strip()
    if w in ("kaynak", "source", "same", "orijinal"):
        return "ass" if src_fmt == "ass" else ("ssa" if src_fmt == "ssa" else src_fmt)
    if w == "ass" and src_fmt == "ssa":
        return "ssa"           # SSA kaynağı kendi biçiminde yazılır (stil satırları uyumlu kalsın)
    return w if w in ("srt", "ass", "vtt") else "srt"


def render(blocks: list[Block], fmt: str, doc: SubDoc | None) -> str:
    if fmt in ("ass", "ssa"):
        return render_ass(blocks, doc if doc is not None and doc.fmt in ("ass", "ssa") else None)
    if fmt == "vtt":
        return render_vtt(blocks, doc if doc is not None and doc.fmt == "vtt" else None)
    return render_srt([Block(b.pos, b.index, b.start_ms, b.end_ms, strip_ass_codes_for_srt(b.text), b.tail)
                       for b in blocks]) if doc is not None and doc.fmt in ("ass", "ssa") else render_srt(blocks)


def write_atomic(path: Path, blocks: list[Block], fmt: str, doc: SubDoc | None, bom: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = render(blocks, fmt, doc)
    data = text.replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8")
    if bom:
        data = b"\xef\xbb\xbf" + data
    fd, tmp = tempfile.mkstemp(prefix=".tmp_", suffix=path.suffix, dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def strip_ass_codes_for_srt(text: str) -> str:
    """ASS'ten SRT'ye: {\\an8} gibi konum kodu dışındaki ASS kodları kaldırılır."""
    return re.sub(r"\{(?!\\an\d\})[^}]*\}", "", text)


# ---------------------------------------------------------------- ASS / SSA

def _ass_ms(s: str) -> int | None:
    m = _ASS_TIME_RE.match(s)
    if not m:
        return None
    h, mi, se, frac = m.groups()
    return ((int(h) * 60 + int(mi)) * 60 + int(se)) * 1000 + int(frac.ljust(3, "0")[:3])


def _ass_time(ms: int) -> str:
    ms = max(0, ms)
    cs = (ms + 5) // 10
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, c = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{c:02d}"


def ass_to_text(t: str) -> tuple[str, bool]:
    """ASS metin alanı -> iç metin. (metin, çizim mi)."""
    drawing = False
    out, pos, leading = [], 0, True
    for m in _OVERRIDE_RE.finditer(t):
        chunk = t[pos:m.start()]
        if chunk:
            leading = False
        out.append(chunk)
        body = m.group(0)[1:-1]
        pos = m.end()
        if "\\" not in body:
            continue                      # {yorum} blokları
        if _DRAWING_RE.search(body):
            drawing = True
        body = _KARAOKE_RE.sub("", body)
        tags = []
        for tag, html_tag in (("i", "i"), ("b", "b"), ("u", "u")):
            for mm in re.finditer(r"\\" + tag + r"([01])(?![0-9])", body):
                tags.append(f"<{html_tag}>" if mm.group(1) == "1" else f"</{html_tag}>")
            body = re.sub(r"\\" + tag + r"[01](?![0-9])", "", body)
        rest = body.strip()
        if leading and rest and rest != "\\":
            out.append("{" + rest + "}")      # baştaki konum/efekt kodu korunur
        out.extend(tags)
    out.append(t[pos:])
    s = "".join(out)
    s = s.replace("\\N", "\n").replace("\\n", " ").replace("\\h", "\u00a0")
    s = "\n".join(ln.rstrip() for ln in s.split("\n"))
    return s.strip("\n"), drawing


def text_to_ass(s: str) -> str:
    s = s.replace("\r", "")
    for a, b in (("<i>", "{\\i1}"), ("</i>", "{\\i0}"), ("<b>", "{\\b1}"), ("</b>", "{\\b0}"),
                 ("<u>", "{\\u1}"), ("</u>", "{\\u0}")):
        s = re.sub(re.escape(a), b.replace("\\", "\\\\"), s, flags=re.I)
    s = re.sub(r"</?[a-zA-Z][^>]*>", "", s)          # <font> vb.
    s = s.replace("}{", "")                           # {\an8}{\i1} -> {\an8\i1}
    return s.replace("\n", "\\N")


def parse_ass(text: str, fmt: str = "ass") -> tuple[list[Block], list[str], SubDoc]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    doc = SubDoc(fmt=fmt, lines=lines)
    warnings: list[str] = []
    blocks: list[Block] = []
    section = ""
    fmt_fields: list[str] = []
    for no, ln in enumerate(lines):
        st = ln.strip()
        if st.startswith("[") and st.endswith("]"):
            section = st.lower()
            continue
        if section != "[events]":
            continue
        if st.lower().startswith("format:"):
            fmt_fields = [x.strip().lower() for x in st.split(":", 1)[1].split(",")]
            doc.fmt_fields = fmt_fields
            continue
        if not st.lower().startswith("dialogue:"):
            continue                       # Comment:, Picture:, Sound: ... aynen kalır
        if not fmt_fields:
            fmt_fields = ["layer", "start", "end", "style", "name", "marginl", "marginr", "marginv", "effect", "text"]
            if fmt == "ssa":
                fmt_fields[0] = "marked"
            doc.fmt_fields = fmt_fields
        body = ln.split(":", 1)[1]
        if body.startswith(" "):
            body = body[1:]
        parts = body.split(",", len(fmt_fields) - 1)
        if len(parts) < len(fmt_fields):
            warnings.append(f"Satır {no + 1}: eksik alanlı Dialogue satırı atlandı")
            continue
        get = dict(zip(fmt_fields, parts))
        start, end = _ass_ms(get.get("start", "")), _ass_ms(get.get("end", ""))
        if start is None or end is None:
            warnings.append(f"Satır {no + 1}: zaman okunamadı, satır çevrilmeyecek")
            continue
        raw = get.get("text", "")
        txt, drawing = ass_to_text(raw)
        pos = len(blocks)
        style = get.get("style", "").strip()
        ev = AssEvent(line_no=no, kind="Dialogue", fields=parts[:-1], style=style, raw_text=raw)
        doc.events.append(ev)
        blocks.append(Block(pos=pos, index=pos + 1, start_ms=start, end_ms=end, text=txt))
        if drawing:
            doc.drawing.add(pos)
        if _SIGN_STYLE_RE.search(style) or _PLACED_RE.search(raw):
            doc.nowrap.add(pos)
    if not blocks:
        warnings.append("ASS dosyasında Dialogue satırı bulunamadı")
    return blocks, warnings, doc


_DEFAULT_ASS_HEADER = """[Script Info]
; Altyazı çevirici ile oluşturuldu
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,72,&H00FFFFFF,&H000000FF,&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,3.5,1.5,2,60,60,50,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"""


def render_ass(blocks: list[Block], doc: SubDoc | None) -> str:
    if doc is None or not doc.events:
        out = [_DEFAULT_ASS_HEADER]
        for b in blocks:
            out.append(f"Dialogue: 0,{_ass_time(b.start_ms)},{_ass_time(b.end_ms)},Default,,0,0,0,,{text_to_ass(b.text)}")
        return "\n".join(out) + "\n"
    by_pos = {b.pos: b for b in blocks}
    ev_line = {ev.line_no: (pos, ev) for pos, ev in enumerate(doc.events)}
    fields = doc.fmt_fields
    i_start = fields.index("start") if "start" in fields else 1
    i_end = fields.index("end") if "end" in fields else 2
    out = []
    for no, ln in enumerate(doc.lines):
        hit = ev_line.get(no)
        if hit is None:
            out.append(ln)
            continue
        pos, ev = hit
        b = by_pos.get(pos)
        if b is None:
            continue                       # silinen blok (yalnızca nottan oluşuyordu)
        f = list(ev.fields)
        if i_start < len(f):
            f[i_start] = _ass_time(b.start_ms)
        if i_end < len(f):
            f[i_end] = _ass_time(b.end_ms)
        text = ev.raw_text if pos in doc.drawing else text_to_ass(b.text)
        out.append("Dialogue: " + ",".join(f + [text]))
    while out and not out[-1].strip():
        out.pop()
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- WebVTT

_VTT_TC_RE = re.compile(r"^\s*((?:\d+:)?\d{1,2}:\d{2}[.,]\d{1,3})\s+-->\s+((?:\d+:)?\d{1,2}:\d{2}[.,]\d{1,3})(.*)$")


def _vtt_ms(s: str) -> int:
    s = s.replace(",", ".")
    main, frac = s.split(".")
    parts = [int(x) for x in main.split(":")]
    while len(parts) < 3:
        parts.insert(0, 0)
    h, m, sec = parts
    return ((h * 60 + m) * 60 + sec) * 1000 + int(frac.ljust(3, "0")[:3])


def _vtt_time(ms: int) -> str:
    return format_ms(ms).replace(",", ".")


def vtt_to_text(t: str) -> str:
    t = re.sub(r"<v(?:\.[^ >]*)?\s+([^>]+)>", lambda m: f"({m.group(1).strip()}) ", t)
    t = re.sub(r"<rt>.*?</rt>", "", t, flags=re.S)
    t = re.sub(r"</?(?:v|c|ruby|rt|lang)(?:[.\s][^>]*)?>", "", t)
    t = re.sub(r"<\d{1,2}:\d{2}(?::\d{2})?\.\d{3}>", "", t)
    return html.unescape(t)


def text_to_vtt(s: str) -> str:
    s = re.sub(r"\{\\[^}]*\}", "", s)
    keep = []

    def stash(m):
        keep.append(m.group(0))
        return f"\x00{len(keep) - 1}\x00"
    s = re.sub(r"</?(?:i|b|u)>", stash, s, flags=re.I)
    s = re.sub(r"</?[a-zA-Z][^>]*>", "", s)
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = re.sub(r"\x00(\d+)\x00", lambda m: keep[int(m.group(1))].lower(), s)
    s = "\n".join(ln for ln in s.split("\n") if ln.strip())   # boş satır cue'yu bitirir
    return s.replace("-->", "->")


def parse_vtt(text: str) -> tuple[list[Block], list[str], SubDoc]:
    text = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    chunks = re.split(r"\n\s*\n", text)
    doc = SubDoc(fmt="vtt")
    warnings: list[str] = []
    blocks: list[Block] = []
    for k, ch in enumerate(chunks):
        lines = [ln for ln in ch.split("\n")]
        while lines and not lines[0].strip():
            lines.pop(0)
        if not lines:
            continue
        head = lines[0].strip()
        if k == 0 and head.startswith("WEBVTT"):
            doc.vtt_header.append("\n".join(lines))
            continue
        if head.startswith("NOTE"):
            continue
        if head.startswith("STYLE") or head.startswith("REGION"):
            if not blocks:
                doc.vtt_header.append("\n".join(lines))
            continue
        ti = next((i for i, ln in enumerate(lines[:2]) if _VTT_TC_RE.match(ln)), None)
        if ti is None:
            warnings.append(f"Zaman kodu olmayan bölüm atlandı: {head[:40]!r}")
            continue
        m = _VTT_TC_RE.match(lines[ti])
        start, end = _vtt_ms(m.group(1)), _vtt_ms(m.group(2))
        body = "\n".join(ln.rstrip() for ln in lines[ti + 1:] if ln.strip())
        pos = len(blocks)
        blocks.append(Block(pos=pos, index=pos + 1, start_ms=start, end_ms=end, text=vtt_to_text(body),
                            tail=(" " + m.group(3).strip()) if m.group(3).strip() else ""))
    if not doc.vtt_header:
        doc.vtt_header = ["WEBVTT"]
    return blocks, warnings, doc


def render_vtt(blocks: list[Block], doc: SubDoc | None) -> str:
    head = doc.vtt_header if doc is not None and doc.vtt_header else ["WEBVTT"]
    parts = list(head)
    for b in blocks:
        tail = b.tail if doc is not None else ""     # SRT'deki X1: konum bilgisi VTT'de geçersiz
        parts.append(f"{_vtt_time(b.start_ms)} --> {_vtt_time(b.end_ms)}{tail}\n{text_to_vtt(b.text)}")
    return "\n\n".join(parts) + "\n"


def output_path(base: Path, fmt: str) -> Path:
    """`X.tr.srt` adını istenen biçimin uzantısına çevirir."""
    return base.with_suffix("." + ("ssa" if fmt == "ssa" else fmt))
