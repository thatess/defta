"""SRT okuma/yazma: encoding tespiti, toleranslı parser, atomik yazma.

Altın kural: Bu modül zaman kodlarını ve sıra numaralarını olduğu gibi taşır.
Çeviri sırasında yalnızca Block.text değişir.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    import charset_normalizer
except ImportError:  # Kodi: kütüphane yoksa UTF-8 / UTF-16 / cp1252-cp1254 tahmini
    charset_normalizer = None

TIMECODE_RE = re.compile(
    r"^\s*(\d{1,3}):(\d{1,2}):(\d{1,2})[,.:](\d{1,3})\s*-->\s*"
    r"(\d{1,3}):(\d{1,2}):(\d{1,2})[,.:](\d{1,3})(.*)$"
)
INDEX_RE = re.compile(r"^\s*\d+\s*$")


@dataclass
class Block:
    """Tek bir altyazı bloğu. `pos` dosya içindeki değişmez dahili ID'dir (0'dan başlar)."""
    pos: int
    index: int
    start_ms: int
    end_ms: int
    text: str
    tail: str = ""  # zaman kodundan sonra gelen ek bilgi (nadiren: X1:... konum bilgisi)


@dataclass
class SrtFile:
    path: Path
    blocks: list[Block]
    encoding: str
    had_bom: bool
    encoding_confidence: float
    warnings: list[str] = field(default_factory=list)
    doc: object = None          # biçime özgü bilgiler (subformats.SubDoc); SRT'de None olabilir


# ---------------------------------------------------------------- zaman kodu

def _to_ms(h: str, m: str, s: str, frac: str) -> int:
    # "5" -> 500 ms, "50" -> 500 ms, "500" -> 500 ms (ondalık kesir olarak yorumlanır)
    ms = int(frac.ljust(3, "0")[:3])
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + ms


def format_ms(ms: int) -> str:
    if ms < 0:
        ms = 0
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, rem = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{rem:03d}"


# ---------------------------------------------------------------- encoding

# Altyazılarda pratikte görülen kod sayfaları (UTF-8 dışı)
_CANDIDATE_CODEPAGES = [
    "cp1252", "cp1254", "cp1250", "cp1251", "cp1253", "cp1255", "cp1256", "cp1257",
    "iso8859_9", "koi8_r", "cp874", "shift_jis", "euc_jp", "gb18030", "big5", "cp949",
]
_LATIN_SINGLE_BYTE = {"cp1252", "cp1254", "cp1250", "cp1257", "iso8859_9", "latin_1", "iso8859_1"}
_COMMON_ACCENTS = set("àâäçèéêëîïôöùûüÿñáíóúãõßğşıİĞŞÇÖÜÉÀÈÂÊÔÑÁÍÓÚ")
_OTHER_ACCENTS = set("čšžřěůąęłśźżćńőűåæøœýťďňľĺŕēāīūģķļņėįųČŠŽŘĚŮĄĘŁŚŹŻĆŃŐŰÅÆØŒÝ")
_JUNK = set("¤¦¨´¸¹º¼½¾þðÞÐ×÷µ¶§¬¯±²³")


def _latin_plausibility(text: str) -> float:
    score = 0.0
    for ch in text:
        if ord(ch) < 128:
            continue
        if ch in _COMMON_ACCENTS:
            score += 3
        elif ch in _OTHER_ACCENTS:
            score += 2
        elif ch in _JUNK:
            score -= 4
    return score


_CJK = {"shift_jis", "euc_jp", "gb18030", "big5", "cp949", "cp932", "euc_kr", "gbk", "gb2312"}


def _cjk_coherence(text: str) -> float:
    """Metnin tek bir doğu Asya yazı sistemine ne kadar tutarlı uyduğu (0..1)."""
    def kind(ch):
        o = ord(ch)
        if 0x3040 <= o <= 0x30FF:
            return "kana"
        if 0xAC00 <= o <= 0xD7A3 or 0x1100 <= o <= 0x11FF or 0x3130 <= o <= 0x318F:
            return "hangul"
        if 0x4E00 <= o <= 0x9FFF:
            return "han"
        if 0x3000 <= o <= 0x303F or 0xFF00 <= o <= 0xFFEF:
            return "punct"
        return "other"
    counts: dict[str, int] = {}
    total = 0
    for ch in text:
        if ord(ch) < 128 or ch.isspace():
            continue
        k = kind(ch)
        counts[k] = counts.get(k, 0) + 1
        total += 1
    if not total:
        return 0.0
    g = lambda *ks: sum(counts.get(k, 0) for k in ks)  # noqa: E731
    ja = g("kana", "han", "punct") / total + (0.2 if counts.get("kana") else 0)
    ko = g("hangul", "punct") / total
    zh = g("han", "punct") / total
    return max(ja, ko, zh)


def _pick_best(results):
    """charset-normalizer kısa metinlerde Batı Avrupa kod sayfalarını karıştırabiliyor
    (örn. Fransızcayı cp1257 sanmak). Neredeyse eşit puanlı Latin adayları arasında
    harf sıklığına göre seçim yapar."""
    if not results:
        return None
    top = results[0]
    if top.encoding in _CJK:
        cands = [r for r in results if r.encoding in _CJK]
        return max(cands, key=lambda r: (_cjk_coherence(str(r)), -r.chaos))
    ties = [r for r in results if r.encoding in _LATIN_SINGLE_BYTE
            and abs(r.chaos - top.chaos) <= 0.05]
    if top.encoding in _LATIN_SINGLE_BYTE and len(ties) > 1:
        return max(ties, key=lambda r: (_latin_plausibility(str(r)), -r.chaos))
    return top


def _fallback_decode(raw: bytes) -> tuple[str, str, bool, float]:
    """charset-normalizer olmadan: Türkçe izleri varsa cp1254, Kiril/Yunan/Arap ise ilgili kod sayfası, yoksa cp1252."""
    cands = []
    for enc in ("cp1254", "cp1252", "cp1251", "cp1253", "cp1256", "cp1250", "shift_jis", "gbk", "euc_kr"):
        try:
            text = raw.decode(enc)
        except UnicodeDecodeError:
            continue
        letters = sum(ch.isalpha() for ch in text) or 1
        odd = len(re.findall(r"[\x80-\xbf\u0080-\u00bf\u2020-\u2122\ufffd]", text))
        score = odd / letters
        if enc == "cp1254":
            score -= 0.002 * len(re.findall(r"[ğĞşŞıİ]", text))
        cands.append((score, enc, text))
    if not cands:
        return raw.decode("cp1254", errors="replace"), "cp1254", False, 0.3
    score, enc, text = min(cands, key=lambda c: c[0])
    return text, enc, False, 0.6


def detect_and_decode(raw: bytes) -> tuple[str, str, bool, float]:
    """(metin, encoding, BOM var mı, güven) döndürür.

    Önce katı UTF-8 denenir (en yaygın ve en güvenli). Olmazsa charset-normalizer,
    o da başarısız olursa Türkçe için Windows-1254 kullanılır.
    """
    had_bom = raw.startswith(b"\xef\xbb\xbf")
    if had_bom:
        raw_body = raw[3:]
    else:
        raw_body = raw
    try:
        return raw_body.decode("utf-8"), "utf-8", had_bom, 1.0
    except UnicodeDecodeError:
        pass

    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        try:
            return raw.decode("utf-16"), "utf-16", True, 1.0
        except UnicodeDecodeError:
            pass

    if charset_normalizer is None:
        return _fallback_decode(raw)
    results = list(charset_normalizer.from_bytes(raw, cp_isolation=_CANDIDATE_CODEPAGES))
    best = _pick_best(results)
    if best is not None:
        enc = best.encoding
        text = str(best)
        # charset-normalizer kısa Türkçe dosyaları sık sık cp1252/cp1250 sanar. Yanlış
        # çözülmüş Türkçenin izleri (ý þ ð Ý Þ Ð Ţ ţ đ) varsa ve cp1254 ile Türkçe
        # harfler (ı ş ğ İ Ş Ğ) çıkıyorsa cp1254'ü tercih et.
        if enc not in ("cp1254", "iso8859_9"):
            try:
                alt = raw.decode("cp1254")
                tr_hits = len(re.findall(r"[ğĞşŞıİ]", alt))
                junk = len(re.findall(r"[ýþðÝÞÐŢţđĐ]", text))
                if tr_hits and junk:
                    return alt, "cp1254", False, 0.85
            except UnicodeDecodeError:
                pass
        conf = 1.0 - float(getattr(best, "chaos", 0.0))
        return text, enc, False, max(0.0, min(1.0, conf))

    return raw.decode("cp1254", errors="replace"), "cp1254", False, 0.3


# ---------------------------------------------------------------- parse

def parse_srt_text(text: str) -> tuple[list[Block], list[str]]:
    """Toleranslı SRT parser. (bloklar, uyarılar) döndürür.

    Desteklenen bozukluklar: eksik/fazla boş satır, eksik veya sırasız numara,
    milisaniyede nokta, CRLF/LF karışıklığı, dosya sonunda eksik boş satır.
    """
    warnings: list[str] = []
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    n = len(lines)

    # Önce tüm zaman kodu satırlarını bul
    tc_lines = [i for i, ln in enumerate(lines) if TIMECODE_RE.match(ln)]
    blocks: list[Block] = []
    used_indices: set[int] = set()

    for k, li in enumerate(tc_lines):
        m = TIMECODE_RE.match(lines[li])
        assert m
        start = _to_ms(*m.group(1, 2, 3, 4))
        end = _to_ms(*m.group(5, 6, 7, 8))
        tail = m.group(9).rstrip()

        # Bir önceki satır sadece sayıysa o bloğun numarasıdır
        index = None
        if li > 0 and INDEX_RE.match(lines[li - 1]):
            index = int(lines[li - 1].strip())

        # Metin: bir sonraki zaman kodu satırına kadar (onun numara satırı hariç)
        stop = tc_lines[k + 1] if k + 1 < len(tc_lines) else n
        if k + 1 < len(tc_lines) and stop - 1 > li and INDEX_RE.match(lines[stop - 1]):
            stop -= 1
        text_lines = [ln.rstrip() for ln in lines[li + 1:stop]]
        # Baştaki/sondaki boş satırları at, aradaki boş satırları da at
        text_lines = [ln for ln in text_lines if ln.strip() != ""]

        if index is None:
            index = (blocks[-1].index + 1) if blocks else 1
            warnings.append(f"Satır {li + 1}: blok numarası eksik, {index} atandı")
        if index in used_indices:
            warnings.append(f"Satır {li + 1}: blok numarası {index} tekrar ediyor")
        used_indices.add(index)
        if end < start:
            warnings.append(f"Satır {li + 1}: bitiş zamanı başlangıçtan önce")
        if not text_lines:
            warnings.append(f"Satır {li + 1}: blok {index} metinsiz")

        blocks.append(Block(pos=len(blocks), index=index, start_ms=start, end_ms=end,
                            text="\n".join(text_lines), tail=tail))

    # Zaman kodu satırına bağlanmayan metin var mı? (ilk zaman kodundan önceki içerik)
    if tc_lines:
        orphan = [ln for ln in lines[:tc_lines[0]] if ln.strip() and not INDEX_RE.match(ln)]
        if orphan:
            warnings.append(f"Dosya başında zaman kodu olmayan {len(orphan)} satır yok sayıldı")
    return blocks, warnings


# ---------------------------------------------------------------- yazma

def render_srt(blocks: list[Block]) -> str:
    parts = []
    for b in blocks:
        tc = f"{format_ms(b.start_ms)} --> {format_ms(b.end_ms)}{b.tail}"
        parts.append(f"{b.index}\n{tc}\n{b.text}\n")
    return "\n".join(parts)


# ---------------------------------------------------------------- adlandırma

_LANG_CODES = {
    "en", "eng", "english", "tr", "tur", "turkish", "ja", "jpn", "jp", "de", "ger", "deu",
    "fr", "fre", "fra", "es", "spa", "it", "ita", "pt", "por", "ru", "rus", "ar", "ara",
    "zh", "chi", "zho", "ko", "kor", "nl", "dut", "pl", "pol", "sv", "swe", "fi", "fin",
    "no", "nor", "da", "dan", "el", "gre", "he", "heb", "fa", "per", "hi", "hin", "id",
    "ind", "th", "tha", "vi", "vie", "uk", "ukr", "cs", "cze", "hu", "hun", "ro", "rum",
    "sdh", "forced", "cc",
}


def output_name(src: Path, target_lang: str) -> str:
    """`Dizi.S01E01.srt` -> `Dizi.S01E01.tr.srt`; `Dizi.S01E01.en.srt` -> `Dizi.S01E01.tr.srt`."""
    stem = src.stem
    parts = stem.split(".")
    # Sondaki dil/etiket parçalarını at (örn. .en, .en.sdh, .eng.forced)
    while len(parts) > 1 and parts[-1].lower() in _LANG_CODES:
        parts.pop()
    return ".".join(parts) + f".{target_lang.lower()}.srt"


def verify_structure(src: list[Block], out: list[Block], allow_empty: set[int] | None = None) -> list[str]:
    """Kaynak ve çıktıyı birebir karşılaştırır. Boş liste = sorun yok.
    allow_empty: bilerek boşaltılan blokların pos değerleri (yalnızca nottan oluşanlar)."""
    allow_empty = allow_empty or set()
    errors = []
    if len(src) != len(out):
        errors.append(f"Blok sayısı farklı: kaynak {len(src)}, çıktı {len(out)}")
        return errors
    for a, b in zip(src, out):
        if a.index != b.index:
            errors.append(f"Blok {a.pos + 1}: numara değişmiş ({a.index} -> {b.index})")
        if a.start_ms != b.start_ms or a.end_ms != b.end_ms:
            errors.append(f"Blok {a.index}: zaman kodu değişmiş")
        if a.text.strip() and not b.text.strip() and a.pos not in allow_empty:
            errors.append(f"Blok {a.index}: çeviri boş")
        if len(errors) > 20:
            errors.append("... (diğer hatalar kesildi)")
            break
    return errors
