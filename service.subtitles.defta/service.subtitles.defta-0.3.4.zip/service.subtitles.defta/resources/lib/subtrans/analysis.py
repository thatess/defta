"""Bölüm analizi: sözlük terimleri, kurgusal dil satırları ve anlamları, sahne özetleri."""
from __future__ import annotations

from typing import TYPE_CHECKING

import asyncio
import logging
import time

from .config import lang_name
from .glossary import (ANALYSIS_SCHEMA, ANALYSIS_TASKS, CONLANG_SCHEMA, CONLANG_SYSTEM, EXTRACT_SYSTEM,
                       GLOSSARY_SCHEMA, Glossary, conlang_candidate, conlang_payload, extract_payload,
                       english_vocab, filter_keep_refs, looks_english, parse_analysis, parse_terms)
from .postfix import TAGS_STRIP_RE
from .prompts import names_rule
from .provider import ProviderError
from .textprep import (conlang_key, conlang_lines, find_conlang, has_letters, norm_line)
from .common import FatalError, same_words

if TYPE_CHECKING:
    from .engine import FileJob

log = logging.getLogger("subtrans")


class AnalysisMixin:
    # ------------------------------------------------------------ sözlük

    def _glossary_lines(self, job: FileJob) -> tuple[list[tuple[str, str]], dict[str, str]]:
        """(referans, gösterilecek metin) listesi ve referans -> kaynak satır eşlemesi."""
        rows, raw = [], {}
        for i in job.translate_pos:
            p = job.prepared[i]
            who = ", ".join(p.speakers)
            for li, line in enumerate(p.send_text.split("\n"), 1):
                if not line.strip():
                    continue
                ref = f"{i + 1}.{li}"
                raw[ref] = line
                rows.append((ref, f"({who}) {line}" if who and li == 1 else line))
        return rows, raw

    def _glossary_system(self, job: FileJob, full: bool | None = None) -> str:
        """full=True: bölüm analizi (sözlük + Elfçe anlamları + sahne özetleri + hitap biçimi)."""
        dec = job.decisions or self.decisions
        tgt = self.rules.name if not self.rules.is_default else lang_name(self.rules.code)
        names = "  * " + names_rule(dec, tgt).split(". ", 1)[1].replace("\n", "\n  ")
        series = job.glossary.series if job.glossary else job.series
        if full is None:
            full = self.analysis_on
        tasks = ANALYSIS_TASKS.replace("{tgt}", tgt) if full else ""
        more = (', "keep_meanings": [...], "scenes": [{{"from_id": 1, "to_id": 40, "summary": "..."}}], '
                '"address": [...]' if full else "")
        return EXTRACT_SYSTEM.format(series=series, src=lang_name(job.src_lang), tgt=tgt, names=names,
                                     tasks=tasks, more=more.replace("{{", "{").replace("}}", "}"))

    async def translate_conlang(self, g: Glossary, jobs: list[FileJob]) -> int:
        """Sözlükte Türkçesi olmayan Elfçe satırların anlamını tek istekle sorar ve sözlüğe yazar.
        Dönüş: eklenen çeviri sayısı. Hata olursa 0 (satırlar yalnızca Elfçe gösterilir).
        Anlamı yanındaki blokta zaten yazıyorsa bunu _assemble kodla anlar ve altına eklemez."""
        missing = g.missing_translations()
        if not missing:
            return 0
        got = await self._ask_conlang(g, jobs, missing)
        added = 0
        for ln, (tr, _is_conlang) in got.items():
            if tr:
                g.keep_tr[ln] = tr
                added += 1
        return added

    async def _ask_conlang(self, g: Glossary, jobs: list[FileJob], lines: list[str]
                           ) -> dict[str, tuple[str, bool]]:
        """{satır: (çeviri, kurgusal dil mi)}. Hata olursa boş sözlük."""
        if not lines or self.provider is None:
            return {}
        strip = lambda t: TAGS_STRIP_RE.sub("", t).replace("\n", " ").strip()  # noqa: E731
        # Bağlam: satırın geçtiği bloktan önceki/sonraki iki blok (kaynak metin).
        # Kaynak anlamı satırın yanında ya da altında veriyorsa ("Tangado haid! (Hold positions!)",
        # "Namárië.\n(Farewell.)") o anlam kullanılır.
        # Tüm bölümler tek kez taranır: anahtar -> ilk geçtiği yer (anlamı verilen yer tercih edilir)
        index: dict[str, tuple] = {}
        for j in jobs:
            for k, b in enumerate(j.srt.blocks):
                raw_lines = b.text.split("\n")
                for i, key, gl, gi in conlang_lines(raw_lines):
                    if key and (key not in index or (gl and not index[key][4])):
                        index[key] = (j.srt.blocks, k, raw_lines, i, gl, gi)
        contexts, hints = [], []
        for ln in lines:
            hit = index.get(conlang_key(ln))
            if hit is None:
                contexts.append(([], []))
                hints.append("")
                continue
            blocks, k, raw_lines, i, gl, gi = hit
            others = [x for n, x in enumerate(raw_lines) if n not in (i, gi) and norm_line(x)]
            contexts.append(([strip(x.text) for x in blocks[max(0, k - 2):k]] + [strip(x) for x in others],
                             [strip(x.text) for x in blocks[k + 1:k + 3]]))
            hints.append(gl)
        tgt = self.rules.name if not self.rules.is_default else lang_name(self.rules.code)
        system = CONLANG_SYSTEM.format(series=g.series, tgt=tgt)
        seen = " ".join(lines + hints + [x for b, a in contexts for x in b + a])
        user = conlang_payload(lines, contexts, hints, g.relevant(seen, 40) if g.terms else None)
        for attempt in range(3):
            try:
                async with self.limiter:
                    data, usage = await self.provider.complete_json(
                        system, user, 4000, schema=CONLANG_SCHEMA, schema_name="conlang_translation")
                if jobs:
                    jobs[0].usage.add(usage)
                items = data.get("items") if isinstance(data, dict) else None
                if not isinstance(items, list):
                    raise ValueError("yanıtta 'items' yok")
                out: dict[str, tuple[str, bool]] = {}
                for it in items:
                    try:
                        i = int(it.get("i"))
                    except (TypeError, ValueError, AttributeError):
                        continue
                    if not 1 <= i <= len(lines):
                        continue
                    tr = str(it.get("translation", "")).strip()
                    src = lines[i - 1]
                    if not has_letters(tr) or not g.valid_target(tr) or same_words(tr, src):
                        tr = ""
                    is_conlang = it.get("is_constructed_language") is not False
                    out[src] = (tr, is_conlang)
                    log.debug("Elfçe satır %r -> %r (kurgusal=%s)", src, tr, is_conlang)
                return out
            except ProviderError as e:
                if e.kind == "fatal":
                    raise FatalError(str(e)) from e
                if e.kind == "rate_limit":
                    await self.limiter.on_rate_limit()
                log.debug("Elfçe çevirisi denemesi %d: %s", attempt + 1, e)
            except ValueError as e:
                log.debug("Elfçe çevirisi denemesi %d: %s", attempt + 1, e)
            await asyncio.sleep((1.5 ** attempt) * self.backoff_scale)
        return {}

    async def _late_conlang(self, job: FileJob) -> None:
        """Ön taramada kaçan Elfçe satırlar: model satıra hiç dokunmadan bıraktıysa ve satır
        kurgusal dile benziyorsa anlamı sorulur; anlamı olanlar sözlüğe eklenir (sonraki
        bölümlerde de korunur) ve altına Türkçesi yazılır."""
        g = job.glossary
        if g is None or not self.conlang_both or not g.latin_target:
            return
        terms_lower = {norm_line(x) for t in g.terms for x in [t["target"], *t["forms"]]}
        keys = g.keep_keys()
        cands: list[str] = []
        for pos in job.translate_pos:
            out = job.results.get(pos)
            if not out:
                continue
            # Hem ham kaynak hem modele giden metin (konuşmacı adı / tire / not kaldırılmış hâli)
            src_lines = job.srt.blocks[pos].text.split("\n")
            src_keys = {norm_line(x) for x in src_lines} | \
                       {norm_line(x) for x in job.prepared[pos].send_text.split("\n")}
            for ln in out.split("\n"):
                k = norm_line(ln)
                if not k or k not in src_keys or k in keys or any(norm_line(c) == k for c in cands):
                    continue
                # Kaynak altına/yanına anlamını yazdıysa ("Namárië." + "(Farewell.)") tek sözcük ya da
                # büyük harfli sözcükler de kurgusal dil sayılır.
                hit = find_conlang(src_lines, ln)
                glossed = bool(hit and hit[1][:1].isupper()) and not looks_english(k) and k not in terms_lower
                if glossed or conlang_candidate(ln, terms_lower):
                    cands.append(ln.strip())
        if not cands:
            return
        log.debug("%s: çeviride değişmeden kalan, Elfçe olabilecek satırlar: %s", job.rel, cands)
        got = await self._ask_conlang(g, [job], cands)
        found = {ln: tr for ln, (tr, is_conlang) in got.items() if is_conlang and tr}
        (log.info if found else log.debug)("%s: çeviride değişmeden kalan %d satır soruldu, %d tanesi kurgusal dil "
                                           "çıktı (altına Türkçesi yazıldı, sözlüğe eklendi)", job.rel, len(cands), len(found))
        if found:
            g.add_keep(list(found))
            g.keep_tr.update(found)
            job.kept_verbatim += len(found)
            try:
                g.save()
            except OSError as e:
                log.debug("sözlük kaydedilemedi: %s", e)

    async def extract_terms(self, job: FileJob) -> tuple[list[dict], list[str]] | None:
        """Bölüm analizi tek istekte: isim/terimler, kurgusal dildeki satırlar ve anlamları, sahne özetleri,
        karakterlerin birbirine hitap biçimi. Dönüş: (terimler, aynen kalacak satırlar); analizin geri kalanı
        job.analysis'e yazılır (sözlüğe kaydedilmez, yalnızca bu bölümün çevirisinde kullanılır).
        Hata olursa önce analizsiz sözlük isteği denenir; o da olmazsa None (çeviri yine yapılır)."""
        g = job.glossary
        if g is None or self.provider is None:
            return None
        rows, raw = self._glossary_lines(job)
        fixed = g.entries_in("\n".join(t for _, t in rows))
        user = extract_payload(g.series, fixed, rows)
        modes = [True, False] if self.analysis_on else [False]
        last = ""
        for full in modes:
            system = self._glossary_system(job, full)
            schema, name = (ANALYSIS_SCHEMA, "episode_analysis") if full else (GLOSSARY_SCHEMA, "subtitle_glossary")
            max_out = 12000 if full else 6000
            for attempt in range(3):
                try:
                    async with self.limiter:
                        t0 = time.monotonic()
                        data, usage = await self.provider.complete_json(system, user, max_out, schema=schema,
                                                                        schema_name=name)
                    job.usage.add(usage)
                    log.debug("%s: %s yanıtı %.1f sn, %d giriş / %d çıkış token", job.rel,
                              "bölüm analizi" if full else "sözlük", time.monotonic() - t0,
                              usage.input_tokens, usage.output_tokens)
                    terms, keep_ids = parse_terms(data)
                    vocab = english_vocab(raw.values())
                    ok, rejected = filter_keep_refs(keep_ids, raw, [r for r, _ in rows], job.src_lang, vocab)
                    keep = [TAGS_STRIP_RE.sub("", raw[r]).strip() for r in ok]
                    log.debug("%s: kurgusal dil satırları: %s", job.rel, keep)
                    if rejected:
                        log.debug("%s: İngilizce göründüğü için kurgusal dil sayılmayan satırlar: %s", job.rel,
                                  [raw[r] for r in rejected])
                    if full:
                        an = parse_analysis(data)
                        meanings = {}
                        for r in ok:
                            m = an["meanings"].get(r, "")
                            src_line = TAGS_STRIP_RE.sub("", raw[r]).strip()
                            if has_letters(m) and g.valid_target(m) and not same_words(m, src_line):
                                meanings[src_line] = m
                        job.analysis = {"scenes": an["scenes"], "address": an["address"], "meanings": meanings}
                        log.debug("%s: bölüm analizi: %d sahne, %d hitap notu, %d Elfçe anlamı", job.rel,
                                  len(an["scenes"]), len(an["address"]), len(meanings))
                        for sc in an["scenes"]:
                            log.debug("%s: sahne %d-%d: %s", job.rel, sc["from"], sc["to"], sc["summary"])
                        for ad in an["address"]:
                            log.debug("%s: hitap %s -> %s: %s (%s)", job.rel, ad["speaker"], ad["listener"],
                                      ad["form"], ad["note"])
                    return terms, keep
                except ProviderError as e:
                    if e.kind == "fatal":
                        raise FatalError(str(e)) from e
                    if e.kind == "rate_limit":
                        await self.limiter.on_rate_limit()
                    if e.length:
                        max_out = min(self.max_out_cfg, max_out * 2)
                    last = str(e)
                except ValueError as e:
                    last = str(e)
                await asyncio.sleep((1.5 ** attempt) * self.backoff_scale)
            if full:
                log.debug("%s: bölüm analizi alınamadı (%s), yalnızca sözlük isteniyor", job.rel, last)
        job.warnings.append(f"sözlük çıkarılamadı ({last}); mevcut sözlükle devam edildi")
        return None

