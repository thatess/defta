"""Önbellek ve proje kaydı (hedef klasörde .subtrans/proje.sqlite).

- calls   : her API isteğinin yanıtı. Anahtar = model + sistem metni + istek metni (+ şema adı).
            Kaynak, sözlüğün ilgili kısmı, kurallar ve model isteğin içinde olduğu için hepsi anahtara
            otomatik girer; biri değişirse istek yeniden gönderilir, değişmezse bedavaya önbellekten gelir.
            Yarıda kalan çalışma yeniden başlatılınca biten parçalar tekrar ödenmez (devam etme).
- stages  : dosya başına ara sonuçlar (bölüm analizi, anlam kontrolünden önceki çeviri).
- written : en son yazılan çıktı (blok blok). Kullanıcı çıktıyı elle düzeltirse bir sonraki
            çalışmada fark buradan bulunur ve çeviri hafızasına eklenir.
- memory  : çeviri hafızası (seri + kaynak satır -> kullanıcının düzelttiği çeviri).
"""
from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
import time
from pathlib import Path

from .provider import Provider, ProviderError, Usage

log = logging.getLogger("subtrans")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS calls (key TEXT PRIMARY KEY, data TEXT NOT NULL, created REAL);
CREATE TABLE IF NOT EXISTS stages (key TEXT PRIMARY KEY, data TEXT NOT NULL, created REAL);
CREATE TABLE IF NOT EXISTS written (path TEXT PRIMARY KEY, series TEXT, data TEXT NOT NULL, created REAL);
CREATE TABLE IF NOT EXISTS memory (series TEXT, src TEXT, tgt TEXT, created REAL, PRIMARY KEY (series, src));
"""


def sha(*parts: str) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(p.encode("utf-8", "surrogatepass"))
        h.update(b"\x00")
    return h.hexdigest()


class Store:
    """Küçük sqlite deposu. Tek süreç, tek iş parçacığı (asyncio) içinde kullanılır."""

    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(path))
        self.db.executescript(_SCHEMA)
        self.db.commit()

    def close(self) -> None:
        try:
            self.db.commit()
            self.db.close()
        except sqlite3.Error:
            pass

    # -------------------------------------------------- genel anahtar/değer
    def _get(self, table: str, key: str):
        row = self.db.execute(f"SELECT data FROM {table} WHERE key=?", (key,)).fetchone()
        if row is None:
            return None
        try:
            return json.loads(row[0])
        except ValueError:
            return None

    def _put(self, table: str, key: str, value) -> None:
        self.db.execute(f"INSERT OR REPLACE INTO {table} (key, data, created) VALUES (?, ?, ?)",
                        (key, json.dumps(value, ensure_ascii=False), time.time()))
        self.db.commit()

    def get_call(self, key: str):
        return self._get("calls", key)

    def put_call(self, key: str, data) -> None:
        self._put("calls", key, data)

    def get_stage(self, key: str):
        return self._get("stages", key)

    def put_stage(self, key: str, data) -> None:
        self._put("stages", key, data)

    # -------------------------------------------------- yazılan çıktı
    def get_written(self, path: str) -> tuple[str, list] | None:
        row = self.db.execute("SELECT series, data FROM written WHERE path=?", (path,)).fetchone()
        if row is None:
            return None
        try:
            return row[0] or "", json.loads(row[1])
        except ValueError:
            return None

    def put_written(self, path: str, series: str, blocks: list) -> None:
        self.db.execute("INSERT OR REPLACE INTO written (path, series, data, created) VALUES (?, ?, ?, ?)",
                        (path, series, json.dumps(blocks, ensure_ascii=False), time.time()))
        self.db.commit()

    # -------------------------------------------------- çeviri hafızası
    def memory(self, series: str) -> dict[str, str]:
        rows = self.db.execute("SELECT src, tgt FROM memory WHERE series=?", (series,)).fetchall()
        return {s: t for s, t in rows}

    def remember(self, series: str, src: str, tgt: str) -> None:
        self.db.execute("INSERT OR REPLACE INTO memory (series, src, tgt, created) VALUES (?, ?, ?, ?)",
                        (series, src, tgt, time.time()))
        self.db.commit()


class CachedProvider(Provider):
    """Bir Provider'ı önbellekle sarar.

    - Aynı istek daha önce yanıtlandıysa yanıt önbellekten gelir (token harcanmaz).
    - Aynı çalışmada aynı istek ikinci kez sorulursa (yeniden deneme) önbellek atlanır: önceki
      yanıt doğrulamadan geçmemiştir, yenisi alınır ve önbelleğe o yazılır.
    - offline=True: hiç API'ye gidilmez; önbellekte olmayan istek hata verir (test / tekrar oynatma).
    - fresh=True: önbellekten okunmaz ama yeni yanıtlar yazılır (--fresh)."""

    name = "cached"

    def __init__(self, inner: Provider | None, store: Store, model: str, offline: bool = False,
                 fresh: bool = False):
        self.inner = inner
        self.store = store
        self.model = model
        self.offline = offline
        self.fresh = fresh
        self.hits = 0
        self.saved = Usage()       # önbellekten gelen isteklerin ilk seferki kullanımı (tasarruf)
        self._served: dict[str, int] = {}

    def key(self, system: str, user: str, schema_name: str = "") -> str:
        return sha(self.model, schema_name or "", system, user)

    def lookup(self, system: str, user: str, schema_name: str = ""):
        hit = self.store.get_call(self.key(system, user, schema_name))
        return None if hit is None else hit.get("data")

    async def complete_json(self, system: str, user: str, max_output_tokens: int,
                            schema: dict | None = None, schema_name: str = "") -> tuple[dict, Usage]:
        key = self.key(system, user, schema_name)
        n = self._served.get(key, 0)          # bu çalışmada bu istek kaçıncı kez soruluyor
        self._served[key] = n + 1
        stored = self.store.get_call(key)
        hit = None if self.fresh and not self.offline else stored
        answers = ([hit] + list(hit.get("more") or [])) if hit else []
        if n < len(answers) or (self.offline and answers):
            # Aynı istek aynı çalışmada yeniden sorulduysa (doğrulamadan geçmeyen yanıtın tekrarı) önceki
            # çalışmadaki sıradaki yanıt verilir; böylece yeniden çalıştırma birebir aynı ve bedava olur.
            ans = answers[min(n, len(answers) - 1)]
            if ans.get("batch") and not self.offline:
                # Bu çalışmada toplu istekle alınmış yanıt: ücreti zaten sayıldı, "önbellekten" sayılmaz
                ans.pop("batch", None)
                self.store.put_call(key, hit)
                return ans["data"], Usage()
            self.hits += 1
            u = ans.get("usage") or {}
            self.saved.add(Usage(input_tokens=u.get("in", 0), cached_input_tokens=u.get("cached", 0),
                                 output_tokens=u.get("out", 0), requests=1))
            return ans["data"], Usage()
        if self.offline or self.inner is None:
            raise ProviderError("fatal", "çevrimdışı mod: bu istek önbellekte yok (önce normal çalıştırın)")
        data, usage = await self.inner.complete_json(system, user, max_output_tokens, schema, schema_name)
        entry = {"data": data, "usage": {"in": usage.input_tokens, "cached": usage.cached_input_tokens,
                                         "out": usage.output_tokens}}
        if n == 0 or stored is None:
            self.store.put_call(key, entry)
        else:
            stored["more"] = (list(stored.get("more") or []) + [entry])[:5]
            self.store.put_call(key, stored)
        return data, usage

    def put(self, system: str, user: str, schema_name: str, data, usage: Usage) -> None:
        """Toplu (batch) isteklerden gelen yanıtı önbelleğe yazar."""
        self.store.put_call(self.key(system, user, schema_name),
                            {"data": data, "batch": True,
                             "usage": {"in": usage.input_tokens, "cached": usage.cached_input_tokens,
                                       "out": usage.output_tokens}})

    async def check(self, strict: bool = True) -> str:
        if self.offline or self.inner is None:
            return "çevrimdışı mod: API'ye bağlanılmıyor, yanıtlar önbellekten"
        chk = getattr(self.inner, "check", None)
        return await chk(strict=strict) if chk else "ön kontrol yok"

    async def close(self) -> None:
        if self.inner is not None:
            await self.inner.close()

    def __getattr__(self, item):
        # batch_json gibi iç sağlayıcıya özgü yöntemler
        inner = self.__dict__.get("inner")
        if inner is None:
            raise AttributeError(item)
        return getattr(inner, item)
