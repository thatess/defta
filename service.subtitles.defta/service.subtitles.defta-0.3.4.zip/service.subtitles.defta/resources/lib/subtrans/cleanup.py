"""Son temizlik: çeviride kalmış işaret ve artıkları siler (her çıktı bloğuna en sonda uygulanır).

- Satırın başında ve sonunda yalnızca altyazıda olağan işaretler kalır (izin listesi):
  harf/rakam ve . , ! ? … ' " “ ” ‘ ’ - – — : ; ( ) [ ] ♪ ♫ # ¿ ¡ % $ € ₺ + &
- Motorun geçici işaretleri (⟦1⟧), oklar ve kutu karakterleri her yerden silinir.
- « » / << >> bütün bloğu sarıyorsa silinir (italik yerine konmuş), değilse düz tırnağa çevrilir.
- Eşi olmayan ( ) ve [ ] silinir (bir satırda açılıp alttaki satırda kapanan korunur).
- Konuşan etiketi kaldır seçiliyse kalmış "GANDALF:" / "Gandalf:" etiketleri silinir
  (tamamı büyük harf ya da bilinen bir karakter adıysa; "Not: ..." gibi cümlelere dokunulmaz).
Biçim etiketleri korunuyorsa (<i>, {\\an8}) yalnızca kesin artıklar silinir, izin listesi uygulanmaz."""
from __future__ import annotations

import re

_EDGE_OK = set(".,!?…'\"“”‘’-–—:;()[]♪♫#¿¡%$€₺+&")
_PLACEHOLDER_RE = re.compile(r"⟦\d*⟧?|⟧")
_JUNK_RE = re.compile(r"[→←↑↓↔⇒⇐⇔➔➜➝➞►◄▶◀▸◂▹◃⟶⟵⟷↦↪↩☐□▢▯■◆◇●○•�□⬚​‎‏﻿]")
_ANGLE_QUOTES = (("«", "»"), ("<<", ">>"), ("‹", "›"))
_NAME_CH = r"[A-Za-zÇĞİÖŞÜÂÎÛçğıöşüâîû'’.\-]"
_LABEL_RE = re.compile(rf"^(\s*(?:[-–—]\s*)?)([A-ZÇĞİÖŞÜ]{_NAME_CH}*(?:\s[A-ZÇĞİÖŞÜ]{_NAME_CH}*){{0,2}})\s*:\s+(?=\S)")


def _strip_edges(line: str) -> str:
    start, end = 0, len(line)
    while start < end and not (line[start].isalnum() or line[start] in _EDGE_OK):
        start += 1
    while end > start and not (line[end - 1].isalnum() or line[end - 1] in _EDGE_OK):
        end -= 1
    return line[start:end]


def _fix_unmatched(lines: list[str]) -> list[str]:
    """Blok boyunca eşi olmayan parantezleri siler."""
    pairs = {")": "(", "]": "["}
    stack: list[tuple[str, int, int]] = []   # (karakter, satır, konum)
    drop: set[tuple[int, int]] = set()
    for li, ln in enumerate(lines):
        for ci, ch in enumerate(ln):
            if ch in "([":
                stack.append((ch, li, ci))
            elif ch in ")]":
                if stack and stack[-1][0] == pairs[ch]:
                    stack.pop()
                else:
                    drop.add((li, ci))
    drop |= {(li, ci) for _, li, ci in stack}
    if not drop:
        return lines
    return ["".join(ch for ci, ch in enumerate(ln) if (li, ci) not in drop) for li, ln in enumerate(lines)]


def clean_residue(text: str, remove_labels: bool = False, names=(), keep_markup: bool = False) -> str:
    if not text or not text.strip():
        return text
    out = _PLACEHOLDER_RE.sub("", text)
    out = _JUNK_RE.sub("", out)
    body = out.strip()
    for a, b in _ANGLE_QUOTES:
        if body.startswith(a) and body.endswith(b) and body.count(a) == 1 and body.count(b) == 1:
            body = body[len(a):-len(b)]
        if not keep_markup or a != "<<":
            body = body.replace(a, '"').replace(b, '"')
    names = {n for n in names if n}
    lines = []
    for ln in body.split("\n"):
        if remove_labels:
            m = _LABEL_RE.match(ln)
            if m:
                label = m.group(2).strip()
                letters = re.sub(r"[^A-Za-zÇĞİÖŞÜçğıöşü]", "", label)
                if (len(letters) >= 2 and letters.isupper()) or label in names:
                    ln = m.group(1) + ln[m.end():]
        if not keep_markup:
            ln = _strip_edges(ln)
        ln = re.sub(r"[ \t]{2,}", " ", ln).strip()
        if ln:
            lines.append(ln)
    lines = _fix_unmatched(lines)
    lines = [re.sub(r"[ \t]{2,}", " ", ln).strip() for ln in lines]
    result = "\n".join(ln for ln in lines if ln)
    return result if result else text.strip()
