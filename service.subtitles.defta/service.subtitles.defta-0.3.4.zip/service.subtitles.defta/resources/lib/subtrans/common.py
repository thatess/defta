"""Motorun ortak yardımcıları: hata türleri, sözlük yazımı ve tekrar kontrolleri."""
from __future__ import annotations

import re

from .postfix import TAGS_STRIP_RE

# Çeviride aynen geçmesi beklenen sözlük türleri (karakter adı ayrıca, yalnızca Japonca vb. kaynakta).
# Yalnızca büyük harfle başlayan özel adlar zorlanır: "esper", "palantír" gibi küçük harfli
# terimler modele ipucu olarak gider ama "casus Spy Wars" gibi zorlama yapılmaz.
ENFORCE_TYPES = {"place", "organization", "technique", "item", "title", "nickname", "term"}

# Japonca künye satırlarında modelin sürekli yanlış okuduğu kalıp: "結婚 離婚歴なし" = hiç evlenmemiş.
# Model "Evli" diye okuduğu için kaynak gönderilmeden önce açık yazılır.
_JA_SOURCE_FIXES = [(re.compile(r"結婚[\s　・、/／]*離婚歴(?:なし|無し)"), "結婚歴なし・離婚歴なし")]

_STEM_RE = re.compile(r"[^\W\d_]{3,}")


def _stems(text: str) -> set[str]:
    return {w[:4] for w in _STEM_RE.findall(_fold(text))}


def _fold(s: str) -> str:
    return TAGS_STRIP_RE.sub("", s).lower().replace("\u0307", "").replace("ı", "i")


def _term_present(target: str, folded_text: str) -> bool:
    """Sözlük yazımı çeviride geçiyor mu? Türkçe ekler için sözcük köküne bakar
    (Bürosu -> Büromuz, Tarikatı -> Tarikatımız kabul)."""
    words = [w for w in re.split(r"[\s\-'’]+", _fold(target)) if len(w) >= 3]
    if not words:
        return _fold(target) in folded_text
    return all((w if len(w) < 5 else w[:max(4, len(w) - 2)]) in folded_text for w in words)


_SPLIT_HINT = ("Word order may differ between languages, so you may move words between the two ids, but every "
               "word is written once and neither id may be empty: e.g. '\"Concerning...' / '...Hobbits.\"' becomes "
               "the noun in the first id and the word for 'concerning' (a postposition) in the second id.")


def _repeats_neighbor(text: str, other: str, src: str, other_src: str) -> bool:
    """Bölünmüş cümlede model bir satırın sözcüklerini komşu satırda tekrar mı yazmış?
    ("...ruh hâliniz üzerinde bir etkisi var" / "ruh hâlinizde.") Kaynakta aynı tekrar varsa değil."""
    a, b = _stems(text), _stems(other)
    if not a or not a <= b:
        return False
    s1 = _stems(src)
    return bool(s1) and not (s1 & _stems(other_src))


class FatalError(Exception):
    """Tüm çalışmayı durduran hata (geçersiz API anahtarı, model yok, kota bitti...)."""


class ChunkFailed(Exception):
    pass



def same_words(a: str, b: str) -> bool:
    """Elfçe satırın "anlamı" satırın kendisiyle neredeyse aynı mı? ("Cares Galeton." -> "Cares Galadon.")
    Öyleyse altına yazmanın anlamı yok (yer/kişi adıdır)."""
    import difflib
    from .textprep import norm_line
    x, y = norm_line(a), norm_line(b)
    return x == y or difflib.SequenceMatcher(None, x, y).ratio() >= 0.75
