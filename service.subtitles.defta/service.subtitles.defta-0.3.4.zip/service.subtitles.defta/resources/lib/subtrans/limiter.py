"""Eşzamanlı istek sınırı (429 gelince azalır, sonra yeniden artar)."""
from __future__ import annotations

import asyncio
import logging
import time

log = logging.getLogger("subtrans")


class AdaptiveLimiter:
    """Aynı anda kaç istek gideceğini yönetir. 429 gelince yarıya iner; 429 kesildikten sonra
    hızla eski düzeyine döner (her 3 başarılı yanıtta yarısı kadar artar). Tüm dosyalar aynı limiti paylaşır.

    Eski sürümde 429'dan sonra sınır 1'e iner ve neredeyse hiç yükselmezdi (Claude ile "donma")."""

    def __init__(self, start: int, maximum: int):
        self.limit = max(1, start)
        self.maximum = max(1, maximum)
        self.peak = self.limit           # 429 öncesi ulaşılan düzey: hızlı dönüş hedefi
        self.active = 0
        self.streak = 0
        self.last_429 = float("-inf")   # henüz 429 gelmedi (monotonic bilgisayar açılınca 0dan başlar)
        self._cond = asyncio.Condition()

    async def __aenter__(self):
        async with self._cond:
            await self._cond.wait_for(lambda: self.active < self.limit)
            self.active += 1

    async def __aexit__(self, *_):
        async with self._cond:
            self.active -= 1
            self._cond.notify_all()

    async def on_success(self):
        async with self._cond:
            self.streak += 1
            if self.limit >= self.maximum:
                return
            recovering = self.limit < self.peak and time.monotonic() - self.last_429 >= 10
            if recovering and self.streak >= 3:
                self.limit = min(self.peak, self.maximum, self.limit + max(1, self.limit // 2))
            elif self.limit >= self.peak and self.streak >= max(4, self.limit // 2):
                self.limit += 1
                self.peak = max(self.peak, self.limit)
            else:
                return
            self.streak = 0
            self._cond.notify_all()

    async def on_rate_limit(self):
        async with self._cond:
            now = time.monotonic()
            if now - self.last_429 < 2:     # aynı anda gelen birkaç 429 tek sayılır
                return
            recent = now - self.last_429 < 120
            self.last_429 = now
            # Dönüş sırasında yine 429 geldiyse sağlayıcının gerçek sınırı buradadır: hedef bu düzeye iner
            self.peak = max(1, self.limit - 1) if recent else max(self.peak, self.limit)
            new = max(1, self.limit // 2)
            if new < self.limit:
                log.warning("Hız sınırı (429): eşzamanlı istek %d -> %d", self.limit, new)
            self.limit = new
            self.streak = 0
