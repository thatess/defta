"""Çevirilerin bloklara geri yerleştirilmesi, son düzeltmeler, çeviri hafızası ve şüpheli satır raporu."""
from __future__ import annotations

from typing import TYPE_CHECKING

import logging
import re

from .postfix import TAGS_STRIP_RE, apply_fixes, fix_dropped_n
from .srt_io import Block, format_ms
from .textprep import (ASS_CODES_RE, add_conlang_translations, conlang_lines, norm_line, restore,
                       similar_meaning, visible_len)



from .common import _fold, _term_present, same_words
from .cleanup import clean_residue

if TYPE_CHECKING:
    from .engine import FileJob

log = logging.getLogger("subtrans")


def _meaning(g, line: str) -> str | None:
    tr = g.conlang_translation(line)
    return None if not tr or same_words(tr, line) else tr


_BAY_RE = re.compile(r"\bBay ([A-ZÇĞİÖŞÜ][\w-]+)")
_BEY_RE = re.compile(r"\b([A-ZÇĞİÖŞÜ][\w-]+) Bey(?![\w'’])")


def unify_titles(texts: list[str]) -> list[str]:
    """Aynı dosyada "Bay Frodo" ile "Frodo Bey" karışmasın: çoğunlukta olan yazım ekli olmayan
    yerlerde diğerinin yerine yazılır (ekli hâller ünlü uyumu gerektirdiği için olduğu gibi kalır)."""
    bay, bey = {}, {}
    for t in texts:
        for m in _BAY_RE.finditer(t):
            bay[m.group(1)] = bay.get(m.group(1), 0) + 1
        for m in _BEY_RE.finditer(t):
            bey[m.group(1)] = bey.get(m.group(1), 0) + 1
    out = []
    for t in texts:
        for name in set(bay) | set(bey):
            if bay.get(name, 0) > bey.get(name, 0):
                t = re.sub(r"\b" + re.escape(name) + r" Bey(?![\w'’])", "Bay " + name, t)
            elif bey.get(name, 0) > bay.get(name, 0):
                t = re.sub(r"\bBay " + re.escape(name) + r"(?![\w'’])", name + " Bey", t)
        out.append(t)
    return out


_HON_GLUE = "san|sama|chan|kun|senpai|sensei|dono"


def hyphenate_honorifics(texts: list[str], names: list[str]) -> list[str]:
    """Model hitap ekini isme yapışık yazdıysa ("Yorsenpai") tire eklenir ("Yor-senpai")."""
    words = sorted({w for n in names for w in n.split() if len(w) >= 2 and w[:1].isupper()}, key=len, reverse=True)
    if not words:
        return texts
    rx = re.compile(r"\b(" + "|".join(re.escape(w) for w in words) + r")(" + _HON_GLUE + r")\b")
    return [rx.sub(r"\1-\2", t) for t in texts]


def memory_key(text: str) -> str:
    """Çeviri hafızası anahtarı: kaynak bloğun metni (boşluklar sadeleştirilmiş)."""
    return " ".join(text.split())


class AssembleMixin:
    def _assemble(self, job: FileJob) -> None:
        long_lines = 0
        job.dropped = set()
        job.conlang_translated = 0
        texts: list[str] = []
        blocks = job.srt.blocks
        for b, p in zip(blocks, job.prepared):
            if p.dup_of >= 0:
                text = ""                       # katman kopyası: aşağıda asıl bloğun çevirisi kopyalanır
            elif p.drop:
                job.dropped.add(b.pos)
                text = "\u00a0" if p.blank else ""   # boş bırak: görünmez boşluk
            elif p.passthrough:
                text = p.send_text
            else:
                keep, terms, counts = [], [], {}
                if job.glossary is not None and job.glossary.terms:
                    terms = job.glossary.relevant_terms(p.send_text)
                    keep = [t["target"] for t in terms if " " in t["target"]]
                    counts = {t["target"]: job.glossary.count_in(t, p.send_text) for t in terms}
                text = restore(p, job.results[b.pos], self.rules.max_line_length, self.rules.max_lines, keep)
                text = apply_fixes(text, terms, self.rules.code, counts)
            texts.append(text)
        g = job.glossary
        texts = fix_dropped_n(texts, g.keep_keys() if g is not None else set())
        if self.rules.code.lower().startswith("tr"):
            texts = unify_titles(texts)
        if g is not None and g.terms:
            texts = hyphenate_honorifics(texts, [t["target"] for t in g.terms if t.get("type") == "character"])
        if self.conlang_both and g is not None and g.keep_tr:
            keys = g.keep_keys()
            plain = [TAGS_STRIP_RE.sub("", t) for t in texts]
            for i, p in enumerate(job.prepared):
                if p.drop or not any(norm_line(ln) in keys for ln in texts[i].split("\n")):
                    continue
                # Anlamı zaten komşu blokta (ya da aynı blokta) yazıyorsa ikinci kez yazma.
                # Satır satır değil blok bütün olarak karşılaştırılır: "kapılar da açılır." gibi
                # kısa bir satır parçası yanlışlıkla "aynı anlam" sayılmasın.
                near = [x for x in (" ".join(ln for ln in plain[j].split("\n") if norm_line(ln) not in keys)
                                    for j in range(max(0, i - 2), min(len(texts), i + 3))) if x.strip()]
                # Kaynak altyazı bu satırın anlamını kendisi veriyorduysa ("Noro lim, Asfaloth!\n(Ride fast
                # Asfaloth!)") Türkçesi her zaman yazılır; komşu benzerliği yalnızca açıklamasız satırlara bakılır.
                src_glossed = any(gl for _, _, gl, _ in conlang_lines(blocks[i].text.split("\n")))
                texts[i], n_tr = add_conlang_translations(
                    texts[i], lambda ln: _meaning(g, ln) if norm_line(ln) in keys else None,
                    skip=None if src_glossed else (lambda tr, near=near: any(similar_meaning(tr, x) for x in near)))
                job.conlang_translated += n_tr
        for i, p in enumerate(job.prepared):
            if p.dup_of >= 0:
                texts[i] = texts[p.dup_of]
        # Çeviri hafızası: kullanıcının daha önce elle düzelttiği satırlar aynen kullanılır
        job.memory_used = 0
        if job.memory:
            for i, b in enumerate(blocks):
                hit = job.memory.get(memory_key(b.text))
                if hit is not None and not job.prepared[i].drop:
                    if texts[i] != hit:
                        log.debug("%s blok %d: çeviri hafızasından yazıldı: %r -> %r", job.rel, b.index, texts[i], hit)
                    texts[i] = hit
                    job.memory_used += 1
        keep_codes = job.out_fmt in ("ass", "ssa")
        # Son temizlik: kalmış motor işaretleri, oklar, eşi olmayan parantez, konuşan etiketi
        if bool(self.s["output"].get("residue_filter", True)):
            dec = job.decisions or self.decisions
            names = {t["target"] for t in (g.terms if g is not None else []) if t.get("type") == "character"}
            names |= {n for p in job.prepared for n in (p.speakers or [])}
            markup = keep_codes or dec.get("format_tags") != "remove"
            labels_off = dec.get("speaker_labels") == "remove"
            for i, p in enumerate(job.prepared):
                if not p.drop and texts[i].strip():
                    texts[i] = clean_residue(texts[i], remove_labels=labels_off, names=names, keep_markup=markup)
        out = []
        for b, p, text in zip(blocks, job.prepared, texts):
            if self.remove_pos_codes and not keep_codes:
                text = ASS_CODES_RE.sub("", text)
            if not p.drop and not p.passthrough:
                lines = [ln for ln in text.split("\n") if not re.sub(r"^<i>", "", ln).startswith("(")]
                if not p.nowrap and (len(lines) > self.rules.max_lines or any(
                        visible_len(ln) > self.rules.max_line_length + 8 for ln in lines)):
                    long_lines += 1
                    job.suspects.setdefault(b.pos, []).append("okunabilirlik: satır çok uzun ya da fazla satır")
            out.append(Block(pos=b.pos, index=b.index, start_ms=b.start_ms, end_ms=b.end_ms,
                             text=text, tail=b.tail))
        if long_lines:
            job.warnings.append(f"{long_lines} blok okunabilirlik sınırını aşıyor (uzun satır / fazla satır)")
        job.out_blocks = out
        self._check_glossary(job)

    def _check_glossary(self, job: FileJob) -> None:
        """Sözlükteki yazım çeviride yoksa logda not düşer (zamir kullanımı gibi masum durumlar da olabilir)."""
        g = job.glossary
        job.glossary_misses = 0
        if g is None or not g.terms:
            return
        for pos in job.translate_pos:
            src = job.prepared[pos].send_text
            out = _fold(job.out_blocks[pos].text)
            for form, target in g.relevant(src).items():
                if not _term_present(target, out):
                    job.glossary_misses += 1
                    log.debug("%s blok %d: sözlükte '%s' -> '%s', çeviride geçmiyor: %r", job.rel,
                              job.srt.blocks[pos].index, form, target, job.out_blocks[pos].text)

    def final_blocks(self, job: FileJob) -> list[Block]:
        """Yazılacak bloklar. Yalnızca nottan oluşup "sil" modunda kaldırılan bloklar çıkarılır
        ve numaralar 1'den yeniden verilir. Diğer blokların zaman kodları aynen korunur."""
        keep = [b for b in job.out_blocks if not (b.pos in job.dropped and b.text == "")]
        if len(keep) == len(job.out_blocks):
            return job.out_blocks
        return [Block(pos=b.pos, index=n, start_ms=b.start_ms, end_ms=b.end_ms, text=b.text, tail=b.tail)
                for n, b in enumerate(keep, 1)]


    def suspect_report(self, job: FileJob) -> str:
        """Gözden geçirilmesi önerilen satırlar (düz metin). Boşsa ""."""
        if not job.suspects or not job.out_blocks:
            return ""
        by_pos = {b.pos: b for b in job.out_blocks}
        rows = [f"Şüpheli satırlar — {job.rel}", "Bu satırlar doğrulamada ya da anlam kontrolünde işaretlendi; "
                "çoğu doğrudur, yalnızca göz atmanız önerilir.", ""]
        for pos in sorted(job.suspects):
            b = by_pos.get(pos)
            if b is None:
                continue
            src = job.srt.blocks[pos]
            reasons = list(dict.fromkeys(job.suspects[pos]))
            rows.append(f"[{src.index}] {format_ms(src.start_ms)}")
            rows.append("  kaynak : " + src.text.replace("\n", " / "))
            rows.append("  çeviri : " + b.text.replace("\n", " / "))
            for r in reasons:
                rows.append("  neden  : " + r)
            rows.append("")
        return "\n".join(rows)
