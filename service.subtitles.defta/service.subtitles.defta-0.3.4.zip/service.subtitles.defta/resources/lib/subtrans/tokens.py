"""Token sayımı. OpenAI modellerinde tiktoken ile gerçek sayım, diğerlerinde yaklaşık."""
from __future__ import annotations

from functools import lru_cache


@lru_cache(maxsize=1)
def _encoder():
    try:
        import tiktoken
        return tiktoken.get_encoding("o200k_base")
    except Exception:  # tiktoken yoksa veya kodlama indirilemiyorsa
        return None


def is_exact(model: str) -> bool:
    return model.lower().startswith(("gpt-", "o1", "o3", "o4")) and _encoder() is not None


def count_tokens(text: str) -> int:
    enc = _encoder()
    if enc is not None:
        return len(enc.encode(text, disallowed_special=()))
    return max(1, int(len(text) / 3.2))


def fmt_tokens(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.2f}M"
    if n >= 1000:
        return f"{n / 1000:.1f}K"
    return str(n)


def fmt_cost(c: float | None) -> str:
    if c is None:
        return "bilinmiyor"
    if c < 0.01:
        return f"${c:.4f}"
    return f"${c:.2f}"
