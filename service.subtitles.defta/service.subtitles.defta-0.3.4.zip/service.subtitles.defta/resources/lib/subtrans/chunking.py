"""Chunk'lara bölme: hedef boyut otomatik/sabit, sınırlar doğal duraklara yerleşir.

Her blok tam olarak bir chunk'ta çevrilir. Komşu bloklar yalnızca bağlam olarak eklenir.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass

from .srt_io import Block

SENTENCE_END_RE = re.compile(r"[.!?…。！？♪]['\"”’)\]]*\s*$")
TAG_RE = re.compile(r"</?[a-zA-Z][^>]*>|\{\\[^}]*\}")


@dataclass
class Chunk:
    number: int                 # 1'den başlar, log için
    targets: list[int]          # çevrilecek blokların pos değerleri
    before: list[int]           # yalnızca bağlam
    after: list[int]            # yalnızca bağlam
    part: str = ""              # ikiye bölünen parçalarda ".1", ".2"


def auto_chunk_size(n_blocks: int) -> int:
    """Hız ile token arasında denge: bölüm ~16 parçaya bölünür, parça 25–60 blok."""
    if n_blocks <= 25:
        return max(1, n_blocks)
    return max(25, min(60, math.ceil(n_blocks / 16)))


def boundary_score(blocks: list[Block], i: int, scene_gap_ms: int) -> int:
    """i numaralı bloktan SONRA bölmenin ne kadar doğal olduğu (yüksek = iyi)."""
    if i >= len(blocks) - 1:
        return 10
    cur, nxt = blocks[i], blocks[i + 1]
    score = 0
    gap = nxt.start_ms - cur.end_ms
    if gap >= scene_gap_ms:
        score += 3
    text = TAG_RE.sub("", cur.text).strip()
    if SENTENCE_END_RE.search(text):
        score += 2
    nxt_text = TAG_RE.sub("", nxt.text).lstrip()
    if nxt_text.startswith(("-", "–")):
        score += 1
    if text.endswith((",", ";", ":")) or (text and text[-1].isalpha()):
        score -= 2  # cümle devam ediyor
    return score


def make_chunks(blocks: list[Block], translate_pos: list[int], size: int, *,
                strict: bool, before_n: int, after_n: int,
                scene_gap_ms: int, max_blocks: int | None = None) -> list[Chunk]:
    """translate_pos: LLM'e gidecek blokların pos listesi (atlananlar hariç), sıralı."""
    if not translate_pos:
        return []
    if max_blocks:
        size = max(1, min(size, max_blocks))
    chunks: list[Chunk] = []
    i = 0
    n = len(translate_pos)
    while i < n:
        remaining = n - i
        if remaining <= size * 1.2 or (strict and remaining <= size):
            end = n
        elif strict:
            end = i + size
        else:
            lo = i + max(1, int(size * 0.8))
            hi = min(n - 1, i + int(size * 1.2))
            if max_blocks:
                hi = min(hi, i + max_blocks)
            best, best_key = lo, None
            for e in range(lo, hi + 1):
                pos = translate_pos[e - 1]
                sc = boundary_score(blocks, pos, scene_gap_ms)
                key = (sc, -abs(e - (i + size)))
                if best_key is None or key > best_key:
                    best, best_key = e, key
            end = best
        targets = translate_pos[i:end]
        first, last = targets[0], targets[-1]
        before = list(range(max(0, first - before_n), first))
        after = list(range(last + 1, min(len(blocks), last + 1 + after_n)))
        chunks.append(Chunk(number=len(chunks) + 1, targets=targets, before=before, after=after))
        i = end
    return chunks


def split_chunk(chunk: Chunk, n_blocks: int, before_n: int, after_n: int) -> tuple[Chunk, Chunk]:
    """Hatalı bir chunk'ı ikiye böler (yeniden deneme için)."""
    mid = len(chunk.targets) // 2
    a_t, b_t = chunk.targets[:mid], chunk.targets[mid:]

    def ctx(t: list[int], k: int) -> Chunk:
        return Chunk(number=chunk.number, part=f"{chunk.part}.{k}", targets=t,
                     before=list(range(max(0, t[0] - before_n), t[0])),
                     after=list(range(t[-1] + 1, min(n_blocks, t[-1] + 1 + after_n))))
    return ctx(a_t, 1), ctx(b_t, 2)
