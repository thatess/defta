"""Çeviri motoru: chunk'ları paralel (veya sıralı) çevirir, her yanıtı doğrular,
hatalı chunk'ı yeniden dener, gerekirse ikiye bölerek tekrar dener.

Analiz, anlam kontrolü ve birleştirme ayrı modüllerdedir (analysis, reviewer, assemble)."""
from __future__ import annotations

import asyncio
import logging
import random
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import lyrics
from .chunking import Chunk, auto_chunk_size, make_chunks, split_chunk
from .config import RulePack, Settings, credit_label, lang_name
from .glossary import (Glossary, extract_payload)
from .prompts import address_notes, build_system_prompt, build_user_payload, glossary_block
from .provider import Provider, ProviderError, Usage
from .review import REVIEW_SCHEMA, is_fragment
from .srt_io import Block, SrtFile
from .textprep import (NON_LATIN_LANGS, PLACEHOLDER_RE, TAG_RE, Prepared, check_translation, has_foreign_script,
                       honorifics_in_source, is_credit_line,
                       is_site_credit, norm_line, normalize_model_text, prepare)
from .tokens import count_tokens

from .common import (ENFORCE_TYPES, ChunkFailed, FatalError, _JA_SOURCE_FIXES, _SPLIT_HINT, _fold,
                     _repeats_neighbor, _term_present)
from .limiter import AdaptiveLimiter
from .analysis import AnalysisMixin
from .reviewer import ReviewMixin
from .fragments import FragmentMixin
from .assemble import AssembleMixin

log = logging.getLogger("subtrans")

__all__ = ["Engine", "FileJob", "FatalError", "ChunkFailed", "AdaptiveLimiter"]


@dataclass
class FileJob:
    srt: SrtFile
    rel: Path
    out_path: Path
    src_lang: str
    prepared: list[Prepared] = field(default_factory=list)
    translate_pos: list[int] = field(default_factory=list)
    chunks: list[Chunk] = field(default_factory=list)
    chunk_size_auto: int = 0
    chunk_size_used: int = 0
    system_prompt: str = ""
    results: dict[int, str] = field(default_factory=dict)
    draft: dict[int, str] = field(default_factory=dict)     # kontrol öncesi çeviri (kontrol bağlamı bundan okunur)
    usage: Usage = field(default_factory=Usage)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    est_input: int = 0
    est_output: int = 0
    est_cached: int = 0                              # tahmini önbellekli (indirimli) giriş token'ı
    est_review: tuple[int, int] = (0, 0)             # bunun anlam kontrolüne düşen kısmı (giriş, çıkış)
    elapsed: float = 0.0
    status: str = "bekliyor"
    out_blocks: list[Block] = field(default_factory=list)
    decisions: dict[str, str] | None = None   # dosyaya özgü kararlar (örn. şarkılar "auto")
    dropped: set[int] = field(default_factory=set)  # yalnızca nottan oluşup kaldırılan bloklar
    series: str = ""                                 # seri sözlüğü adı
    glossary: Glossary | None = None
    glossary_est: tuple[int, int] = (0, 0)           # sözlük isteği tahmini (giriş, çıkış)
    glossary_misses: int = 0
    kept_verbatim: int = 0                           # Elfçe vb. aynen bırakılan blok sayısı
    conlang_translated: int = 0                      # altına Türkçesi eklenen Elfçe satır sayısı
    honorific_issues: int = 0                        # yeniden denemeye rağmen eksik kalan hitap ekleri
    review_fixes: int = 0                            # anlam kontrolünde düzeltilen blok sayısı
    review_skipped: int = 0                          # kontrole gönderilmeyen (tek sözcüklük vb.) blok sayısı
    out_fmt: str = "srt"                             # çıktı biçimi: srt | ass | ssa | vtt
    analysis: dict | None = None                     # bölüm analizi: sahne özetleri, hitap biçimi, Elfçe anlamları
    instructions: str = ""                           # seri talimat dosyası (sozlukler/<seri>.talimat.txt)
    full_glossary: bool = False                      # sözlüğün tamamı sistem metninde (prompt cache varken)
    memory: dict[str, str] = field(default_factory=dict)   # çeviri hafızası: kaynak satır -> kullanıcının çevirisi
    memory_used: int = 0
    suspects: dict[int, list[str]] = field(default_factory=dict)  # pos -> şüphe nedenleri (rapor için)
    fragment_tasks: list = field(default_factory=list)            # kısa replik kontrolü görevleri (parça parça)
    fragment_fixes: dict = field(default_factory=dict)            # satır -> (kontrol edilen taslak, düzeltme)
    fragment_lines: int = 0
    fragment_lost: int = 0
    fragment_applied: int = 0


class Engine(AnalysisMixin, ReviewMixin, FragmentMixin, AssembleMixin):
    def __init__(self, settings: Settings, provider: Provider | None, rules: RulePack,
                 decisions: dict[str, str]):
        self.s = settings
        self.provider = provider
        self.rules = rules
        self.decisions = decisions
        ch = settings["chunking"]
        self.before_n = 6 if settings.is_auto("chunking", "context_before") else int(ch["context_before"])
        # Sonraki bağlam 5 blok: bölünmüş cümlelerin devamı ve cevaplar görünsün (ilk denemede doğru çeviri)
        self.after_n = 5 if settings.is_auto("chunking", "context_after") else int(ch["context_after"])
        self.sequential = str(ch["chunk_order"]).lower() == "sequential"
        if settings.is_auto("chunking", "parallel"):
            # Bir bölüm ~16 parça: hepsini aynı anda göndermek hedef. 429 gelirse yarıya iner.
            self.limiter = AdaptiveLimiter(start=16, maximum=48)
        else:
            n = int(ch["parallel"])
            self.limiter = AdaptiveLimiter(start=n, maximum=n)
        self.max_api_retries = int(settings["retry"]["max_api_retries"])
        self.max_val_attempts = int(settings["retry"]["max_validation_attempts"])
        self.max_out_cfg = int(settings["provider"]["max_output_tokens"])
        self.backoff_scale = 1.0  # testlerde beklemeyi kısaltmak için
        self.progress = None      # canlı ilerleme göstergesi (isteğe bağlı)
        self.remove_pos_codes = str(settings["output"].get("position_codes", "remove")).lower() == "remove"
        self.credit = str(settings["output"].get("credit", "") or "").strip()
        self.conlang_both = str(settings["conlang"].get("display", "original+translation")).lower() != "original"
        self.review_on = bool(settings.raw.get("quality", {}).get("review", True))
        self.estimate = True        # plan sırasında maliyet tahmini (Kodi kapatır)
        # Anlam kontrolü ayrı (daha güçlü) bir modelle yapılabilir: [quality] review_model
        self.review_provider: Provider | None = None
        self.review_price: dict | None = None
        self.main_price: dict | None = None
        pv = settings["provider"]
        pc = str(pv.get("prompt_cache", "auto")).lower()
        # Sağlayıcı istek başını önbelleğe alıyorsa (OpenAI) sözlüğün tamamı sistem metnine konur:
        # tüm parçalarda aynı kaldığı için %90 indirimli okunur ve her parçada her isim görünür.
        self.prompt_cache = ("openai.com" in str(pv.get("base_url", "")) if pc == "auto"
                             else pc in ("true", "1", "yes", "evet", "on"))
        self.analysis_on = bool(settings.raw.get("quality", {}).get("episode_analysis", True))
        self.store = None          # cache.Store: ara sonuçlar (çeviri, analiz)
        self.review_only = False   # --review-only: çeviri önbellekten, yalnızca anlam kontrolü
        self.batch = False         # toplu istek (Batch API)
        self.on_chunk = None       # her parça bitince çağrılır: on_chunk(job, {pos: metin})

    # ------------------------------------------------------------ hazırlık

    def plan(self, job: FileJob) -> None:
        """Blokları hazırlar, chunk'lara böler, token tahmini yapar (API çağrısı yok)."""
        blocks = job.srt.blocks
        dec = job.decisions or self.decisions
        job.warnings = []
        job.prepared = []
        n = len(blocks)
        keep_keys = job.glossary.keep_keys() if job.glossary is not None else None
        ja_src = job.src_lang.lower().startswith("ja")
        job.kept_verbatim = 0
        doc = getattr(job.srt, "doc", None)
        ass_doc = doc is not None and getattr(doc, "fmt", "") in ("ass", "ssa")
        nowrap = getattr(doc, "nowrap", set()) if doc is not None else set()
        drawing = getattr(doc, "drawing", set()) if doc is not None else set()
        # Şarkı sözleri blok olarak bulunur; moda göre çevrilir / Latin harfleriyle kalır / ikisi birden
        styles = {k: ev.style for k, ev in enumerate(getattr(doc, "events", []) or [])} if ass_doc else {}
        lyric_plan = lyrics.plan(blocks, lyrics.find_lyrics(blocks, styles), dec.get("lyrics", "translate"))
        tdec = {**dec, "lyrics": "translate"}
        seen_text: dict[tuple, int] = {}
        for k, b in enumerate(blocks):
            if k in drawing:
                # ASS çizimi: çevrilmez; başka biçime yazılırken atılır
                keep_draw = job.out_fmt in ("ass", "ssa")
                job.prepared.append(Prepared(send_text=b.text if keep_draw else "", passthrough=True,
                                             drop=not keep_draw))
                continue
            if ass_doc and b.text.strip():
                key = (b.start_ms, b.end_ms, b.text)
                if key in seen_text:
                    # Aynı anda aynı metni taşıyan katman kopyası: bir kez çevrilir, buraya kopyalanır
                    job.prepared.append(Prepared(send_text=b.text, passthrough=True, dup_of=seen_text[key]))
                    continue
                seen_text[key] = k
            if self.credit and ((k < 15 or k >= n - 25) and is_credit_line(b.text) or is_site_credit(b.text)):
                # Kaynaktaki "Subtitle translation by: X" satırı -> "Altyazı çevirisi: <senin adın>"
                label = self.rules.credit_label or credit_label(self.rules.code)
                job.prepared.append(Prepared(send_text=f"{label}: {self.credit}", passthrough=True))
                job.warnings.append(f"Blok {b.index}: künye satırı '{label}: {self.credit}' olarak yazıldı")
                continue
            lp = lyric_plan.get(b.pos)
            if lp is not None and not lp.plain:
                keep, head = (TAG_RE.sub("", x) if dec.get("format_tags") == "remove" else x for x in (lp.keep, lp.head))
                p = prepare(lp.send, tdec, keep_keys) if lp.send.strip() else Prepared(send_text="", passthrough=True)
                p.nowrap = bool(lp.keep or lp.romanize or lp.romanize_both)   # çeviri satırları yeniden sarılır
                if not p.passthrough:
                    p.romanize, p.romanize_both = lp.romanize, lp.romanize_both
                    p.lyric_head, p.lyric_wrap = head, lp.wrap
                    p.song = not (lp.romanize or lp.romanize_both)     # anlamı çevrilecek şarkı satırı
                else:                               # çevrilecek bir şey yok: orijinal kalır ya da blok atılır
                    p.send_text = keep or head
                    p.drop, p.blank = not p.send_text, False
                job.prepared.append(p)
                continue
            else:
                # şarkı olmayan blok: "♪ hafif müzik ♪" gibi notlar da çevrilir (şarkı modu yalnızca lyrics.plan'da)
                p = prepare(b.text, tdec, keep_keys) if b.text.strip() else Prepared(send_text=b.text, passthrough=True)
            if k in nowrap:
                p.nowrap = True
            if ja_src and not p.passthrough:
                for rx, fixed in _JA_SOURCE_FIXES:
                    p.send_text = rx.sub(fixed, p.send_text)
            if keep_keys and b.text.strip() and (p.passthrough or p.placeholders) and \
                    any(norm_line(x) in keep_keys for x in b.text.split("\n")):
                job.kept_verbatim += 1
            if p.warning:
                job.warnings.append(f"Blok {b.index}: {p.warning}")
            job.prepared.append(p)
        job.translate_pos = [i for i, p in enumerate(job.prepared) if not p.passthrough]
        self._reading_limits(job, blocks)

        ch = self.s["chunking"]
        job.chunk_size_auto = auto_chunk_size(len(job.translate_pos))
        size = job.chunk_size_auto if self.s.is_auto("chunking", "chunk_size") else int(ch["chunk_size"])

        # Çıktı token güvenliği: tek yanıtın sığması için chunk başına üst sınır
        avg_src = (sum(count_tokens(job.prepared[i].send_text) for i in job.translate_pos)
                   / max(1, len(job.translate_pos)))
        per_block_out = avg_src * self.rules.token_expansion + 12
        max_blocks = max(1, int((self.max_out_cfg * 0.4) / max(1.0, per_block_out)))
        if size > max_blocks:
            job.warnings.append(f"Chunk boyutu {size} çıktı sınırını aşabilir, {max_blocks}'e düşürüldü")

        job.chunks = make_chunks(
            blocks, job.translate_pos, size,
            strict=str(ch["chunk_mode"]).lower() == "strict",
            before_n=self.before_n, after_n=self.after_n,
            scene_gap_ms=int(float(ch["scene_gap_seconds"]) * 1000),
            max_blocks=max_blocks,
        )
        job.chunk_size_used = min(size, max_blocks)
        job.system_prompt = self._system_prompt(job, dec)

        if self.estimate:
            self._estimate(job)

    READ_CPS = 17       # Türkçe altyazıda rahat okuma hızı (karakter/sn)
    PAUSE_S = 5         # bundan uzun sessizlik yüke "pause_before" olarak yazılır

    def _reading_limits(self, job: FileJob, blocks) -> None:
        """Ekranda kısa kalan satırlar: kaynak satır bile okuma hızını aşıyorsa modele karakter sınırı
        verilir (anlam korunur, ifade kısalır). Sınır kaynağın %80'inden aşağı inmez: hızlı İngilizce
        altyazılarda (20+ karakter/sn) daha sert kısaltma anlam kaybettirir."""
        for i in job.translate_pos:
            p = job.prepared[i]
            if p.romanize or p.romanize_both or i >= len(blocks):
                continue
            dur = (blocks[i].end_ms - blocks[i].start_ms) / 1000
            limit = int(dur * self.READ_CPS)
            text = re.sub(r"(?m)^\s*[-–]\s*", "", PLACEHOLDER_RE.sub("", TAG_RE.sub("", p.send_text)))  # "- " sayılmaz
            chars = len(text.replace("\n", " ").strip())
            if dur > 0 and chars > limit:
                p.max_chars = max(14, limit, int(chars * 0.8))

    def _estimate(self, job: FileJob) -> None:
        """Maliyet tahmini (masaüstünde onay ekranı için; Kodi'de kullanılmaz, kapalıdır)."""
        sys_tokens = count_tokens(job.system_prompt)
        rev_tokens = count_tokens(self._review_system(job)) if self.review_on else 0
        job.est_input = job.est_output = job.est_cached = 0
        job.est_review = (0, 0)
        for k, c in enumerate(job.chunks):
            user = self._payload(job, c, prev=None)
            out = self._est_out(job, c)
            job.est_input += sys_tokens + count_tokens(user) + 10
            if self.prompt_cache and k > 0 and sys_tokens >= 1024:
                job.est_cached += sys_tokens
            job.est_output += out
            if self.review_on:   # anlam kontrolü: kaynak + çeviri okunur, yalnızca düzeltmeler yazılır
                r_in, r_out = rev_tokens + count_tokens(user) + out + 10, 4 * len(c.targets) + 30
                job.est_input += r_in
                job.est_output += r_out
                job.est_review = (job.est_review[0] + r_in, job.est_review[1] + r_out)
        if job.glossary is not None:
            sys_g = self._glossary_system(job)
            user_g = extract_payload(job.glossary.series, [], self._glossary_lines(job)[0])
            job.glossary_est = (count_tokens(sys_g) + count_tokens(user_g) + 10,
                                1500 + (12 * len(job.translate_pos) // 10 + 400 if self.analysis_on else 0))

    def _system_prompt(self, job: FileJob, dec: dict[str, str]) -> str:
        """Çeviri sistem metni. Sıra önemli: değişmeyen kısımlar başta (sağlayıcı önbelleği başı tutar),
        bölüme özgü notlar en sonda."""
        parts = [build_system_prompt(job.src_lang, self.rules, dec)]
        if any(p.romanize for p in job.prepared):
            parts.append("\nSONG LYRICS TO ROMANIZE\nItems marked \"romanize\": true contain song lyrics that must "
                         "NOT be translated: write the original lyrics in Latin letters (Hepburn romaji for Japanese, "
                         "standard romanization for other scripts), keep the ♪ symbols, and translate any other "
                         "line of that item normally.\n")
        if any(p.romanize_both for p in job.prepared):
            parts.append("\nSONG LYRICS: ORIGINAL AND MEANING\nItems marked \"romanize_and_translate\": true contain "
                         "song lyrics. Write each original line in Latin letters (Hepburn romaji for Japanese, standard "
                         "romanization for other scripts), and directly under it its translation wrapped in "
                         "parentheses, e.g. \"Sora e\\n(Gökyüzüne)\".\n")
        if any(p.song for p in job.prepared):
            parts.append("\nSONG LYRICS\nItems marked \"song\": true are song lyrics: translate their meaning into short, "
                         "natural, poetic lines (not like dialogue), keep the line count, no full stop at the end.\n")
        if any(p.max_chars for p in job.prepared):
            parts.append("\nREADING SPEED\nItems with \"max_chars\" stay on screen only briefly: keep that translation "
                         "within about max_chars characters by choosing shorter natural wording. Never drop meaning, "
                         "names or a negation to fit.\n")
        if job.instructions:
            parts.append("\nSERIES-SPECIFIC INSTRUCTIONS FROM THE USER (they override the general rules above)\n"
                         + job.instructions.strip() + "\n")
        job.full_glossary = False
        g = job.glossary
        if self.prompt_cache and g is not None and g.terms:
            text = glossary_block(g)
            if count_tokens(text) <= 6000:
                parts.append(text)
                job.full_glossary = True
        notes = address_notes(job.analysis, self.rules.code)
        if notes:
            parts.append(notes)
        return "".join(parts)

    @staticmethod
    def _names(job: FileJob) -> set[str] | None:
        """Hitap eki kontrolü için tüm sözlük adları (黄昏君 gibi kod adı + ek de sayılsın)."""
        if job.glossary is None:
            return None
        names: set[str] = set()
        for t in job.glossary.terms:
            for f in t["forms"]:
                names.add(f)
                names.update(x for x in f.split("・") if x)
        return names

    def _est_out(self, job: FileJob, c: Chunk) -> int:
        src = sum(count_tokens(job.prepared[i].send_text) for i in c.targets)
        return int(src * self.rules.token_expansion + 12 * len(c.targets) + 20)

    def _payload(self, job: FileJob, c: Chunk, prev: dict[int, str] | None,
                 notes: list[str] | None = None) -> str:
        blocks = job.srt.blocks

        def item(i: int, with_prev: bool = False, target: bool = False) -> dict:
            p = job.prepared[i]
            d: dict = {"id": i + 1}
            if p.speakers_by_line:
                d["speakers_by_line"] = p.speakers_by_line   # hangi satırı kim söylüyor ("" = belirtilmemiş)
            elif p.speakers:
                d["speaker"] = ", ".join(p.speakers)
            if p.notes:
                d["note"] = " ".join(p.notes)       # ses notu: çevrilmez, yalnızca ton/bağlam için
            if 0 < i < len(blocks):                 # uzun sessizlik: çoğu zaman yeni sahne ya da konuşan
                gap = (blocks[i].start_ms - blocks[i - 1].end_ms) / 1000
                if gap >= self.PAUSE_S:
                    d["pause_before"] = int(round(gap))
            d["text"] = p.send_text
            if target and p.romanize:
                d["romanize"] = True
            if target and p.romanize_both:
                d["romanize_and_translate"] = True
            if target and p.song:
                d["song"] = True
            if target and p.max_chars:
                d["max_chars"] = p.max_chars
            if with_prev and prev is not None and i in prev:
                d["translation"] = prev[i]
            return d
        before = [item(i, True) for i in c.before]
        targets = [item(i, target=True) for i in c.targets]
        after = [item(i, True) for i in c.after]
        gl = None
        if job.glossary is not None and job.glossary.terms and not job.full_glossary:
            text = "\n".join(job.prepared[i].send_text + " " + " ".join(job.prepared[i].speakers)
                             for i in c.before + c.targets + c.after)
            gl = job.glossary.relevant(text) or None
        return build_user_payload(before, targets, after, gl, notes, self._hints(job, c), self._scene(job, c))

    @staticmethod
    def _hon_label(g, n: str, h: str) -> str:
        """Modele söylenecek hitap: sözlükteki Latin yazımı + ek ("Yor-senpai"). Sözlükte yoksa
        Japonca harf yazdırmamak için "ヨル (Latin harfleriyle)-senpai" denir."""
        if not n:
            return h
        tgt = None
        if g is not None:
            tgt = g.relevant(n).get(n)
            if not tgt:   # yalnızca tam adla kayıtlıysa (ヨル・ブライア -> Yor Briar) ilk parça
                for t in g.terms:
                    for f in t["forms"]:
                        parts = f.split("・")
                        if len(parts) > 1 and n in parts:
                            words = t["target"].split()
                            if len(words) == len(parts):
                                tgt = words[parts.index(n)]
                                break
                    if tgt:
                        break
        if not tgt:
            tgt = n if not has_foreign_script(n) else f"{n} (in Latin letters)"
        return f"{tgt}{h if h.startswith('-') else '-' + h}"

    @staticmethod
    def _scene(job: FileJob, c: Chunk) -> list:
        """Bölüm analizindeki sahne özetlerinden bu parçaya (bağlam dahil) düşenler, id aralığıyla:
        model hangi özetin hangi satırlara ait olduğunu bilsin."""
        if not job.analysis or not job.analysis.get("scenes") or not c.targets:
            return []
        ids = (c.before or c.targets) + c.targets + (c.after or c.targets)
        a, b = min(ids) + 1, max(ids) + 1
        return [{"ids": f"{sc['from']}-{sc['to']}", "summary": sc["summary"]}
                for sc in job.analysis["scenes"] if sc["from"] <= b and sc["to"] >= a][:6]

    def _hints(self, job: FileJob, c: Chunk) -> list[str]:
        """İlk denemede doğru çıksın diye önceden verilen kısa uyarılar: yeniden denemeye en sık yol açan
        hitap ekleri ve altyazılara bölünmüş cümleler."""
        hints: list[str] = []
        names = self._names(job)
        g = job.glossary
        hon = []
        if job.src_lang.lower().startswith("ja"):
            for i in c.targets:
                pairs = []
                for n, h in honorifics_in_source(job.prepared[i].send_text, names):
                    pairs.append(self._hon_label(g, n, h))
                if pairs:
                    hon.append(f"id {i + 1}: {', '.join(pairs)}")
        if hon:
            hints.append("Keep these honorifics attached to the name exactly as written (never Bay/Hanım/abla "
                         "or similar instead): " + "; ".join(hon[:12]))
        runs, cur = [], []
        tset = set(c.targets)
        for i in c.targets:
            nxt = i + 1
            if nxt in tset and is_fragment(job.prepared[i].send_text, job.prepared[nxt].send_text):
                if not cur:
                    cur = [i]
                cur.append(nxt)
            elif cur:
                runs.append(cur)
                cur = []
        if cur:
            runs.append(cur)
        if runs:
            hints.append("Sentences split across ids: " + ", ".join(f"{r[0] + 1}-{r[-1] + 1}" for r in runs[:15])
                         + ". Translate each as one sentence, write every word once in the id during which it is "
                         "spoken, and leave no id empty.")
        return hints

    # ------------------------------------------------------------ API çağrısı

    async def _call(self, job: FileJob, c: Chunk, user: str, max_out: int, attempt: int) -> dict:
        pr = self.progress
        for api_try in range(self.max_api_retries + 1):
            t0 = 0.0
            try:
                async with self.limiter:
                    t0 = time.monotonic()
                    if pr:
                        pr.sent(job, c, attempt + api_try)
                    data, usage = await self.provider.complete_json(job.system_prompt, user, max_out)
                job.usage.add(usage)
                if pr:
                    pr.received(job, c, time.monotonic() - t0, usage)
                log.debug("%s parça %d%s: yanıt %.1f sn, %d giriş (%d cache) / %d çıkış token",
                          job.rel, c.number, c.part, time.monotonic() - t0, usage.input_tokens,
                          usage.cached_input_tokens, usage.output_tokens)
                await self.limiter.on_success()
                return data
            except ProviderError as e:
                if pr:
                    pr.received(job, c, time.monotonic() - t0 if t0 else 0.0, None, error=str(e))
                if e.kind == "fatal":
                    raise FatalError(str(e)) from e
                if e.kind == "bad_request":
                    raise  # doğrulama hatası gibi ele alınır
                if api_try >= self.max_api_retries:
                    raise
                if e.kind == "rate_limit":
                    await self.limiter.on_rate_limit()
                wait = min(60.0, 2 ** api_try + random.random()) * self.backoff_scale
                log.debug("%s: geçici hata (%s), %.1f sn sonra yeniden deneniyor", job.rel, e, wait)
                await asyncio.sleep(wait)
        raise ProviderError("transient", "yeniden deneme hakkı bitti")

    # ------------------------------------------------------------ chunk çevirisi

    def _validate(self, job: FileJob, c: Chunk, data: dict, watch: set[int] | None = None,
                  flagged: set[int] | None = None) -> tuple[dict[int, str], list[str], list[str], list[str]]:
        """(çeviriler, kesin hatalar, yumuşak sorunlar, modele geri bildirim notları).
        flagged: verilirse sorunlu blokların pos değerleri buraya eklenir (yalnızca onlar yeniden sorulur);
        yanıtın bütünü bozuksa (biçimsiz öğe, yabancı id) içine -1 konur = parçanın tamamı yeniden sorulur.
        watch: önceki denemede yalnızca noktalama dönen id'ler; yeniden sorulduğunda model o satırı
        doldurmak için komşu satırdaki sözcükleri tekrar yazabilir, bu id'lerde tekrar aranır."""
        hard, soft, notes = [], [], []
        items = data.get("translations") if isinstance(data, dict) else None
        if flagged is None:
            flagged = set()
        if not isinstance(items, list):
            flagged.add(-1)
            return {}, ["yanıtta 'translations' listesi yok"], soft, ["Return a 'translations' list."]
        want = {i + 1 for i in c.targets}
        ctx_ids = {i + 1 for i in c.before + c.after}
        got: dict[int, str] = {}
        for it in items:
            if not isinstance(it, dict) or "id" not in it or "text" not in it:
                hard.append("biçimsiz öğe")
                flagged.add(-1)
                continue
            try:
                bid = int(it["id"])
            except (TypeError, ValueError):
                hard.append(f"geçersiz id {it.get('id')!r}")
                flagged.add(-1)
                continue
            if bid in ctx_ids:
                soft.append(f"bağlam bloğu {bid} yanıtta geldi, atıldı")
                continue
            if bid not in want:
                hard.append(f"beklenmeyen id {bid}")
                flagged.add(-1)
                continue
            if bid in got:
                hard.append(f"id {bid} tekrar ediyor")
                flagged.add(bid - 1)
                continue
            got[bid] = normalize_model_text(str(it["text"]))
        missing = want - set(got)
        if missing:
            flagged.update(m - 1 for m in missing)
            hard.append(f"eksik id: {sorted(missing)[:10]}")
            notes.append(f"These ids were missing; return every id exactly once: {sorted(missing)[:20]}")
        out: dict[int, str] = {}
        g = job.glossary
        names = self._names(job)
        # İsim kontrolü yalnızca Japonca vb. kaynaklarda (Anya kendinden adıyla bahseder).
        # İngilizce kaynakta isimler zaten korunur; orada "Doggie" gibi lakapları zorlamasın.
        check_names = g is not None and g.terms and job.src_lang.lower() in NON_LATIN_LANGS
        target_latin = self.rules.code.lower().split("-")[0] not in NON_LATIN_LANGS
        for bid, text in got.items():
            pos = bid - 1
            src = job.prepared[pos]
            h, sft = check_translation(src, text, names)
            if target_latin and has_foreign_script(PLACEHOLDER_RE.sub("", text)):
                h.append("çeviri kaynak dilde kalmış (hedef dilin alfabesinde olmayan harfler var)")
            idx = job.srt.blocks[pos].index
            if h:
                flagged.add(pos)
            hard += [f"blok {idx}: {x}" for x in h]
            soft += [f"blok {idx}: {x}" for x in sft]
            for x in h:
                if "kaynak dilde" in x:
                    tgt = self.rules.name if not self.rules.is_default else lang_name(self.rules.code)
                    notes.append(f"id {bid}: you left this line in the source language; translate it into {tgt}.")
                if "yer tutucu" in x:
                    notes.append(f"id {bid}: keep every placeholder like ⟦1⟧ exactly once, unchanged.")
                if "noktalama" in x:
                    if watch is not None:
                        watch.add(bid)
                    notes.append(f"id {bid}: you returned only punctuation. This id is part of a sentence split "
                                 "across ids: put the words spoken during this id into it, and do NOT repeat "
                                 "words that are already in the neighbouring id. " + _SPLIT_HINT)
            for x in sft:
                if x.startswith("hitap") or "etiket" in x:
                    flagged.add(pos)
                if x.startswith("hitap"):
                    pairs = []
                    for n, hon in honorifics_in_source(
                            src.send_text, names):
                        pairs.append(self._hon_label(g, n, hon))
                    notes.append(f"id {bid}: the source has the honorific(s) {', '.join(pairs)}; write them "
                                 "attached to the name exactly like that. Never replace them with Bay, Bayan, Hanım, "
                                 "kıdemli, abla or similar words, never drop them, never attach them to a non-name word.")
            if check_names:
                low = text.casefold()
                for t in g.relevant_terms(src.send_text):
                    if t.get("type") != "character":
                        continue
                    words = [w for w in re.split(r"[\s\-']+", t["target"].casefold()) if len(w) >= 3]
                    if words and not any(w in low for w in words):
                        flagged.add(pos)
                        soft.append(f"blok {idx}: isim eksik: {t['target']}")
                        notes.append(f"id {bid}: the source line contains the name {t['target']}; keep the name "
                                     f"in this line (characters who refer to themselves by name keep doing so, "
                                     f"e.g. 'Anya'nın annesi yok', not 'Annem yok').")
            nxt = got.get(bid + 1)
            if watch and (bid in watch or bid + 1 in watch) and nxt is not None and pos + 1 < len(job.prepared):
                nsrc = job.prepared[pos + 1].send_text
                pair = ((text, nxt, src.send_text, nsrc) if len(text) <= len(nxt) else (nxt, text, nsrc, src.send_text))
                if _repeats_neighbor(*pair):
                    short_id = bid if pair[0] is text else bid + 1
                    flagged.update((pos, pos + 1))
                    soft.append(f"blok {idx}: tekrar: id {short_id} komşu satırdaki sözcükleri yineliyor")
                    notes.append(f"ids {bid} and {bid + 1}: one sentence is split across them and you repeated "
                                 f"the same words in both. Write each part of the sentence only once, in the id "
                                 "during which it is spoken. " + _SPLIT_HINT)
            if g is not None and g.terms:
                low = _fold(text)
                for t in g.relevant_terms(src.send_text):
                    if t.get("type") not in ENFORCE_TYPES or not t["target"][:1].isupper():
                        continue
                    if not _term_present(t["target"], low):
                        flagged.add(pos)
                        soft.append(f"blok {idx}: terim eksik: {t['target']}")
                        notes.append(f"id {bid}: the glossary fixes this name as \"{t['target']}\"; write it "
                                     f"exactly like that (only {self.rules.name if not self.rules.is_default else 'target-language'} "
                                     f"suffixes may be attached, e.g. {t['target']}'i, {t['target']}'nin). "
                                     "Do not translate or reword it.")
            out[pos] = text
        return out, hard, soft, notes

    async def _run_chunk(self, job: FileJob, c: Chunk, prev: dict[int, str] | None,
                         notes_in: list[str] | None = None, attempts: int | None = None,
                         sub: bool = False) -> dict[int, str]:
        """Bir parçayı çevirir ve doğrular. Yanıtın çoğu doğruysa yalnızca sorunlu satırlar (ve aradakiler)
        doğru çevrilmiş komşularıyla birlikte yeniden sorulur (akıllı yeniden deneme: daha az token).
        sub=True: akıllı yeniden denemenin alt parçası (ilerleme çubuğu ayrıca sayılmaz)."""
        notes: list[str] = list(notes_in or [])
        max_out = min(self.max_out_cfg, max(2048, self._est_out(job, c) * 3))
        attempts = attempts or self.max_val_attempts
        last_soft: list[str] = []
        last_out: dict[int, str] | None = None
        last_err = ""
        watch: set[int] = set()

        def done(out: dict[int, str], soft: list[str]) -> dict[int, str]:
            job.warnings.extend(f"chunk {c.number}: {x}" for x in soft)
            job.honorific_issues += sum("hitap eki eksik" in x for x in soft)
            for x in soft:
                m = re.match(r"blok (\d+): (.*)", x)
                if m:
                    pos = self._pos_of_index(job, int(m.group(1)))
                    if pos is not None:
                        job.suspects.setdefault(pos, []).append(m.group(2))
            if self.progress and not sub:
                self.progress.chunk_ok(job, c)
            return out

        for attempt in range(1, attempts + 1):
            user = self._payload(job, c, prev, notes or None)
            try:
                data = await self._call(job, c, user, max_out, attempt)
            except ProviderError as e:
                last_err = str(e)
                if e.length:      # yanıt sığmadı: bir sonraki denemede sınır iki katı
                    max_out = min(self.max_out_cfg, max_out * 2)
                log.debug("%s parça %d%s deneme %d: %s", job.rel, c.number, c.part, attempt, e)
                if self.progress and attempt < attempts:
                    self.progress.retry(job, c, last_err)
                continue
            flagged: set[int] = set()
            out, hard, soft, new_notes = self._validate(job, c, data, watch, flagged)
            hon = [x for x in soft if "hitap eki eksik" in x or "tekrar:" in x]
            other = [x for x in soft if "etiket" in x or "isim eksik" in x or "terim eksik" in x]
            retry_soft = (hon and attempt < attempts) or (other and attempt < 2)
            if not hard and not retry_soft:
                return done(out, soft)
            reason = "; ".join((hard or hon + other)[:5])
            if not hard:
                last_soft, last_out = soft, out
            # Akıllı yeniden deneme: yalnızca sorunlu satırlar
            if attempt < attempts and -1 not in flagged and flagged and len(c.targets) > 2:
                good = {p: t for p, t in out.items() if p not in flagged}
                lo, hi = min(flagged), max(flagged)
                sub_t = [p for p in c.targets if lo <= p <= hi]
                if len(sub_t) <= max(3, len(c.targets) // 2):
                    log.debug("%s parça %d%s deneme %d: yalnızca %d satır yeniden soruluyor: %s", job.rel, c.number,
                              c.part, attempt, len(sub_t), reason)
                    if self.progress:
                        self.progress.retry(job, c, f"{len(sub_t)} satır: " + reason.split(": ", 1)[-1][:60])
                    sc = Chunk(number=c.number, part=f"{c.part}r", targets=sub_t,
                               before=list(range(max(0, sub_t[0] - self.before_n), sub_t[0])),
                               after=list(range(sub_t[-1] + 1, min(len(job.prepared), sub_t[-1] + 1 + self.after_n))))
                    ctx = {**(prev or {}), **good}
                    try:
                        fixed = await self._run_chunk(job, sc, ctx, new_notes, attempts - attempt, sub=True)
                    except ChunkFailed as e:
                        last_err = str(e)
                        notes = new_notes
                        continue
                    merged = {**good, **fixed}
                    if all(p in merged for p in c.targets):
                        rest = [x for x in soft if not any(f"blok {job.srt.blocks[p].index}:" in x for p in sub_t)]
                        return done({p: merged[p] for p in c.targets}, rest)
            notes = new_notes
            last_err = reason
            log.debug("%s parça %d%s deneme %d yeniden soruluyor: %s", job.rel, c.number, c.part, attempt, last_err)
            if self.progress and attempt < attempts:
                self.progress.retry(job, c, last_err.split(": ", 1)[-1][:60])
        if last_out is not None and len(last_out) == len(c.targets):
            # Son deneme kesin hatayla bitti ama daha önce yumuşak sorunlu, eksiksiz bir yanıt vardı
            return done(last_out, last_soft)
        if last_soft:
            job.warnings += [f"chunk {c.number}: {x}" for x in last_soft]

        if len(c.targets) > 1:
            job.warnings.append(f"chunk {c.number} ({len(c.targets)} blok) doğrulanamadı, ikiye bölünüp tekrar deneniyor ({last_err})")
            a, b = split_chunk(c, len(job.srt.blocks), self.before_n, self.after_n)
            if self.progress and not sub:
                self.progress.split(job, c)
            if prev is not None:
                ra = await self._run_chunk(job, a, prev, sub=sub)
                rb = await self._run_chunk(job, b, {**prev, **ra}, sub=sub)
            else:
                ra, rb = await asyncio.gather(self._run_chunk(job, a, None, sub=sub),
                                              self._run_chunk(job, b, None, sub=sub))
            return {**ra, **rb}
        blk = job.srt.blocks[c.targets[0]]
        raise ChunkFailed(f"blok {blk.index} çevrilemedi: {last_err}")

    @staticmethod
    def _pos_of_index(job: FileJob, index: int) -> int | None:
        m = getattr(job, "_index_map", None)
        if m is None:
            m = {b.index: b.pos for b in job.srt.blocks}
            job._index_map = m
        return m.get(index)

    # ------------------------------------------------------------ dosya

    def _stage_key(self, job: FileJob) -> str:
        """Anlam kontrolünden önceki çevirinin kayıt anahtarı: dosya + kaynak + sistem metni + model."""
        from .cache import sha
        src = "\n\x1e".join(p.send_text for p in job.prepared)
        return "tr:" + sha(str(job.rel), src, job.system_prompt, str(self.s["provider"]["model"]))

    async def translate_phase(self, job: FileJob) -> None:
        """Çeviri turu (anlam kontrolü hariç). Sonuç kaydedilir: --review-only ve devam etme için."""
        t0 = time.monotonic()
        job.status = "çevriliyor"
        try:
            if self.review_only:
                saved = self.store.get_stage(self._stage_key(job)) if self.store is not None else None
                if not saved:
                    raise ChunkFailed("bu dosyanın kayıtlı çevirisi yok (önce normal çeviri yapın; kaynak, "
                                      "sözlük, kurallar ya da model değiştiyse çeviri yeniden gerekir)")
                job.results = {int(k): v for k, v in saved.items()}
                if self.progress:
                    for c in job.chunks:
                        self.progress.chunk_ok(job, c)
            elif self.sequential:
                prev: dict[int, str] = {}
                for c in job.chunks:
                    res = await self._run_chunk(job, c, prev)
                    job.results.update(res)
                    self.schedule_fragments(job, c, res)
                    if self.on_chunk is not None:
                        self.on_chunk(job, res)
                    prev.update(res)
            else:
                async def one(c):
                    res = await self._run_chunk(job, c, None)
                    self.schedule_fragments(job, c, res)   # kısa replikler hemen kontrole (ayrı sınır)
                    if self.on_chunk is not None:
                        self.on_chunk(job, res)      # ara sonuç (Kodi: altyazı parça parça yüklenir)
                    return res
                parts = await asyncio.gather(*(one(c) for c in job.chunks), return_exceptions=True)
                failed = []
                for res in parts:
                    if isinstance(res, FatalError):
                        raise res
                    if isinstance(res, BaseException):
                        if not isinstance(res, ChunkFailed):
                            raise res
                        failed.append(str(res))
                    else:
                        job.results.update(res)
                if failed:
                    raise ChunkFailed("; ".join(failed))
            if not self.review_only:
                await self._late_conlang(job)
                if self.store is not None:
                    self.store.put_stage(self._stage_key(job), {str(k): v for k, v in job.results.items()})
            job.status = "çevrildi"
        except ChunkFailed as e:
            job.errors.append(str(e))
            job.status = "başarısız"
        finally:
            job.elapsed += time.monotonic() - t0

    async def finish_phase(self, job: FileJob) -> None:
        """Anlam kontrolü + birleştirme."""
        if job.status != "çevrildi":
            return
        t0 = time.monotonic()
        try:
            self._repeat_consistency(job)
            await self._review(job)
            await self._finish_fragments(job)
            self._assemble(job)
            job.status = "tamam"
        except ChunkFailed as e:
            job.errors.append(str(e))
            job.status = "başarısız"
        finally:
            job.elapsed += time.monotonic() - t0

    def _repeat_consistency(self, job: FileJob) -> None:
        """Filmde tekrar eden sahne (geri dönüş, hatırlama): satır önceki ve sonraki satırıyla birlikte aynen
        tekrar ediyorsa ilk çevirisi kullanılır; aynı replik iki yerde farklı çevrilmesin ("Common gods.")."""
        n = len(job.prepared)

        def norm(i: int) -> str:
            if not 0 <= i < n:
                return ""
            return " ".join(PLACEHOLDER_RE.sub("", TAG_RE.sub("", job.prepared[i].send_text)).lower().split())

        first: dict[tuple, int] = {}
        for i in job.translate_pos:
            p = job.prepared[i]
            if p.passthrough or p.romanize or p.romanize_both or not job.results.get(i):
                continue
            k = (norm(i - 1), norm(i), norm(i + 1))
            if len(k[1].split()) < 2 or not (k[0] or k[2]):
                continue
            j = first.setdefault(k, i)
            if j != i and job.results[i] != job.results[j]:
                log.debug("%s blok %d: tekrar eden sahne, blok %d ile aynı çevrildi: %r -> %r", job.rel, i + 1,
                          j + 1, job.results[i], job.results[j])
                job.results[i] = job.results[j]

    # ------------------------------------------------------------ toplu istek (Batch API)

    async def prefill_batch(self, jobs: list[FileJob], phase: str, say=print) -> int:
        """Toplu istek modu: parçaların ilk denemesi (phase="translate") ya da anlam kontrolü
        (phase="review") tek seferde Batch API ile gönderilir (%50 ucuz, yanıt dakikalar içinde gelir).
        Yanıtlar önbelleğe yazılır; ardından normal akış çalışır ve bu istekleri önbellekten okur.
        Doğrulamadan geçmeyenler normal (anlık) istekle yeniden sorulur. Dönüş: önbelleğe yazılan yanıt sayısı."""
        from .cache import CachedProvider, sha
        main = self.provider
        if not isinstance(main, CachedProvider) or getattr(main.inner, "batch_json", None) is None:
            return 0
        reqs: list[dict] = []
        owner: dict[str, tuple[FileJob, CachedProvider]] = {}
        groups: dict[int, list[dict]] = {}
        for job in jobs:
            if phase == "translate":
                if self.sequential or job.status not in ("bekliyor", "çevriliyor"):
                    continue
                for c in job.chunks:
                    user = self._payload(job, c, None)
                    if main.lookup(job.system_prompt, user, ""):
                        continue
                    max_out = min(self.max_out_cfg, max(2048, self._est_out(job, c) * 3))
                    rid = f"t{len(reqs)}"
                    reqs.append({"id": rid, "system": job.system_prompt, "user": user, "max_out": max_out,
                                 "schema": None, "schema_name": ""})
                    owner[rid] = (job, main)
            else:
                if not self.review_on or job.status != "çevrildi":
                    continue
                prov = self.review_provider or main
                if not isinstance(prov, CachedProvider) or getattr(prov.inner, "batch_json", None) is None:
                    continue
                system = self._review_system(job)
                for c in job.chunks:
                    req = self._review_request(job, c)
                    if req is None or prov.lookup(system, req[0], "subtitle_review"):
                        continue
                    rid = f"r{len(reqs)}"
                    reqs.append({"id": rid, "system": system, "user": req[0], "max_out": self._review_max_out(prov),
                                 "schema": REVIEW_SCHEMA, "schema_name": "subtitle_review"})
                    owner[rid] = (job, prov)
        if not reqs:
            return 0
        for r in reqs:
            groups.setdefault(id(owner[r["id"]][1]), []).append(r)
        stored = 0
        for reqs_g in groups.values():
            prov = owner[reqs_g[0]["id"]][1]
            key = "batch:" + sha(phase, *[r["system"][-200:] + r["user"] for r in reqs_g])
            pending = self.store.get_stage(key) if self.store is not None else None
            label = "çeviri" if phase == "translate" else "anlam kontrolü"
            say(f"▶ Toplu istek ({label}): {len(reqs_g)} istek tek dosyada gönderiliyor"
                + (" (önceki toplu istek bekleniyor)" if pending else "")
                + ". Sonuç genelde birkaç dakikada gelir; Ctrl+C ile çıkarsanız sonra kaldığı yerden devam eder.")
            last = {"s": ""}

            def status(b, last=last):
                counts = getattr(b, "request_counts", None)
                txt = f"{b.status}" + (f" {counts.completed}/{counts.total}" if counts is not None else "")
                if txt != last["s"]:
                    last["s"] = txt
                    say(f"  toplu istek durumu: {txt}")

            def created(bid, key=key):
                if self.store is not None:
                    self.store.put_stage(key, {"id": bid})
            try:
                got = await prov.inner.batch_json(reqs_g, on_status=status, on_created=created,
                                                  resume_id=(pending or {}).get("id"))
            except ProviderError as e:
                if e.kind == "fatal":
                    raise FatalError(str(e)) from e
                say(f"  ! toplu istek başarısız ({e}); normal isteklerle devam ediliyor")
                if self.store is not None:
                    self.store.put_stage(key, {})
                continue
            actual = self.review_price if prov is not main and self.review_price else self.main_price
            for r in reqs_g:
                hit = got.get(r["id"])
                if hit is None:
                    continue
                data, usage = hit
                # Toplam maliyet çeviri modelinin fiyatıyla hesaplanır; Batch API %50 indirimli ve kontrol
                # modeli farklı fiyatlı olabilir: fark extra_cost'a yazılır.
                usage.extra_cost = 0.5 * (usage.cost(actual) or 0) - (usage.cost(self.main_price) or 0)
                owner[r["id"]][0].usage.add(usage)
                if data is not None:
                    prov.put(r["system"], r["user"], r["schema_name"], data, usage)
                    stored += 1
            if self.store is not None:
                self.store.put_stage(key, {})
            say(f"  toplu istek tamam: {stored} yanıt alındı")
        return stored

    async def translate_file(self, job: FileJob) -> None:
        await self.translate_phase(job)
        await self.finish_phase(job)

