"""Kısa, fiilsiz repliklerin ("Common gods.", "By you.") düşünerek ve dar kontrolü.

Düşünmeden çeviren model bu satırlarda çok anlamlı kelimeyi sık geçen anlamıyla okuyabiliyor
("Common gods." -> "Sıradan tanrılar"). Denendi: anlamı önceden çıkarıp düşünmeyen modele vermek yetmiyor
(model anlamı görüp yine yanlış yazabiliyor); en güvenilir sonuç, düşünen modelin taslağa bakıp yalnızca
yanlış anlamı kendisinin düzeltmesi.

Akış (tek yükleme): her çeviri parçası biter bitmez o parçadaki kısa replikler küçük gruplar halinde ayrı
bir sınırla (çeviri ve anlam kontrolü isteklerinin sırasına girmeden) kontrole gider. Anlam kontrolü bitince
kalan kontroller en çok FRAGMENT_WAIT saniye beklenir; düzeltmeler anlam kontrolünün değiştirmediği satırlara
işlenir, sonra altyazı birleştirilir. Bağlam yalnızca aynı parçanın çevirisinden alınır: istek her çalışmada
aynı olur ve önbellekten gelir."""
from __future__ import annotations

import asyncio
import json
import logging
import time

from .common import FatalError
from .config import lang_name
from .limiter import AdaptiveLimiter
from .provider import ProviderError
from .review import validate_fix
from .textprep import is_verbless_line

log = logging.getLogger("subtrans")

FRAGMENT_SYSTEM = """You check short subtitle lines (fragments without a verb) of "{title}" translated from {src} into {tgt}.
Each item has the source line "text", its {tgt} draft "draft", the nearby lines ("before" / "after": source and, when available, their {tgt} translation; "pause_before" = seconds of silence before a line, often a new scene).
For each item:
1. "means": in English, at most 15 words: what the speaker is saying in this exchange (who or whose is implied, which sense of each ambiguous word fits; a reply answers the line before it).
2. "verdict": "ok" if the draft says that; "fix" if the draft takes a word in the wrong sense or misses what the line means here.
3. "text": for "fix", a short natural {tgt} line with that meaning; a short full sentence is fine ('Same blood.' given as a reason -> 'Aynı kandanız.'). For "ok", repeat the draft exactly.
"fix" ONLY when the draft reads a word in a sense that is wrong for this scene, or says something false about who or whose. Everything else is "ok": a free but correct rendering, a draft that adds the implied verb or person, a shorter or longer wording, punctuation.
In a fix never: add facts or words taken from the neighbouring lines, change who is spoken to or who speaks (you / we / I), drop part of the meaning, or restyle. Keep names, tags and placeholders exactly as in the draft.
Return JSON: {{"items": [{{"id": <number>, "means": "...", "verdict": "ok" | "fix", "text": "..."}}]}} with one item for every input item."""

FRAGMENT_SCHEMA = {
    "type": "object",
    "properties": {"items": {"type": "array", "items": {
        "type": "object",
        "properties": {"id": {"type": "integer"}, "means": {"type": "string"},
                       "verdict": {"type": "string", "enum": ["ok", "fix"]}, "text": {"type": "string"}},
        "required": ["id", "means", "verdict", "text"], "additionalProperties": False}}},
    "required": ["items"],
    "additionalProperties": False,
}

GROUP = 6           # istek başına satır (küçük gruplar: düşünen model hızlı yanıt versin)
FRAGMENT_WAIT = 15  # sn: anlam kontrolü bittikten sonra kalan kısa replik kontrolleri en çok bu kadar beklenir


class FragmentMixin:
    fragment_provider = None
    _fragment_limiter = None

    def _fragment_targets(self, job, positions) -> list[int]:
        if not job.src_lang.lower().startswith("en"):
            return []
        out = []
        for i in positions:
            p = job.prepared[i]
            if p.passthrough or p.romanize or p.romanize_both or p.song:
                continue
            if not is_verbless_line(p.send_text) or len(p.send_text.split()) > 3:
                continue
            # Bölünmüş cümlenin parçası değil: önceki satır cümleyi bitirmiş, sonraki büyük harfle başlıyor
            prev = job.prepared[i - 1].send_text.strip() if i > 0 else "."
            nxt = job.prepared[i + 1].send_text.strip() if i + 1 < len(job.prepared) else "A"
            if not prev.endswith((".", "!", "?", "…", '"')) or (nxt[:1].islower()):
                continue
            out.append(i)
        return out

    def _fragment_item(self, job, i: int, own: dict) -> dict:
        """own: bu parçanın çevirisi (bağlam yalnızca bundan: istek her çalışmada aynı olsun)."""
        n = len(job.prepared)
        blocks = job.srt.blocks if job.srt is not None else []

        def ctx(k: int) -> dict:
            p = job.prepared[k]
            d: dict = {}
            sp = (p.speakers_by_line and " / ".join(x for x in p.speakers_by_line if x)) or ", ".join(p.speakers)
            if sp:
                d["speaker"] = sp
            if 0 < k < len(blocks):
                gap = (blocks[k].start_ms - blocks[k - 1].end_ms) / 1000
                if gap >= self.PAUSE_S:
                    d["pause_before"] = int(round(gap))
            d["text"] = p.send_text
            if own.get(k):
                d["translation"] = own[k]
            return d
        d = {"id": i + 1, **ctx(i)}
        d.pop("translation", None)
        d["draft"] = own[i]
        d["before"] = [ctx(k) for k in range(max(0, i - 4), i)]
        d["after"] = [ctx(k) for k in range(i + 1, min(n, i + 3))]
        return d

    def schedule_fragments(self, job, c, res: dict) -> None:
        """Bir çeviri parçası bitince çağrılır: o parçanın kısa repliklerini kontrole gönderir (beklemez)."""
        if self.fragment_provider is None or not res:
            return
        targets = [i for i in self._fragment_targets(job, c.targets) if res.get(i)]
        if not targets:
            return
        if self._fragment_limiter is None:     # çeviri ve anlam kontrolü isteklerinin sırasına girmesin
            self._fragment_limiter = AdaptiveLimiter(24, 24)
        title = job.series or str(job.rel).split(" [")[0].rsplit(".", 1)[0]
        system = FRAGMENT_SYSTEM.format(title=title, src=lang_name(job.src_lang),
                                        tgt=lang_name(self.s["language"]["target"]))
        own = dict(res)
        for k in range(0, len(targets), GROUP):
            group = targets[k:k + GROUP]
            job.fragment_tasks.append(asyncio.ensure_future(self._fragment_group(job, system, group, own)))
        job.fragment_lines += len(targets)

    async def _fragment_group(self, job, system: str, group: list, own: dict) -> None:
        prov = self.fragment_provider
        user = json.dumps({"items": [self._fragment_item(job, i, own) for i in group]}, ensure_ascii=False,
                          separators=(",", ":"))
        max_out = 2000 + 300 * len(group)           # düşünme token'ları da bu sınıra dahil
        data = None
        for attempt in range(3):
            try:
                async with self._fragment_limiter:
                    data, usage = await prov.complete_json(system, user, max_out,
                                                           schema=FRAGMENT_SCHEMA, schema_name="fragment_check")
                job.usage.add(usage)
                break
            except ProviderError as e:
                if e.kind == "fatal":
                    log.warning("Kısa replik kontrolü yapılamadı (%s); atlandı.", e)
                    break
                if e.length:
                    max_out *= 2
                log.debug("%s kısa replik kontrolü deneme %d: %s", job.rel, attempt + 1, e)
                await asyncio.sleep((1.5 ** attempt) * self.backoff_scale)
        items = data.get("items") if isinstance(data, dict) else None
        if not isinstance(items, list):
            job.fragment_lost += len(group)
            log.debug("%s: %d satırlık kısa replik grubu alınamadı", job.rel, len(group))
            return
        names = self._names(job)
        want = {i + 1: i for i in group}
        for it in items:
            if not isinstance(it, dict) or it.get("verdict") != "fix":
                continue
            try:
                pos = want.get(int(it.get("id")))
            except (TypeError, ValueError):
                continue
            if pos is None:
                continue
            orig = own[pos]
            ok, why = validate_fix(job.prepared[pos], orig, str(it.get("text") or ""), names)
            if ok is None:
                log.debug("%s blok %d: kısa replik önerisi alınmadı (%s): %r", job.rel, pos + 1, why, it.get("text"))
                continue
            log.debug("%s blok %d: kısa replik düzeltmesi (%s): %r -> %r", job.rel, pos + 1,
                      it.get("means", ""), orig, ok)
            job.fragment_fixes[pos] = (orig, ok)

    async def _finish_fragments(self, job) -> None:
        """Anlam kontrolünden sonra: kalan kontrolleri bekler, düzeltmeleri işler."""
        if not job.fragment_tasks:
            return
        t0 = time.monotonic()
        pending = [t for t in job.fragment_tasks if not t.done()]
        if pending:
            await asyncio.wait(pending, timeout=FRAGMENT_WAIT)
        late = [t for t in job.fragment_tasks if not t.done()]
        for t in late:
            t.cancel()
        for t in job.fragment_tasks:
            if t.done() and not t.cancelled() and isinstance(t.exception(), FatalError):
                raise t.exception()
        applied = {}
        for pos, (orig, fix) in sorted(job.fragment_fixes.items()):
            if job.results.get(pos) == orig:     # anlam kontrolü ya da tutarlılık bu satırı değiştirmediyse
                applied[pos] = orig
                job.results[pos] = fix
        # Aynı kaynak satırın kopyaları (tekrar eden sahne) düzeltmeyi izler; anlam kontrolünün ayrıca düzelttiği
        # kopyalar olduğu gibi kalır
        for q, v in list(job.results.items()):
            if q in applied:
                continue
            for p, old in applied.items():
                if v == old and job.prepared[q].send_text == job.prepared[p].send_text:
                    job.results[q] = job.results[p]
                    break
        job.fragment_applied = len(applied)
        log.debug("%s: kısa replik kontrolü: %d satır, %d düzeltme, %d kayıp, %d grup yetişmedi, %.1f sn beklendi",
                  job.rel, job.fragment_lines, len(applied), job.fragment_lost, len(late), time.monotonic() - t0)
