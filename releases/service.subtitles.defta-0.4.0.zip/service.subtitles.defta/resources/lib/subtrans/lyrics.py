"""Şarkı sözleri: blok olarak bulunur ve seçilen moda göre hazırlanır.

Bulma: ♪/# işaretli bloklar, ♪ ile açılıp birkaç blok sonra kapanan şarkılar, şarkı stili (ASS: OP, ED,
song, kara...) ve şarkıya bitişik romaji blokları. Yalnızca ilk satırı işaretli şarkılar da bütün olarak bulunur.

Satır türleri: romaji (Latin harfli Japonca), yerli yazı (かな/漢字, 한글, кирилл...), Latin (çoğunlukla
İngilizce anlam satırı; şarkı İngilizceyse sözün kendisi). Aynı anda başlayan bloklar (ASS'de romaji +
İngilizce ayrı satır) birlikte değerlendirilir.

Modlar:
  translate  yalnızca anlamın çevirisi; romaji / yerli yazı satırı atılır
  keep       sözler Latin harfleriyle olduğu gibi; İngilizce anlam satırı atılır, yerli yazı romajiye çevrilir;
             kaynakta yalnızca İngilizce söz varsa İngilizce kalır
  both       Latin harfli orijinal, hemen altında parantez içinde çevirisi"""
from __future__ import annotations

import re
from dataclasses import dataclass

LYRIC_MARK_RE = re.compile(r"[♪♫]|^\s*#|#\s*$")
_SONG_STYLE_RE = re.compile(r"(?i)\bop\b|\bed\b|^op|^ed|opening|ending|song|kara|lyric|insert|romaji|kanji")
_TAGS_RE = re.compile(r"<[^>]+>|\{[^}]*\}")
_NATIVE_RE = re.compile(r"[぀-ヿ㐀-鿿가-힯Ѐ-ӿͰ-Ͽ"
                        r"؀-ۿ֐-׿฀-๿ऀ-ॿ]")
_SYL = r"(?:(?:ky|gy|sh|ch|j|ny|hy|by|py|my|ry|ts|[kgsztdnhbpmyrwf])?[aiueo]|n)"
_SYL_RE = re.compile(rf"^(?:{_SYL})+$")
_PARTICLES = {"no", "wa", "ga", "wo", "ni", "de", "mo", "to", "ka", "yo", "ne", "e", "made", "kara", "dake"}
RUN_GAP_MS = 8000          # şarkı içinde iki blok arası en fazla bu kadar boşluk
RUN_MAX = 16               # ♪ ile açılan şarkı en fazla bu kadar blok sürer
SAME_TIME_MS = 400         # aynı anda başlayan bloklar birlikte (romaji + anlam ayrı satırda)


def plain(line: str) -> str:
    s = _TAGS_RE.sub("", line)
    return re.sub(r"[♪♫#]", "", s).strip().strip("-–—").strip()


def _words(line: str) -> list[str]:
    return re.findall(r"[a-z]+", plain(line).lower().replace("'", ""))


def is_native(line: str) -> bool:
    return bool(_NATIVE_RE.search(line))


def is_romaji(line: str, lenient: bool = False) -> bool:
    """Romaji mi? Sıkı: en az 3 sözcük, %85'i Japonca hece kalıbında, en az bir edat.
    Gevşek (şarkının içindeyken): kısa satırlar da ("Ah, sora e") sayılır."""
    if is_native(line) or re.search(r"[À-ɏ]", plain(line)):
        return False
    w = _words(line)
    if not w:
        return False
    ok = sum(1 for x in w if _SYL_RE.match(x))
    if lenient:
        return ok == len(w) and (len(w) >= 2 or len(w[0]) >= 4)
    return len(w) >= 3 and ok / len(w) >= 0.85 and any(x in _PARTICLES for x in w)


def _is_meaning(line: str) -> bool:
    """Anlam satırı biçimi: parantez içinde ya da italik ("(That dream is...)", "<i>Fire the arrow</i>")."""
    return bool(re.match(r"^\s*(?:<[^>]+>)*\s*\(.*\)\s*(?:<[^>]+>)*\s*$", line) or line.strip().startswith("<i>"))


def _role(line: str, lenient: bool) -> str:
    if not plain(line):
        return "empty"
    if is_native(line):
        return "native"
    if is_romaji(line, lenient):
        return "romaji"
    return "latin"


def find_lyrics(blocks, styles: dict[int, str] | None = None) -> set[int]:
    """Şarkı sözü olan blokların pos değerleri."""
    styles = styles or {}
    order = sorted(blocks, key=lambda b: (b.start_ms, b.pos))
    found: set[int] = set()
    for b in order:
        if LYRIC_MARK_RE.search(_TAGS_RE.sub("", b.text)) or _SONG_STYLE_RE.search(styles.get(b.pos, "")):
            found.add(b.pos)
        elif sum(1 for ln in b.text.split("\n") if is_romaji(ln)) >= 1 and \
                all(_role(ln, True) in ("romaji", "empty") for ln in b.text.split("\n")):
            found.add(b.pos)
    # ♪ ile açılıp kapanmayan blok: kapanana kadar sonraki bloklar da şarkı. Romaji şarkıda yalnızca romaji /
    # anlam satırları sayılır; kaynak dilde (İngilizce) şarkıda bloklar arası boşluk kısa olmalı.
    run = None
    for b in order:
        lines = [ln for ln in b.text.split("\n") if plain(ln)]
        closes = any(re.search(r"[♪♫]\s*$", _TAGS_RE.sub("", ln)) for ln in lines)
        if run is not None:
            gap = b.start_ms - run["end"]
            fits = all(_role(ln, True) in ("romaji", "native") or _is_meaning(ln) for ln in lines) \
                if run["romaji"] else gap <= 2500
            if gap > RUN_GAP_MS or run["n"] >= RUN_MAX or not lines or not fits:
                run = None
            else:
                found.add(b.pos)
                run["n"] += 1
                run["end"] = max(run["end"], b.end_ms)
                if closes:
                    run = None
                continue
        if lines and re.match(r"^[♪♫]", _TAGS_RE.sub("", lines[0]).strip()) and not closes:
            run = {"n": 0, "end": b.end_ms,
                   "romaji": any(_role(ln, True) in ("romaji", "native") for ln in lines)}
    # Şarkıya bitişik (araya konuşma girmeden) romaji blokları ve aynı anda başlayan anlam blokları
    changed = True
    while changed:
        changed = False
        for i, b in enumerate(order):
            if b.pos in found:
                continue
            near = [o for o in order[max(0, i - 3):i + 4] if o.pos in found and o.pos != b.pos]
            lines = [ln for ln in b.text.split("\n") if plain(ln)]
            if not near or not lines:
                continue
            same_time = any(abs(o.start_ms - b.start_ms) <= SAME_TIME_MS for o in near)
            adjacent = any(min(abs(b.start_ms - o.end_ms), abs(o.start_ms - b.end_ms)) <= RUN_GAP_MS // 2
                           for o in near)
            romaji = all(_role(ln, True) == "romaji" for ln in lines)
            meaning = same_time and all(_is_meaning(ln) for ln in lines)
            if (adjacent and romaji) or meaning:
                found.add(b.pos)
                changed = True
    return found


@dataclass
class LyricPlan:
    send: str = ""             # modele gidecek metin ("" = hiçbir şey gönderilmez)
    head: str = ""             # çevirinin üstüne aynen yazılacak Latin harfli orijinal (both)
    keep: str = ""             # olduğu gibi kalacak metin (passthrough)
    drop: bool = False         # blok tümden atılır (aynı anda gösterilen diğer blok yeterli)
    romanize: bool = False     # yerli yazı: model Latin harfleriyle yazar
    romanize_both: bool = False   # yerli yazı + both: model önce romaji, altına parantez içinde çeviri
    wrap: bool = False         # çeviri parantez içinde yazılır (both)


def plan(blocks, positions: set[int], mode: str) -> dict[int, LyricPlan]:
    """Her şarkı bloğu için ne yapılacağı. mode: translate | keep | both."""
    by_pos = {b.pos: b for b in blocks}
    groups: list[list] = []
    for b in sorted((by_pos[p] for p in positions), key=lambda b: (b.start_ms, b.pos)):
        if groups and abs(groups[-1][0].start_ms - b.start_ms) <= SAME_TIME_MS:
            groups[-1].append(b)
        else:
            groups.append([b])
    out: dict[int, LyricPlan] = {}
    for g in groups:
        roles = {b.pos: [(ln, _role(ln, True)) for ln in b.text.split("\n")] for b in g}
        kinds = {r for rs in roles.values() for _, r in rs}
        has_orig = "romaji" in kinds or "native" in kinds
        for b in g:
            rs = [(ln, r) for ln, r in roles[b.pos] if r != "empty"]
            orig = [ln for ln, r in rs if r == "romaji"] or \
                   ([ln for ln, r in rs if r == "native"] if "romaji" not in kinds else [])
            native = bool(orig) and all(r == "native" for ln, r in rs if ln in orig)
            meaning = [unwrap(ln) for ln, r in rs if r == "latin"] if has_orig else []
            if not has_orig:                       # şarkı kaynak dilde (ör. İngilizce): sözün kendisi
                orig = [ln for ln, r in rs]
            p = LyricPlan()
            if mode == "translate":
                src = meaning or (orig if not ("latin" in kinds and has_orig) else [])
                if src:
                    p.send = "\n".join(src)
                else:
                    p.drop = True                  # anlamı yanındaki blokta: bu blok atılır
            elif mode == "keep":
                if native:
                    p.send, p.romanize = "\n".join(orig), True
                elif orig:
                    p.keep = "\n".join(orig)
                else:
                    p.drop = True                  # yalnızca anlam satırı: atılır
            else:                                  # both
                if native and not meaning:
                    p.send, p.romanize_both = "\n".join(orig), True
                elif orig and (meaning or not has_orig):
                    p.head, p.send, p.wrap = "\n".join(orig), "\n".join(meaning or orig), True
                elif orig:                         # romaji bloğu; anlamı aynı anda başlayan başka blokta
                    if native:
                        p.send, p.romanize = "\n".join(orig), True
                    else:
                        p.keep = "\n".join(orig)
                elif meaning:
                    p.send, p.wrap = "\n".join(meaning), True
                else:
                    p.drop = True
            out[b.pos] = p
    return out


def unwrap(line: str) -> str:
    """Anlam satırının dış parantezi atılır: "(That dream...)" -> "That dream..." (yoksa ses notu sanılır)."""
    return re.sub(r"^(\s*(?:<[^>]+>)*\s*)\((.*)\)(\s*(?:<[^>]+>)*\s*)$", r"\1\2\3", line)


def wrap_meaning(text: str) -> str:
    """Çeviri satırları parantez içinde (♪ işaretleri ve varsa dış parantez atılır)."""
    lines = []
    for ln in text.split("\n"):
        s = re.sub(r"[♪♫#]", "", ln).strip()
        s = re.sub(r"^\((.*)\)$", r"\1", s).strip()
        s = re.sub(r"(?<!\.)\.$", "", s)          # şarkı satırı: sondaki tek nokta atılır ("..." kalır)
        if s:
            lines.append(f"({s})")
    return "\n".join(lines)
