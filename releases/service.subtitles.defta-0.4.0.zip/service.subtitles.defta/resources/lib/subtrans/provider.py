"""LLM sağlayıcı katmanı. Çeviri motoru yalnızca Provider arayüzünü bilir.

İlk adapter: OpenAI uyumlu Chat Completions (OpenAI, OpenRouter, Ollama, LM Studio,
OpenAI uyumlu özel sunucular). Model adı yalnızca ayardan gelir.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass

log = logging.getLogger("subtrans")


class ProviderError(Exception):
    """kind: 'rate_limit' | 'transient' | 'fatal' | 'bad_request'"""

    def __init__(self, kind: str, message: str, length: bool = False, credit: bool = False):
        super().__init__(message)
        self.kind = kind
        self.length = length      # yanıt çıktı sınırında kesildi: daha büyük sınırla tekrar sorulmalı
        self.credit = credit      # kredi/kota bitti: hiçbir istek gönderilmez


CREDIT_MSG = "OpenAI kredisi bitti"
_CREDIT_CODES = ("insufficient_quota", "billing_hard_limit", "billing_not_active", "insufficient_balance",
                 "credit_balance", "payment_required")
_CREDIT_TEXT = ("exceeded your current quota", "insufficient_quota", "billing", "credit balance",
                "out of credits", "run out of credit", "insufficient balance", "insufficient funds")


def is_credit_error(status: int, payload) -> bool:
    """Kredi/kota bitti mi (hız sınırından farklı): kod, tür ve mesajın hepsine bakılır."""
    if status == 402:
        return True
    e = payload.get("error") if isinstance(payload, dict) else None
    parts = [str(e.get(k) or "") for k in ("code", "type", "message")] if isinstance(e, dict) else [str(e or payload)]
    low = " ".join(parts).lower()
    return any(c in low for c in _CREDIT_CODES) or any(t in low for t in _CREDIT_TEXT)


@dataclass
class Usage:
    input_tokens: int = 0
    cached_input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    requests: int = 0
    extra_cost: float = 0.0     # başka fiyatlı modelin (ör. anlam kontrolü modeli) fiyat farkı, $

    def add(self, other: "Usage") -> None:
        self.input_tokens += other.input_tokens
        self.cached_input_tokens += other.cached_input_tokens
        self.output_tokens += other.output_tokens
        self.reasoning_tokens += other.reasoning_tokens
        self.requests += other.requests
        self.extra_cost += other.extra_cost

    def cost(self, price: dict | None) -> float | None:
        if not price:
            return None
        cached_price = price.get("cached_input", price.get("input", 0.0))
        uncached = max(0, self.input_tokens - self.cached_input_tokens)
        return (uncached * price.get("input", 0.0)
                + self.cached_input_tokens * cached_price
                + self.output_tokens * price.get("output", 0.0)) / 1_000_000 + self.extra_cost


RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "translations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"id": {"type": "integer"}, "text": {"type": "string"}},
                "required": ["id", "text"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["translations"],
    "additionalProperties": False,
}


class Provider:
    name = "base"

    async def complete_json(self, system: str, user: str, max_output_tokens: int,
                            schema: dict | None = None, schema_name: str = "") -> tuple[dict, Usage]:
        raise NotImplementedError

    async def close(self) -> None:
        pass


class OpenAICompatibleProvider(Provider):
    name = "openai_compatible"

    def __init__(self, cfg: dict):
        from openai import AsyncOpenAI

        self.key_env = cfg.get("api_key_env", "OPENAI_API_KEY")
        key = os.environ.get(self.key_env, "").strip()
        if key and (any(ch.isspace() for ch in key) or any(ord(ch) > 127 for ch in key)):
            from .config import describe_key
            raise ProviderError("fatal", "API anahtarı geçersiz karakter içeriyor (boşluk veya Türkçe harf). "
                                         f".env dosyasındaki satırı kontrol edin.\n  {describe_key(self.key_env)}")
        base_url = cfg.get("base_url") or None
        is_local = bool(base_url) and any(h in base_url for h in ("localhost", "127.0.0.1", "0.0.0.0"))
        if not key and not is_local:
            raise ProviderError("fatal", f"API anahtarı bulunamadı: {cfg.get('api_key_env')} ortam "
                                         "değişkeni boş. README'deki 'API anahtarı' adımına bakın.")
        self.model = cfg["model"]
        self.client = AsyncOpenAI(api_key=key or "local", base_url=base_url,
                                  timeout=float(cfg.get("timeout_seconds", 120)), max_retries=0)
        self.reasoning_effort = cfg.get("reasoning_effort") or None
        self.temperature = cfg.get("temperature")
        self.max_tokens_param = cfg.get("max_tokens_param", "max_completion_tokens")
        self.response_mode = "json_schema"   # desteklenmezse json_object -> none

    def _params(self, system: str, user: str, max_out: int, schema: dict | None = None,
                schema_name: str = "") -> dict:
        p: dict = {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        }
        if self.max_tokens_param:
            p[self.max_tokens_param] = max_out
        if self.reasoning_effort:
            p["reasoning_effort"] = self.reasoning_effort
        if self.temperature is not None:
            p["temperature"] = self.temperature
        if self.response_mode == "json_schema":
            p["response_format"] = {"type": "json_schema", "json_schema": {
                "name": schema_name or "subtitle_translation", "strict": True,
                "schema": schema or RESPONSE_SCHEMA}}
        elif self.response_mode == "json_object":
            p["response_format"] = {"type": "json_object"}
        return p

    def _downgrade(self, msg: str) -> bool:
        """Sunucu bir parametreyi reddettiyse onu kalıcı olarak gevşetir. True = tekrar dene."""
        m = msg.lower()
        if self.reasoning_effort and "reasoning" in m:
            log.warning("Sunucu reasoning_effort=%s kabul etmedi, parametre kaldırıldı.", self.reasoning_effort)
            self.reasoning_effort = None
            return True
        if self.temperature is not None and "temperature" in m:
            log.warning("Sunucu temperature kabul etmedi, parametre kaldırıldı.")
            self.temperature = None
            return True
        if self.max_tokens_param == "max_completion_tokens" and "max_completion_tokens" in m:
            log.warning("Sunucu max_completion_tokens kabul etmedi, max_tokens kullanılacak.")
            self.max_tokens_param = "max_tokens"
            return True
        if ("response_format" in m or "json_schema" in m) and self.response_mode != "none":
            self.response_mode = "json_object" if self.response_mode == "json_schema" else "none"
            log.warning("Sunucu yapılandırılmış çıktıyı desteklemiyor, '%s' moduna geçildi.", self.response_mode)
            return True
        return False

    async def complete_json(self, system: str, user: str, max_output_tokens: int,
                            schema: dict | None = None, schema_name: str = "") -> tuple[dict, Usage]:
        import openai

        for _ in range(5):  # parametre gevşetme denemeleri
            try:
                resp = await self.client.chat.completions.create(**self._params(system, user, max_output_tokens, schema, schema_name))
                break
            except openai.BadRequestError as e:
                if self._downgrade(str(e)):
                    continue
                raise ProviderError("bad_request", f"İstek reddedildi: {e}") from e
            except openai.RateLimitError as e:
                if is_credit_error(429, getattr(e, "body", None) or {"error": str(e)}):
                    raise ProviderError("fatal", CREDIT_MSG, credit=True) from e
                raise ProviderError("rate_limit", str(e)) from e
            except openai.AuthenticationError as e:
                raise ProviderError("fatal", self._auth_message(e)) from e
            except openai.PermissionDeniedError as e:
                raise ProviderError("fatal", f"Erişim reddedildi (403): anahtarın bu modele/projeye izni yok. ({e})") from e
            except openai.NotFoundError as e:
                raise ProviderError("fatal", f"Model veya adres bulunamadı: {self.model} ({e})") from e
            except (openai.APITimeoutError, openai.APIConnectionError, openai.InternalServerError) as e:
                raise ProviderError("transient", f"{type(e).__name__}: {e}") from e
            except openai.APIStatusError as e:
                kind = "transient" if e.status_code >= 500 else "bad_request"
                raise ProviderError(kind, f"HTTP {e.status_code}: {e}") from e
        else:
            raise ProviderError("bad_request", "İstek parametreleri sunucuyla uyumlu hâle getirilemedi.")

        u = Usage(requests=1)
        if resp.usage:
            u.input_tokens = resp.usage.prompt_tokens or 0
            u.output_tokens = resp.usage.completion_tokens or 0
            ptd = getattr(resp.usage, "prompt_tokens_details", None)
            ctd = getattr(resp.usage, "completion_tokens_details", None)
            u.cached_input_tokens = (getattr(ptd, "cached_tokens", 0) or 0) if ptd else 0
            u.reasoning_tokens = (getattr(ctd, "reasoning_tokens", 0) or 0) if ctd else 0

        choice = resp.choices[0]
        content = choice.message.content or ""
        if choice.finish_reason == "length":
            raise ProviderError("bad_request", "Yanıt çıktı sınırında kesildi (finish_reason=length).", length=True)
        try:
            return parse_json_loose(content), u
        except ValueError as e:
            raise ProviderError("bad_request", f"Yanıt geçerli JSON değil: {e}") from e

    # ------------------------------------------------------------ toplu istek (Batch API)

    async def batch_json(self, requests: list[dict], poll_seconds: float = 20.0, on_status=None,
                         resume_id: str | None = None, on_created=None) -> dict[str, tuple[dict | None, Usage]]:
        """OpenAI Batch API: istekler tek dosyada gönderilir, %50 ucuzdur ama sonuç dakikalar
        (en geç 24 saat) içinde gelir. requests: {id, system, user, max_out, schema, schema_name}.
        Dönüş: id -> (veri ya da None, kullanım). Hatalı/eksik yanıtlar None döner (sonra normal sorulur)."""
        import openai
        try:
            if resume_id:
                b = await self.client.batches.retrieve(resume_id)
            else:
                lines = []
                for r in requests:
                    body = self._params(r["system"], r["user"], r["max_out"], r.get("schema"), r.get("schema_name", ""))
                    lines.append(json.dumps({"custom_id": r["id"], "method": "POST", "url": "/v1/chat/completions",
                                             "body": body}, ensure_ascii=False))
                data = ("\n".join(lines) + "\n").encode("utf-8")
                f = await self.client.files.create(file=("subtrans_batch.jsonl", data), purpose="batch")
                b = await self.client.batches.create(input_file_id=f.id, endpoint="/v1/chat/completions",
                                                     completion_window="24h")
                if on_created:
                    on_created(b.id)
            while b.status not in ("completed", "failed", "expired", "cancelled"):
                if on_status:
                    on_status(b)
                await asyncio.sleep(poll_seconds)
                b = await self.client.batches.retrieve(b.id)
            if on_status:
                on_status(b)
            out: dict[str, tuple[dict | None, Usage]] = {}
            if not getattr(b, "output_file_id", None):
                return out
            content = await self.client.files.content(b.output_file_id)
            text = content.text if hasattr(content, "text") else content.read().decode("utf-8")
        except openai.AuthenticationError as e:
            raise ProviderError("fatal", self._auth_message(e)) from e
        except openai.OpenAIError as e:
            raise ProviderError("transient", f"toplu istek başarısız: {e}") from e
        for line in text.splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                body = (row.get("response") or {}).get("body") or {}
                usage = body.get("usage") or {}
                u = Usage(requests=1, input_tokens=usage.get("prompt_tokens", 0) or 0,
                          output_tokens=usage.get("completion_tokens", 0) or 0,
                          cached_input_tokens=((usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0) or 0))
                ch = (body.get("choices") or [{}])[0]
                if (row.get("response") or {}).get("status_code") != 200 or ch.get("finish_reason") == "length":
                    out[row["custom_id"]] = (None, u)
                    continue
                out[row["custom_id"]] = (parse_json_loose((ch.get("message") or {}).get("content") or ""), u)
            except (ValueError, KeyError, TypeError, AttributeError):
                continue
        return out

    def _auth_message(self, e) -> str:
        from .config import describe_key
        return (f"Kimlik doğrulama hatası (401): OpenAI anahtarı kabul etmedi.\n"
                f"  {describe_key(self.key_env)}\n"
                f"  Sunucu: {getattr(e, 'message', e)}")

    async def check(self, strict: bool = True) -> str:
        """Anahtarı ve model erişimini token harcamadan dener.

        strict=False: yalnızca kesin anahtar hatası (401) durdurur; model sorgusunu
        desteklemeyen yerel sunucularda diğer hatalar görmezden gelinir."""
        import openai
        try:
            await self.client.models.retrieve(self.model)
            return f"Bağlantı başarılı: anahtar geçerli, '{self.model}' modeline erişim var."
        except openai.AuthenticationError as e:
            raise ProviderError("fatal", self._auth_message(e)) from e
        except Exception as e:  # noqa: BLE001
            if not strict:
                log.debug("Ön kontrol tamamlanamadı, çeviriye devam: %s", e)
                return "ön kontrol atlandı"
            if isinstance(e, openai.NotFoundError):
                raise ProviderError("fatal", f"Anahtar geçerli ama '{self.model}' modeli bulunamadı veya erişim yok.") from e
            if isinstance(e, openai.PermissionDeniedError):
                raise ProviderError("fatal", f"Anahtar geçerli ama izinleri yetersiz (403): {e}") from e
            if isinstance(e, (openai.APITimeoutError, openai.APIConnectionError)):
                raise ProviderError("fatal", f"Sunucuya bağlanılamadı: {e}") from e
            raise ProviderError("fatal", f"Beklenmeyen yanıt: {e}") from e

    async def close(self) -> None:
        await self.client.close()


def parse_json_loose(content: str) -> dict:
    """JSON'u çözer; model kod bloğu (```json) ile sardıysa onu da temizler."""
    s = content.strip()
    if s.startswith("```"):
        s = s.split("\n", 1)[1] if "\n" in s else s
        s = s.rsplit("```", 1)[0]
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        start, end = s.find("{"), s.rfind("}")
        if start != -1 and end > start:
            try:
                return json.loads(s[start:end + 1])
            except json.JSONDecodeError as e:
                raise ValueError(str(e)) from e
        raise ValueError("JSON bulunamadı")


class HttpProvider(OpenAICompatibleProvider):
    """openai kütüphanesi olmadan, yalnızca Python'un kendi urllib'iyle çalışan OpenAI uyumlu istemci
    (Kodi eklentisi için). Anahtar cfg["api_key"] ya da ortam değişkeninden gelir; hiçbir zaman loglanmaz."""

    name = "openai_http"
    batch_json = None            # toplu istek (Batch API) yok

    def __init__(self, cfg: dict):
        import concurrent.futures
        self.key_env = cfg.get("api_key_env", "OPENAI_API_KEY")
        key = str(cfg.get("api_key") or os.environ.get(self.key_env, "")).strip()
        if key and (any(ch.isspace() for ch in key) or any(ord(ch) > 127 for ch in key)):
            raise ProviderError("fatal", "OpenAI API anahtarı geçersiz karakter içeriyor (boşluk veya Türkçe harf).")
        if not key:
            raise ProviderError("fatal", "OpenAI API anahtarı girilmemiş.")
        self._key = key
        self.base_url = str(cfg.get("base_url") or "https://api.openai.com/v1").rstrip("/")
        self.model = cfg["model"]
        self.timeout = float(cfg.get("timeout_seconds", 120))
        self.reasoning_effort = cfg.get("reasoning_effort") or None
        self.temperature = cfg.get("temperature")
        self.max_tokens_param = cfg.get("max_tokens_param", "max_completion_tokens")
        self.response_mode = "json_schema"
        self.ssl_context = cfg.get("ssl_context")
        self.user_agent = str(cfg.get("user_agent") or "subtrans")
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=int(cfg.get("threads", 16)))
        self.dead: ProviderError | None = None    # kredi bitti / anahtar geçersiz: sonraki istekler hiç gitmez
        self._n429, self._first429 = 0, 0.0         # arka arkaya 429 (arada hiç başarılı yanıt yok)
        self.max_429_seconds = 180.0

    def _fatal(self, msg: str, credit: bool = False) -> ProviderError:
        self.dead = ProviderError("fatal", msg, credit=credit)
        return self.dead

    def _request(self, method: str, path: str, body: dict | None = None) -> tuple[int, dict]:
        import urllib.error
        import urllib.request
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.base_url + path, data=data, method=method, headers={
            "Authorization": "Bearer " + self._key, "Content-Type": "application/json",
            "User-Agent": self.user_agent})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=self.ssl_context) as r:
                return r.status, json.loads(r.read().decode("utf-8") or "{}")
        except urllib.error.HTTPError as e:
            try:
                payload = json.loads(e.read().decode("utf-8", "replace") or "{}")
            except ValueError:
                payload = {}
            return e.code, payload
        except (urllib.error.URLError, OSError, ValueError) as e:   # zaman aşımı, bağlantı, bozuk yanıt
            raise ProviderError("transient", f"{type(e).__name__}: {e}") from e

    async def _call(self, method: str, path: str, body: dict | None = None) -> tuple[int, dict]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self.pool, self._request, method, path, body)

    @staticmethod
    def _err(payload: dict) -> str:
        e = payload.get("error") if isinstance(payload, dict) else None
        if isinstance(e, dict):
            return str(e.get("message") or e.get("code") or e)
        return str(e or payload)[:500]

    async def complete_json(self, system: str, user: str, max_output_tokens: int,
                            schema: dict | None = None, schema_name: str = "") -> tuple[dict, Usage]:
        import time
        for _ in range(5):
            if self.dead is not None:          # önceki istekte kredi bitti: aynı anda bekleyenler de durur
                raise self.dead
            status, payload = await self._call("POST", "/chat/completions",
                                               self._params(system, user, max_output_tokens, schema, schema_name))
            if status == 200:
                self._n429 = 0
                break
            msg = self._err(payload)
            if is_credit_error(status, payload):
                raise self._fatal(CREDIT_MSG, credit=True)
            if status == 400:
                if self._downgrade(msg):
                    continue
                raise ProviderError("bad_request", f"İstek reddedildi: {msg}")
            if status == 429:
                now = time.monotonic()
                if self._n429 == 0:
                    self._first429 = now
                self._n429 += 1
                if self._n429 >= 20 and now - self._first429 >= self.max_429_seconds:
                    # Dakikalardır tek istek geçmiyor: kredi bitmiş ya da sınır çok düşük, beklemek boşuna
                    raise self._fatal("OpenAI 3 dakikadır her isteği reddediyor (429): kredi bitmiş olabilir",
                                      credit=True)
                raise ProviderError("rate_limit", msg)
            if status == 401:
                raise self._fatal(self._auth_401(msg))
            if status == 403:
                raise self._fatal(f"Erişim reddedildi (403): anahtarın bu modele izni yok. ({msg})")
            if status == 404:
                raise ProviderError("fatal", f"Model veya adres bulunamadı: {self.model} ({msg})")
            raise ProviderError("transient" if status >= 500 or status == 408 else "bad_request",
                                f"HTTP {status}: {msg}")
        else:
            raise ProviderError("bad_request", "İstek parametreleri sunucuyla uyumlu hâle getirilemedi.")
        u = Usage(requests=1)
        usage = payload.get("usage") or {}
        u.input_tokens = usage.get("prompt_tokens") or 0
        u.output_tokens = usage.get("completion_tokens") or 0
        u.cached_input_tokens = (usage.get("prompt_tokens_details") or {}).get("cached_tokens") or 0
        u.reasoning_tokens = (usage.get("completion_tokens_details") or {}).get("reasoning_tokens") or 0
        choice = (payload.get("choices") or [{}])[0]
        content = (choice.get("message") or {}).get("content") or ""
        if choice.get("finish_reason") == "length":
            raise ProviderError("bad_request", "Yanıt çıktı sınırında kesildi (finish_reason=length).", length=True)
        try:
            return parse_json_loose(content), u
        except ValueError as e:
            raise ProviderError("bad_request", f"Yanıt geçerli JSON değil: {e}") from e

    async def check(self, strict: bool = True) -> str:
        status, payload = await self._call("GET", "/models/" + self.model)
        if status == 200:
            return f"Bağlantı başarılı: anahtar geçerli, '{self.model}' modeline erişim var."
        if status == 401:
            raise ProviderError("fatal", self._auth_401(self._err(payload)))
        if not strict:
            return "ön kontrol atlandı"
        if status == 404:
            raise ProviderError("fatal", f"Anahtar geçerli ama '{self.model}' modeli bulunamadı veya erişim yok.")
        raise ProviderError("fatal", f"Beklenmeyen yanıt (HTTP {status}): {self._err(payload)}")

    def _auth_401(self, server_msg: str) -> str:
        k = self._key
        masked = f"{k[:8]}…{k[-4:]}" if len(k) > 14 else "(çok kısa)"
        notes = []
        if not k.startswith("sk-"):
            notes.append("'sk-' ile başlamıyor")
        if len(k) < 40:
            notes.append("normalden kısa")
        return (f"OpenAI anahtarı kabul edilmedi (401). Kullanılan anahtar {masked}, {len(k)} karakter"
                + (f" ({', '.join(notes)})" if notes else "") + f". Sunucu: {server_msg[:160]}")

    async def close(self) -> None:
        # İş parçacıkları beklenerek kapatılır: Kodi, açık iş parçacığı kalan bir betiği kapatırken çöker.
        self.pool.shutdown(wait=True)


def make_provider(cfg: dict) -> Provider:
    t = cfg.get("type", "openai_compatible")
    if t == "openai_http":
        return HttpProvider(cfg)
    if t == "openai_compatible":
        return OpenAICompatibleProvider(cfg)
    raise ProviderError("fatal", f"Desteklenmeyen sağlayıcı türü: {t} (yalnızca openai_compatible desteklenir)")
