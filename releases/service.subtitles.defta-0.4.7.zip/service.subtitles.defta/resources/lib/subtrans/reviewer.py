"""Anlam kontrolü (ikinci tur): kaynakla çeviri yan yana okunur, yalnızca kesin hatalar düzeltilir."""
from __future__ import annotations

from typing import TYPE_CHECKING

import asyncio
import logging

from .chunking import Chunk
from .config import lang_name
from .provider import ProviderError
import re

from .common import FatalError, _fold, _term_present
from .postfix import TAGS_STRIP_RE
from .review import REVIEW_SCHEMA, REVIEW_SYSTEM, SPLIT_REASONS, is_fragment, review_payload, validate_fix
from .textprep import PLACEHOLDER_RE

if TYPE_CHECKING:
    from .engine import FileJob

log = logging.getLogger("subtrans")

# Kaynakta kişi zamiri / iyelik: İngilizce ve Japonca (Türkçede bunlar tek bir ekle yazılır, kolay kayar)
PERSON_RE = re.compile(r"(?<![\w'])(?:I|I'm|I've|I'll|I'd)(?![\w'])|(?i:(?<![\w'])(?:me|my|mine|myself|you|you're|"
                       r"you've|you'll|you'd|your|yours|yourself|yourselves|we|we're|we've|we'll|us|our|ours|"
                       r"ourselves)(?![\w']))|私|僕|俺|あたし|わたし|ぼく|おれ|あなた|お前|おまえ|君|きみ|貴様|てめえ")


class ReviewMixin:
    # ------------------------------------------------------------ anlam kontrolü

    def _review_system(self, job: FileJob) -> str:
        tgt = self.rules.name if not self.rules.is_default else lang_name(self.rules.code)
        text = REVIEW_SYSTEM.format(src=lang_name(job.src_lang), tgt=tgt, rules=self.rules.instructions or "-")
        if job.instructions:
            text += ("\n\nSERIES-SPECIFIC INSTRUCTIONS FROM THE USER (a translation that follows them is correct)\n"
                     + job.instructions.strip())
        return text

    @staticmethod
    def _trivial(text: str) -> bool:
        """Kontrole gerek olmayacak kadar kısa satır: tek sözcük ("Evet.", "Frodo!", "Ne?").
        Hitap eki, sayı ya da yer tutucu içeren satırlar her zaman kontrol edilir."""
        plain = TAGS_STRIP_RE.sub("", text)
        if PLACEHOLDER_RE.search(plain) or re.search(r"\d", plain) or "-" in plain.strip("-– "):
            return False
        words = re.findall(r"[^\W\d_]+", plain)
        return len(words) <= 1 and len(plain.strip()) <= 14 and not re.search(r"[\u3040-\u9fff\uac00-\ud7af]", plain)

    def _review_request(self, job: FileJob, c: Chunk) -> tuple[str, int] | None:
        """(istek metni, kontrol edilecek blok sayısı) ya da None (gönderilecek satır yoksa)."""
        def src_item(i: int) -> dict:
            p = job.prepared[i]
            d: dict = {"id": i + 1}
            if p.speakers_by_line:
                d["speakers_by_line"] = p.speakers_by_line
            elif p.speakers:
                d["speaker"] = ", ".join(p.speakers)
            if p.notes:
                d["note"] = " ".join(p.notes)
            d["source"] = p.send_text
            return d
        check = []
        for i in c.targets:
            if i not in job.results or (job.prepared[i].romanize or job.prepared[i].romanize_both):
                continue
            if self._trivial(job.prepared[i].send_text):
                continue
            item = {**src_item(i), "translation": job.results[i]}
            if PERSON_RE.search(job.prepared[i].send_text):
                item["check_person"] = True     # kişi / iyelik eki ayrıca denetlensin ("my pocket" -> "cebimde")
            check.append(item)
        if not check:
            return None
        gl = None
        # Kontrolde sözlüğün yalnızca bu parçada geçen kısmı verilir: tam sözlükle model, satırda geçmeyen
        # terimleri de "düzeltmeye" kalkıyor ("power of the Ring" -> "Güç Yüzüğü").
        if job.glossary is not None and job.glossary.terms:
            text = "\n".join(job.prepared[i].send_text for i in c.before + c.targets + c.after)
            gl = job.glossary.relevant(text) or None
        def ctx_item(i: int) -> dict:
            # Bağlam satırının çevirisi de verilir: parça kenarında bölünen cümle bütün olarak okunur.
            # Kontrol öncesi hali kullanılır: parçalar aynı anda kontrol edilir, komşunun düzeltmesi
            # bağlamı değiştirirse istek her çalışmada farklı olur ve önbellekten gelmez.
            d = src_item(i)
            t = job.draft.get(i, job.results.get(i))
            if t is not None and not job.prepared[i].passthrough:
                d["translation"] = t
            return d
        user = review_payload(check, [ctx_item(i) for i in c.before], [ctx_item(i) for i in c.after], gl,
                              self._scene(job, c))
        return user, len(check)

    def _review_max_out(self, prov) -> int:
        return 16000 if prov is not self.provider else 4096

    async def _review(self, job: FileJob) -> None:
        """İkinci tur: her parça kaynak + çeviriyle birlikte yeniden okunur, yalnızca anlamı yanlış
        ya da Türkçesi bozuk satırlar düzeltilir. Hata olursa çeviri olduğu gibi kalır."""
        if not self.review_on or self.provider is None or not job.results:
            return
        system = self._review_system(job)
        names = self._names(job)
        job.draft = dict(job.results)
        if self.progress:
            self.progress.review_begin(job, len(job.chunks))
        await asyncio.gather(*(self._review_chunk(job, c, system, names) for c in job.chunks))
        if job.review_fixes:
            log.debug("%s: anlam kontrolünde %d blok düzeltildi", job.rel, job.review_fixes)
        if job.review_skipped:
            log.debug("%s: %d tek sözcüklük blok anlam kontrolüne gönderilmedi", job.rel, job.review_skipped)

    async def _review_chunk(self, job: FileJob, c: Chunk, system: str, names: set[str] | None) -> None:
        try:
            await self._review_chunk_inner(job, c, system, names)
        finally:
            if self.progress:
                self.progress.review_done(job, c)

    async def _review_chunk_inner(self, job: FileJob, c: Chunk, system: str, names: set[str] | None) -> None:
        req = self._review_request(job, c)
        n_targets = sum(1 for i in c.targets if i in job.results)
        if req is None:
            job.review_skipped += n_targets
            return
        user, n_check = req
        job.review_skipped += n_targets - n_check
        data = None
        max_out = None
        for attempt in range(3):
            try:
                prov = self.review_provider or self.provider
                max_out = max_out or self._review_max_out(prov)
                async with self.limiter:
                    data, usage = await prov.complete_json(system, user, max_out,
                                                           schema=REVIEW_SCHEMA, schema_name="subtitle_review")
                if prov is not self.provider and self.review_price and self.main_price:
                    usage.extra_cost = (usage.cost(self.review_price) or 0) - (usage.cost(self.main_price) or 0)
                job.usage.add(usage)
                await self.limiter.on_success()
                break
            except ProviderError as e:
                if e.kind == "fatal" and self.review_provider is not None:
                    # Kontrol modeline erişim yoksa çeviri modeliyle devam edilir, çeviri durmaz
                    log.warning("Anlam kontrolü modeli kullanılamadı (%s); çeviri modeliyle devam ediliyor.", e)
                    self.review_provider = None
                    max_out = None
                    continue
                if e.kind == "fatal":
                    raise FatalError(str(e)) from e
                if e.kind == "rate_limit":
                    await self.limiter.on_rate_limit()
                if e.length:
                    max_out = min(self.max_out_cfg, (max_out or 4096) * 2)
                log.debug("%s parça %d anlam kontrolü denemesi %d: %s", job.rel, c.number, attempt + 1, e)
                await asyncio.sleep((1.5 ** attempt) * self.backoff_scale)
        fixes = data.get("fixes") if isinstance(data, dict) else None
        if not isinstance(fixes, list):
            return
        want = {i for i in c.targets if i in job.results and not (job.prepared[i].romanize or job.prepared[i].romanize_both)
                and not self._trivial(job.prepared[i].send_text)}
        before_fix = dict(job.results)          # komşu karşılaştırması özgün çeviriyle yapılır
        all_names = tuple(t["target"] for t in job.glossary.terms
                          if t["target"][:1].isupper()) if job.glossary is not None else ()
        n_valid = sum(1 for f in fixes if isinstance(f, dict) and str(f.get("id", "")).isdigit()
                      and int(f["id"]) - 1 in want)
        if n_valid > max(3, int(len(want) * 0.4)):
            # Bu kadar çok "hata" gerçek değil, model üslubu değiştirmeye başlamıştır: parçaya dokunma
            log.debug("%s parça %d: anlam kontrolü %d/%d satır için öneri verdi, hiçbiri alınmadı",
                      job.rel, c.number, n_valid, len(want))
            return
        decided: dict[int, tuple[str | None, str, dict]] = {}
        for f in fixes:
            try:
                pos = int(f.get("id")) - 1
            except (TypeError, ValueError, AttributeError):
                continue
            if pos not in want or pos in decided:
                continue
            orig = job.results[pos]
            if str(f.get("certainty", "certain")).lower() != "certain":
                job.suspects.setdefault(pos, []).append("kontrol emin değil: " + str(f.get("problem", ""))[:140]
                                                        + f" → öneri: {str(f.get('text', ''))[:120]}")
                log.debug("%s blok %d: anlam kontrolü emin değil, alınmadı: %r", job.rel,
                          job.srt.blocks[pos].index, f.get("text"))
                continue
            nb = tuple(before_fix.get(p, "") for p in (pos - 1, pos + 1))
            nxt = job.prepared[pos + 1].send_text if pos + 1 < len(job.prepared) else ""
            frag = is_fragment(job.prepared[pos].send_text, nxt) or \
                (pos > 0 and is_fragment(job.prepared[pos - 1].send_text, job.prepared[pos].send_text))
            new, why = validate_fix(job.prepared[pos], orig, str(f.get("text", "")), names, nb, all_names, frag)
            if new is not None and job.glossary is not None:
                low_o, low_n = _fold(orig), _fold(new)
                for t in job.glossary.relevant_terms(job.prepared[pos].send_text):
                    if _term_present(t["target"], low_o) and not _term_present(t["target"], low_n):
                        new, why = None, f"sözlük yazımı düşmüş: {t['target']}"
                        break
            decided[pos] = (new, why, f)
        # Yan yana satırlara gelen düzeltmeler birlikte değerlendirilir: biri bölünmüş cümle yüzünden
        # reddedildiyse komşusu da alınmaz (yoksa satırlar arasında taşınmış anlam kaybolur ya da yinelenir).
        split_rejected = {p for p, (n, w, _) in decided.items() if n is None and w in SPLIT_REASONS}
        for pos in sorted(decided):
            new, why, f = decided[pos]
            if new is not None:
                q = pos
                while q - 1 in decided:
                    q -= 1
                group = []
                while q in decided:
                    group.append(q)
                    q += 1
                if any(p in split_rejected for p in group):
                    new, why = None, "komşu satırın düzeltmesi reddedildi (birlikte değişmeleri gerekiyordu)"
            idx = job.srt.blocks[pos].index
            if new is None:
                log.debug("%s blok %d: anlam kontrolü önerisi alınmadı (%s): %r", job.rel, idx, why, f.get("text"))
                continue
            log.debug("%s blok %d: anlam kontrolü düzeltti (%s): %r -> %r", job.rel, idx,
                      str(f.get("problem", ""))[:120], job.results[pos], new)
            job.results[pos] = new
            job.review_fixes += 1

