"""Metin ön işleme: SDH ve konuşmacı etiketi tespiti, konum kodları, yer tutucular,
geri yerleştirme.

Korunması gereken parçalar (konum kodları, "orijinal kalsın" seçilen notlar) LLM'e
gönderilmeden önce ⟦1⟧ gibi yer tutuculara çevrilir ve dönüşte Python tarafından
deterministik olarak geri konur. Kaldırılan konuşmacı etiketleri silinmez; modele
ayrı bir "speaker" bilgisi olarak verilir ki kimin konuştuğunu bilsin ama metne yazmasın.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

POS_CODES_RE = re.compile(r"^((?:\{\\[^}]*\})+)")
TAG_RE = re.compile(r"</?[a-zA-Z][^>]*>")
# Normal ve tam genişlikli parantez/köşeli parantez: (…) （…） […] ［…］ 【…】
COLON_LABEL_RE = re.compile(r"([A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜ0-9 .'’\-]{1,30}:)(\s+)")
DASH_RE = re.compile(r"^\s*[-–]\s*(?=\S)")
LEAD_RE = re.compile(r"^(\s*[-–]?\s*)")
LINE_TAGS_RE = re.compile(r"^((?:\s*<[^>]+>)*)")   # satır başındaki <i>, <font ...> gibi etiketler
ASS_CODES_RE = re.compile(r"\{\\[^}]*\}")         # {\an8}, {\i1} gibi konum/biçim kodları
LYRIC_RE = re.compile(r"[♪♫]|^\s*#|#\s*$")
PLACEHOLDER_RE = re.compile(r"⟦\d+⟧")
LATIN_RE = re.compile(r"[A-Za-zÀ-ÿ]")

SDH_CATEGORIES = {
    "sound_notes": "SDH ses açıklamaları  örn. [kapı çarpar], (iç çeker), （拍手）",
    "speaker_labels": "Konuşmacı etiketleri  örn. (Edgar) Merhaba, （アーニャ）, JOHN: ...",
    "speaker_dashes": "Konuşmacı tireleri  örn. - Geldin mi?",
    "lyrics": "Şarkı sözleri  örn. ♪ ... ♪",
}
SDH_OPTIONS = {
    "sound_notes": ["remove", "keep", "translate"],
    "speaker_labels": ["remove", "keep", "translate"],
    "speaker_dashes": ["remove", "keep"],
    "lyrics": ["translate", "keep", "both"],   # config.toml'da "auto" da yazılabilir
}
# Kaynak bu dillerden biriyse şarkılar "auto" seçeneğinde çevrilir (izleyici orijinali okuyamaz)
NON_LATIN_LANGS = {"ja", "zh", "zh-cn", "zh-tw", "ko", "ru", "uk", "bg", "el", "ar", "fa", "he",
                   "hi", "th"}
# Enter'a basılınca seçilen varsayılanlar (her listenin ilk elemanı)
SDH_DEFAULTS = {k: v[0] for k, v in SDH_OPTIONS.items()}
OPTION_TR = {"translate": "çevir", "keep": "orijinal bırak", "remove": "kaldır", "both": "ikisi birden",
             "auto": "otomatik (Japonca vb. ise çevir, değilse orijinal)",
             "use": "yerleşik karşılığı kullan"}


CREDIT_RE = re.compile(
    r"^(?:english\s+|japanese\s+)?(?:subtitles?|subtitle\s+translation|subtitling|subbed|captions?|captioning|"
    r"translat(?:ed|ion|ions)|timing|altyaz[ıi](?:\s+çevirisi)?|çeviri|çeviren|untertitel|sous-titres|"
    r"subtítulos|sottotitoli|legendas?)\b[^\n]{0,25}?(?:\bby\b|\bvon\b|\bpar\b|\bpor\b|[:：])"
    r"|^(?:字幕|翻訳|字幕翻訳|日本語字幕)\s*[:：]",
    re.I,
)


_SITE_CREDIT_RE = re.compile(
    r"^(?:(?:re)?sync(?:ed|hroni[sz]ed)?\b[^.!?]{0,30}\bby\b|corrections?\s+by\b|ripped\s+by\b)"
    r"|\b(?:addic7ed|opensubtitles|subscene|podnapisi|yifysubtitles|tvsubtitles)\.(?:com|org|net)\b",
    re.I)


def is_site_credit(text: str) -> bool:
    """"- sync and corrections by Doctor C -" / "- www.addic7ed.com -" gibi, dosyanın ortasında da
    durabilen paylaşım sitesi künyesi mi? Bloğun bütün satırları künye olmalı."""
    lines = [re.sub(r"^[\s\-–—]+|[\s\-–—]+$", "", re.sub(r"<[^>]+>|\{\\[^}]*\}", "", ln))
             for ln in text.split("\n")]
    lines = [ln for ln in lines if ln]
    return bool(lines) and all(_SITE_CREDIT_RE.search(ln) or re.fullmatch(r"www\.\S+\.(?:com|org|net)", ln, re.I)
                               or CREDIT_RE.match(ln) for ln in lines) and any(_SITE_CREDIT_RE.search(ln) for ln in lines)


def is_credit_line(text: str) -> bool:
    """'Subtitle translation by: Lili Morita', 'Altyazı: X', '字幕翻訳：X' gibi çevirmen künyesi mi?"""
    plain = re.sub(r"<[^>]+>|\{\\[^}]*\}", "", text).strip()
    return (0 < len(plain) <= 80 and "\n" not in plain and not plain.endswith(("?", "？"))
            and bool(CREDIT_RE.match(plain)))


def option_label(category: str, option: str) -> str:
    if category == "speaker_dashes" and option == "keep":
        return "koru"
    return OPTION_TR[option]


def resolve_decisions(decisions: dict[str, str], src_lang: str) -> dict[str, str]:
    """Dosyaya özgü kararlar: "auto" şarkı seçeneğini kaynak dile göre çözer."""
    d = dict(decisions)
    if d.get("lyrics") == "auto":
        d["lyrics"] = "translate" if src_lang.lower() in NON_LATIN_LANGS else "keep"
    return d


def visible_len(line: str) -> int:
    return len(TAG_RE.sub("", line))


def count_tags(text: str) -> int:
    return len(TAG_RE.findall(text))


# ------------------------------------------------------------------ satır analizi

def _is_sound_like(inner: str) -> bool:
    """Latin harfli ve tamamen küçük harfli içerik ses notudur: (sighs), [door slams]."""
    letters = LATIN_RE.findall(inner)
    return bool(letters) and inner == inner.lower()


@dataclass
class LineParts:
    tags: str               # satır başındaki biçim etiketleri, örn. "<i>"
    dash: str               # baştaki "- " (varsa)
    label: str              # konuşmacı etiketi metni, örn. "（エドガー）" veya "JOHN:"
    label_name: str         # parantezsiz ad, örn. "エドガー"
    label_gap: str          # etiketten sonraki boşluk
    rest: str               # satırın geri kalanı
    label_is_sound: bool    # satır başındaki parantez aslında ses notu


OPEN_CH = "([（［【"
CLOSE_CH = ")]）］】"


def match_bracket(s: str, pos: int) -> int | None:
    """s[pos] açılış parantezi ise, iç içe parantezleri de sayarak kapanışın bir
    sonrasındaki konumu döndürür: （ＷＩＳＥ(ワイズ)機関員） tek parça kabul edilir."""
    if pos >= len(s) or s[pos] not in OPEN_CH:
        return None
    depth = 0
    for j in range(pos, min(len(s), pos + 80)):
        c = s[j]
        if c in OPEN_CH:
            depth += 1
        elif c in CLOSE_CH:
            depth -= 1
            if depth == 0:
                return j + 1
    return None


def _starts_with_label(line: str | None) -> bool:
    if not line:
        return False
    line = line[len(LINE_TAGS_RE.match(line).group(1)):]
    body = line[len(LEAD_RE.match(line).group(1)):]
    return match_bracket(body, 0) is not None or bool(COLON_LABEL_RE.match(body))


def split_line(line: str, next_line: str | None) -> LineParts:
    tags = LINE_TAGS_RE.match(line).group(1)
    line = line[len(tags):]
    lead = LEAD_RE.match(line).group(1)
    body = line[len(lead):]
    dash = lead if DASH_RE.match(line) else ""
    end = match_bracket(body, 0)
    if end is not None and BLEEP_RE.fullmatch(body[:end]):
        end = None                               # "(bleep) off!": etiket değil, örtülen küfür (metinde kalır)
    if end is not None:
        label = body[:end]
        inner = label[1:-1].strip()
        after = body[end:]
        gap = after[:len(after) - len(after.lstrip())]
        rest = after.lstrip()
        if rest:
            # Satır başında parantez + arkasında konuşma: konuşmacı etiketi
            # (küçük harfli Latin içerik hariç: "(sighs) I know" bir ses notudur)
            return LineParts(tags, dash, label, inner, gap, rest, _is_sound_like(inner))
        if next_line is not None and not _starts_with_label(next_line) and not _is_sound_like(inner):
            # Tek başına satırda, altındaki satır konuşma: "（外交官）\n大使館までは…"
            return LineParts(tags, dash, label, inner, gap, rest, False)
        # Tek başına not ("（拍手）") veya altında başka bir etiket var ("（せきこみ）\n（黄昏）はい？")
        return LineParts(tags, dash, label, inner, gap, rest, True)
    cm = COLON_LABEL_RE.match(body)
    if cm:
        return LineParts(tags, dash, cm.group(1), cm.group(1)[:-1].strip(), cm.group(2), body[cm.end():], False)
    return LineParts(tags, dash, "", "", "", body, False)


# Televizyonda bip sesiyle örtülen küfür: "(bleep)", "[BLEEP]", "(bleep, bleep)", "(censored)". Ses notu gibi
# silinmez; model orada söylenen küfrü Türkçesiyle yazar (yoksa "You (bleep) idiot!" -> "Seni aptal!" kalıyordu).
# "[beep]" bilerek yok: SDH'de telesekreter, monitör, telefon sesidir (küfür sanılmasın).
BLEEP_RE = re.compile(r"[(\[]\s*(?:bleep|bleeps|bleeping|bleeped|censored|expletive)"
                      r"(?:\s*[,/]?\s*(?:bleep|bleeping))*\s*[)\]]", re.I)


def _sound_spans(text: str) -> list[tuple[int, int]]:
    """Satır içindeki ses notları (başlangıç, bitiş). Bir kelimeye bitişik parantez
    (東国(オスタニア) gibi okunuş/furigana) ses notu sayılmaz; bip ile örtülen küfür de sayılmaz."""
    spans = []
    i = 0
    while i < len(text):
        end = match_bracket(text, i)
        if end is None:
            i += 1
            continue
        before = text[:i]
        if (not before or before[-1].isspace() or before[-1] in "-–") and not BLEEP_RE.fullmatch(text[i:end]):
            spans.append((i, end))
        i = end
    return spans


def detect_sdh(text: str) -> dict[str, int]:
    """Bir blok metninde hangi SDH öğelerinin bulunduğunu sayar (blok başına 0/1)."""
    found = {k: 0 for k in SDH_CATEGORIES}
    body = POS_CODES_RE.sub("", text)
    lines = body.split("\n")
    for i, line in enumerate(lines):
        p = split_line(line, lines[i + 1] if i + 1 < len(lines) else None)
        if p.label and not p.label_is_sound:
            found["speaker_labels"] = 1
        if (p.label and p.label_is_sound) or _sound_spans(p.rest):
            found["sound_notes"] = 1
        if p.dash:
            found["speaker_dashes"] = 1
        if LYRIC_RE.search(p.rest):
            found["lyrics"] = 1
    return found


# ------------------------------------------------------------------ hazırlık

@dataclass
class Prepared:
    send_text: str                      # LLM'e gidecek metin
    placeholders: dict[str, str] = field(default_factory=dict)
    prefix: str = ""                    # baştaki {\an8} gibi konum kodları
    speakers: list[str] = field(default_factory=list)  # kaldırılan etiketler (modele bağlam)
    passthrough: bool = False           # çevrilecek bir şey yok, olduğu gibi kopyalanır
    drop: bool = False                  # blok yalnızca kaldırılan nottan oluşuyordu
    blank: bool = False                 # drop + "boş bırak" modu (blok silinmez, boş görünür)
    warning: str = ""
    dialog: bool = False                # kaynakta konuşmacı tireli satırlar vardı (her satır ayrı kişi)
    nowrap: bool = False                # satır düzenine dokunma (ASS tabela / şarkı / konumlu yazı)
    dup_of: int = -1                    # aynı zamanda aynı metni taşıyan önceki blok (ASS katman kopyası)
    speakers_by_line: list[str] = field(default_factory=list)  # çok satırlı blokta satır satır konuşan ("" = belirsiz)
    notes: list[str] = field(default_factory=list)  # ses notları "(alaycı)", "[fısıldayarak]": yalnızca bağlam
    romanize: bool = False              # şarkı sözü "orijinal kalsın" + Latin dışı kaynak: Latin harflerle yaz
    romanize_both: bool = False         # şarkı "ikisi birden" + Latin dışı kaynak: romaji, altında (çeviri)
    lyric_head: str = ""                # şarkı "ikisi birden": çevirinin üstüne aynen yazılan orijinal
    lyric_wrap: bool = False            # şarkı "ikisi birden": çeviri parantez içinde
    song: bool = False                  # şarkı sözü: kısa, şiirsel çevrilsin
    max_chars: int = 0                  # ekranda kısa kalan satır: çeviri en fazla bu kadar karakter olsun
    strip_dashes: bool = False          # tireler modele gönderildi ama çıktıda istenmiyor: çeviriden sonra silinir


_EDGE_PUNCT = r"[\s\-–—.…,!?¡¿:;\"“”'‘’«»„]+"


def norm_line(s: str) -> str:
    """Satır karşılaştırma anahtarı: etiketsiz, tırnaksız, kenar noktalaması atılmış, küçük harf.
    '<i>"Tin viel elvanui' ile 'Tin viel elvanui' aynı anahtarı verir."""
    s = PLACEHOLDER_RE.sub("", TAG_RE.sub("", ASS_CODES_RE.sub("", s)))
    s = re.sub("^" + _EDGE_PUNCT + "|" + _EDGE_PUNCT + "$", "", s.strip())
    return re.sub(r"\s+", " ", s).casefold()


def conlang_key(s: str) -> str:
    """Kurgusal dil satırının çeviri anahtarı: norm_line + sonda "..." varsa "…".
    "Nai yarvaxea rasselya!" ile yarım kalan "Nai yarvaxea rasselya..." ayrı çevrilir."""
    k = norm_line(s)
    plain = TAG_RE.sub("", ASS_CODES_RE.sub("", s)).rstrip(" \"”'’)")
    return k + "…" if k and plain.endswith(("...", "…")) else k


# ---- hitap ekleri: kaynakta kaç tane var, çeviride kaç tane kaldı
_JA_HONORIFIC_RE = re.compile(r"[\u30A0-\u30FFー・]+(さん|さま|様|ちゃん|くん|君|殿|先輩|せんぱい)")
_KATAKANA_ONLY_RE = re.compile(r"[\u30A0-\u30FFー・]+")
_JA_STANDALONE_RE = re.compile(r"(?<![\u30A0-\u30FFー・])(先輩|せんぱい)")
_EN_HONORIFIC_RE = re.compile(r"(?i)\b\w+-(san|sama|kun|chan|dono|senpai|sensei|tan|nii-san|nee-san)\b")
_STANDALONE_RE = re.compile(r"(?i)(?<![-\w])(senpai|sensei)\b")
HONORIFIC_ROMAJI = {"さん": "-san", "さま": "-sama", "様": "-sama", "ちゃん": "-chan", "くん": "-kun",
                    "君": "-kun", "殿": "-dono", "先輩": "senpai", "せんぱい": "senpai"}


# Katakana ama isim olmayan sözcükler: ワンちゃん (köpecik), シッターさん (bakıcı), ママさん...
_JA_NOT_NAMES = {"ワン", "ワンコ", "ニャン", "ネコ", "ママ", "パパ", "ウサギ", "クマ", "ブタ", "ヒヨコ",
                 "オバ", "オジ", "バア", "ジイ", "オネエ", "オニイ", "シッター", "ベビーシッター", "コック",
                 "ボス", "マスター", "シスター", "ブラザー", "ナース", "ドクター", "ガイド", "メイド",
                 "ウエーター", "ウェイター", "パン", "ケーキ", "サンタ", "ポリス", "ゲスト", "オーナー"}


def honorifics_in_source(text: str, names: set[str] | None = None) -> list[tuple[str, str]]:
    """(isim, romaji ek) listesi, örn. [("カミラ", "-san"), ("", "senpai")].
    names verilirse (sözlükteki karakter adları) yalnızca o adlara bağlı ekler sayılır;
    böylece "シッターさん" (bakıcı) gibi isim olmayan sözcükler yanlış alarm vermez."""
    found = []
    for m in _JA_HONORIFIC_RE.finditer(text):
        word = m.group(0)[: -len(m.group(1))]
        if names is not None:
            if word not in names:
                continue
        elif word in _JA_NOT_NAMES:
            continue
        hon = HONORIFIC_ROMAJI[m.group(1)]
        found.append((word, hon if hon.startswith("-") else "-" + hon))   # ヨル先輩 -> Yor-senpai (tireyle)
    if names:
        # Kanji/hiragana adlar (黄昏君, 夜帷さん): sözlükteki ad + hitap eki
        others = sorted((n for n in names if n and not _KATAKANA_ONLY_RE.fullmatch(n)
                         and not re.fullmatch(r"[A-Za-z .'\-]+", n)), key=len, reverse=True)
        if others:
            pat = re.compile("(" + "|".join(re.escape(n) for n in others) + ")(さん|さま|様|ちゃん|くん|君|殿)")   # 先輩 aşağıda ayrıca sayılır
            found += [(m.group(1), HONORIFIC_ROMAJI[m.group(2)]) for m in pat.finditer(text)]
    found += [("", "senpai") for _ in _JA_STANDALONE_RE.finditer(text)]
    found += [(m.group(0).rsplit("-", 1)[0], "-" + m.group(1).lower()) for m in _EN_HONORIFIC_RE.finditer(text)]
    found += [("", m.group(1).lower()) for m in _STANDALONE_RE.finditer(text)]
    return found


def honorifics_in_output(text: str) -> int:
    return len(_EN_HONORIFIC_RE.findall(text)) + len(_STANDALONE_RE.findall(text))


_TAGS_ONLY_RE = re.compile(r"^(?:\s*</?[a-zA-Z][^>]*>)+\s*$")


def merge_tag_lines(text: str) -> str:
    """Yalnızca etiketten oluşan satırı komşusuna yapıştırır: "⟦1⟧\n</i>" -> "⟦1⟧</i>".
    (Kaynakta alt satırdaki "(anlamı)</i>" silinince ekranda boş bir satır kalmasın.)"""
    lines = text.split("\n")
    if len(lines) < 2 or not any(_TAGS_ONLY_RE.match(ln) for ln in lines):
        return text
    out: list[str] = []
    carry = ""
    for ln in lines:
        if _TAGS_ONLY_RE.match(ln):
            if out and "</" in ln:
                out[-1] += ln.strip()
            else:
                carry += ln.strip()
            continue
        out.append(carry + ln)
        carry = ""
    if carry:
        if out:
            out[-1] += carry
        else:
            out.append(carry)
    return "\n".join(out)


def _tidy(text: str) -> str:
    lines = [re.sub(r"[ \t　]{2,}", " ", ln).strip() for ln in text.split("\n")]
    return merge_tag_lines("\n".join(ln for ln in lines if ln))


# "Tangado haid! (Hold positions!)": kurgusal dil satırı + kaynağın verdiği anlam (sonda etiket olabilir)
_GLOSS_RE = re.compile(r"^(.*?\S)\s*[(（]([^()（）]+)[)）]((?:\s*</?[a-zA-Z][^>]*>)*)\s*$")


def _split_gloss(text: str) -> tuple[str, str] | None:
    """(satır, parantez içindeki anlam) ya da None."""
    m = _GLOSS_RE.match(text)
    if not m or not has_letters(m.group(2)):
        return None
    return m.group(1) + m.group(3), m.group(2).strip()


def _plain(line: str) -> str:
    plain = ASS_CODES_RE.sub("", TAG_RE.sub("", line)).strip()
    return plain[len(LEAD_RE.match(plain).group(1)):]


_GLOSS_LINE_RE = re.compile(r"[(（]([^()（）]+)[)）]")


def conlang_lines(lines: list[str]):
    """Bloğun her satırı için (satır no, kurgusal dil anahtarı, kaynağın verdiği anlam ya da "",
    anlam satırının no'su ya da -1). Anlam aynı satırda ("Tangado haid! (Hold positions!)") ya da
    hemen alttaki yalnızca parantezden oluşan satırda ("Namárië.\n(Farewell.)") olabilir."""
    plains = [_plain(x) for x in lines]
    for i, plain in enumerate(plains):
        g = _split_gloss(plain)
        if g:
            yield i, conlang_key(g[0]), g[1], i
        nxt = _GLOSS_LINE_RE.fullmatch(plains[i + 1]) if i + 1 < len(plains) else None
        if nxt and has_letters(nxt.group(1)):
            yield i, conlang_key(plain), nxt.group(1).strip(), i + 1
        else:
            yield i, conlang_key(plain), "", -1


def find_conlang(lines: list[str], line: str) -> tuple[int, str, int] | None:
    """Kaynak bloğun satırlarında kurgusal dil satırını arar: (satır no, anlam, anlam satırı) ya da None."""
    want = conlang_key(line)
    return next(((i, gl, gi) for i, k, gl, gi in conlang_lines(lines) if k == want), None)


def _build(body: str, decisions: dict[str, str], ph: dict[str, str], speakers: list[str],
           keep_keys: set[str] | None = None, notes: list | None = None,
           line_who: list[str] | None = None) -> str:
    def protect(s: str) -> str:
        tok = f"⟦{len(ph) + 1}⟧"
        ph[tok] = s
        return tok

    sound = decisions.get("sound_notes", "translate")
    labels = decisions.get("speaker_labels", "translate")
    lines = body.split("\n")
    out = []
    who_out: list[str] = []          # her çıktı satırını kim söylüyor (etiketten), "" = belirtilmemiş

    def emit(text: str, who: str) -> None:
        out.append(text)
        who_out.append(who)

    for i, line in enumerate(lines):
        p = split_line(line, lines[i + 1] if i + 1 < len(lines) else None)
        who = p.label_name if p.label and not p.label_is_sound else ""
        # Tire her zaman modele gider: kimin konuştuğunu (soru bir kişinin, cevap ötekinin) ancak böyle bilir.
        # "Kaldır" seçildiyse çeviriden sonra restore() siler.
        dash = p.dash
        head = ""
        if p.label:
            choice = sound if p.label_is_sound else labels
            if choice == "keep":
                head = protect(p.label) + p.label_gap
                if p.label_is_sound and notes is not None:
                    notes.append((i, p.label.strip()))
            elif choice == "translate":
                head = p.label + p.label_gap
            elif not p.label_is_sound:
                speakers.append(p.label_name)
            elif notes is not None:
                notes.append((i, p.label.strip()))  # kaldırılan ses notu: modele yalnızca bağlam olarak gider
        rest = p.rest
        if keep_keys:
            # Elfçe / Kara Lisan vb.: satırın tamamı yer tutucuya çevrilir, model hiç görmez.
            # Kaynak yanına anlamını yazdıysa ("Tangado haid! (Hold positions!)") o kısım atılır;
            # anlamın Türkçesi sözlükten satırın altına eklenir.
            if norm_line(rest) in keep_keys or norm_line(line) in keep_keys:
                emit(p.tags + dash + head + protect(rest), who)
                continue
            gl = _split_gloss(rest)
            if gl and norm_line(gl[0]) in keep_keys:
                emit(p.tags + dash + head + protect(gl[0]), who)
                continue
        if sound == "remove":          # (şarkı sözleri burada değil, lyrics.plan'da işlenir)
            spans = _sound_spans(rest)
            if notes is not None:
                notes.extend((i, rest[a:b].strip()) for a, b in spans)
            for a, b in reversed(spans):
                rest = rest[:a] + rest[b:]
        elif sound == "keep":
            spans = _sound_spans(rest)
            if notes is not None:
                notes.extend((i, rest[a:b].strip()) for a, b in spans)
            for a, b in reversed(spans):
                rest = rest[:a] + protect(rest[a:b]) + rest[b:]
        if not (head + rest).strip():
            dash = ""          # satırda yalnızca kaldırılan not vardı: tek başına "-" kalmasın
        emit(p.tags + dash + head + rest, who)
    result = _tidy("\n".join(out))
    if line_who is not None:
        kept = [w for t, w in zip(out, who_out) if re.sub(r"[ \t　]+", "", t)]
        # Satır sayısı tutuyorsa hizalama güvenilir (etiket satırları birleşmediyse)
        if len(kept) == len(result.split("\n")):
            line_who.extend(kept)
    return result


def _has_content(text: str) -> bool:
    return bool(re.search(r"\w", PLACEHOLDER_RE.sub("", TAG_RE.sub("", ASS_CODES_RE.sub("", text)))))


_OUT_DASH_RE = re.compile(r"^((?:<[^>]+>|\{\\[^}]*\}|⟦\d+⟧(?=\s*[-–]))*)\s*[-–]\s*(?=[^\d\s])")   # "-20 derece": eksi işareti


def strip_dashes(text: str) -> str:
    """Satır başındaki konuşmacı tirelerini siler (<i> gibi etiketler kalır)."""
    return "\n".join(_OUT_DASH_RE.sub(r"\1", ln) for ln in text.split("\n"))


def prepare(text: str, decisions: dict[str, str], keep_keys: set[str] | None = None) -> Prepared:
    p = _prepare(text, decisions, keep_keys)
    if decisions.get("speaker_dashes") == "remove":
        if p.passthrough and not p.drop:
            p.send_text = strip_dashes(p.send_text)
        elif any(DASH_RE.match(TAG_RE.sub("", ln)) for ln in p.send_text.split("\n")):
            p.strip_dashes = True
    lines = [TAG_RE.sub("", ln) for ln in text.split("\n") if ln.strip()]
    p.dialog = len(lines) > 1 and (any(DASH_RE.match(ln) for ln in lines)
                                   or sum(1 for ln in lines if _LABEL_START_RE.match(ln)) >= 2)
    return p


# Satır başında konuşmacı etiketi ve ardından söz: "（ヨル）修羅場…", "(John) Hi", "JOHN: Hi"
_LABEL_START_RE = re.compile(r"^\s*(?:[（(\[][^）)\]\n]{1,20}[）)\]]|[A-Z][A-Z .'\-]{1,20}:)\s*\S")


_INLINE_ASS_RE = re.compile(r"\{\\(?:[ibus][01]?|fn[^}\\]*|fs\d+|c&H[0-9A-Fa-f]+&|[1-4]?c&H[0-9A-Fa-f]+&)[^}]*\}")


def strip_format_tags(text: str) -> str:
    """<i>, <b>, <u>, <font ...> ve ASS'teki {\\i1} gibi biçim kodlarını siler (konum kodu {\\an8} kalır;
    o ayrı bir ayarla silinir). Satır sonları korunur."""
    out = TAG_RE.sub("", text)
    out = _INLINE_ASS_RE.sub("", out)
    return "\n".join(re.sub(r"[ \t]{2,}", " ", ln).strip() for ln in out.split("\n"))


def _prepare(text: str, decisions: dict[str, str], keep_keys: set[str] | None = None) -> Prepared:
    if decisions.get("format_tags") == "remove":
        text = strip_format_tags(text)
    m = POS_CODES_RE.match(text)
    prefix = m.group(1) if m else ""
    body = text[len(prefix):] if prefix else text

    ph: dict[str, str] = {}
    speakers: list[str] = []
    raw_notes: list[tuple[int, str]] = []
    line_who: list[str] = []
    send = _build(body, decisions, ph, speakers, keep_keys, raw_notes, line_who)
    # Birden çok satırlı blokta not hangi satırın: "2: [gasps]" (kaynak satır sırası)
    multi = len({i for i, _ in raw_notes}) > 1 or (raw_notes and len(body.split("\n")) > 1)
    notes = [(f"{i + 1}: {n}" if multi else n) for i, n in raw_notes if n]

    if not _has_content(send):
        if ph:
            # Geriye yalnızca "orijinal kalsın" denen parçalar kaldı: LLM'e göndermeden aynen yaz
            restored = send
            for tok, val in ph.items():
                restored = restored.replace(tok, val)
            return Prepared(send_text=prefix + restored, passthrough=True)
        if not _has_content(body):
            return Prepared(send_text=text, passthrough=True)  # örn. "♪〜"
        # Blok yalnızca kaldırılması istenen nottan oluşuyordu, örn. "（拍手）"
        mode = decisions.get("note_only_blocks", "delete")
        if mode == "delete":
            return Prepared(send_text="", passthrough=True, drop=True,
                            warning="blok yalnızca kaldırılan nottan oluşuyordu, silindi")
        if mode == "blank":
            return Prepared(send_text="", passthrough=True, drop=True, blank=True,
                            warning="blok yalnızca kaldırılan nottan oluşuyordu, boş bırakıldı")
        fallback = {**decisions, "sound_notes": "translate", "speaker_labels": "translate"}
        ph, speakers = {}, []
        send = _build(body, fallback, ph, speakers, keep_keys)
        if not _has_content(send):
            return Prepared(send_text=text, passthrough=True)
        return Prepared(send_text=send, placeholders=ph, prefix=prefix, speakers=speakers,
                        warning="blok yalnızca nottan oluşuyordu, not çevrildi")
    # Çok satırlı blokta en az iki satırın konuşanı belliyse satır satır liste ("JOHN", "MARY")
    # (etiket "çevir" seçildiyse zaten metnin içinde görünür, liste gerekmez)
    by_line = line_who if len(line_who) > 1 and any(line_who) \
        and decisions.get("speaker_labels") != "translate" else []
    p = Prepared(send_text=send, placeholders=ph, prefix=prefix, speakers=speakers,
                 notes=notes[:4], speakers_by_line=by_line)
    if by_line and decisions.get("speaker_dashes") == "remove":
        # Model satır satır konuşanı görünce kendiliğinden "- " ekleyebiliyor; tire istenmiyorsa silinir
        p.strip_dashes = True
    return p


def add_conlang_translations(text: str, lookup, skip=None) -> tuple[str, int]:
    """Metindeki her kurgusal dil satırının hemen altına çevirisini "(...)" olarak ekler.
    lookup(satır) -> çeviri ya da None/"" (sözlükte yoksa ya da gösterilmeyecekse).
    skip(çeviri) True dönerse eklenmez (örn. anlamı komşu blokta zaten yazıyorsa).
    Dönüş: (yeni metin, eklenen çeviri sayısı)."""
    out, added = [], 0
    for ln in text.split("\n"):
        out.append(ln)
        if not norm_line(ln):
            continue
        tr = lookup(ln)
        if not tr or (skip is not None and skip(tr)):
            continue
        low = ln.lower()
        tr_line = f"({tr.strip().strip('()')})"
        if "<i>" in low and "</i>" in low:       # italik Elfçe satır -> Türkçesi de italik
            tr_line = f"<i>{tr_line}</i>"
        out.append(tr_line)
        added += 1
    return "\n".join(out), added


_LETTER_RE = re.compile(r"[^\W\d_]")


def has_letters(s: str) -> bool:
    return bool(_LETTER_RE.search(PLACEHOLDER_RE.sub("", TAG_RE.sub("", ASS_CODES_RE.sub("", s)))))


def similar_meaning(a: str, b: str) -> bool:
    """İki kısa metin aynı anlamı mı taşıyor (biri diğerini içeriyor ya da çok benziyor)?"""
    import difflib
    fa = re.sub(r"[^\w\s]", " ", norm_line(a)).split()
    fb = re.sub(r"[^\w\s]", " ", norm_line(b)).split()
    if not fa or not fb:
        return False
    ja, jb = " ".join(fa), " ".join(fb)
    if len(ja) >= 6 and len(jb) >= 6 and (ja in jb or jb in ja):
        return True
    if difflib.SequenceMatcher(None, ja, jb).ratio() >= 0.6:
        return True
    # Sözcük kökleri örtüşüyor mu? ("Havada kokusunu alıyorum" ~ "Kokusu havada")
    stems = lambda ws: {w[:4] for w in ws if len(w) >= 3}  # noqa: E731
    sa, sb = stems(fa), stems(fb)
    small, big = (sa, sb) if len(sa) <= len(sb) else (sb, sa)
    shared = len(small & big)
    return shared >= 2 and shared / len(small) >= 0.5


# ------------------------------------------------------------------ doğrulama / geri yerleştirme

def normalize_model_text(text: str) -> str:
    """Modelin bazen gönderdiği kaçışlı satır sonlarını (\\n yazısı) gerçek satır sonuna çevirir."""
    return text.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\r\n", "\n").replace("\r", "\n")


# Latin alfabeli hedef dilde hiç bulunmaması gereken harfler (kana, kanji, hangıl, Kiril, Arap, İbrani, Tay).
# Yunan harfleri (π, Ω) ve Doğu Asya noktalaması (〜, 「」) sayılmaz.
_FOREIGN_SCRIPT_RE = re.compile(r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af\u0400-\u04ff"
                                r"\u0590-\u05ff\u0600-\u06ff\u0e00-\u0e7f]")


def has_foreign_script(text: str) -> bool:
    return bool(_FOREIGN_SCRIPT_RE.search(text))


def check_translation(src: Prepared, translated: str,
                      names: set[str] | None = None) -> tuple[list[str], list[str]]:
    """(kesin hatalar, yumuşak uyarılar) döndürür."""
    hard, soft = [], []
    if not translated.strip():
        hard.append("boş çeviri")
        return hard, soft
    for tok in src.placeholders:
        c = translated.count(tok)
        if c != 1:
            hard.append(f"yer tutucu {tok} {c} kez geçiyor (1 olmalı)")
    extra = set(PLACEHOLDER_RE.findall(translated)) - set(src.placeholders)
    if extra:
        hard.append(f"bilinmeyen yer tutucu {sorted(extra)}")
    if has_letters(src.send_text) and not has_letters(translated):
        hard.append("çeviri yalnızca noktalama (kaynakta sözcük var)")
    if count_tags(src.send_text) != count_tags(translated):
        soft.append("biçim etiketi sayısı kaynakla farklı")
    want = honorifics_in_source(src.send_text, names)
    if want and honorifics_in_output(translated) < len(want):
        soft.append("hitap eki eksik: kaynakta " + ", ".join(f"{n}{h}" if n else h for n, h in want)
                    + " var; bunlar isme bitişik aynen yazılmalı (örn. Forger-san, Yor-senpai)")
    return hard, soft


def _phrase_spans(text: str, phrases) -> list[tuple[int, int]]:
    """Metinde geçen çok kelimeli isimlerin (Orta Dünya, Kıyamet Dağı) konumları."""
    spans = []
    for ph in phrases:
        words = ph.split()
        if len(words) < 2:
            continue
        pat = r"[ \t]*\n?[ \t]*".join(re.escape(w) for w in words)
        spans += [(m.start(), m.end()) for m in re.finditer(pat, text, re.I)]
    return spans


def rewrap(text: str, max_len: int, max_lines: int, keep_together=(), dialog: bool = False) -> str:
    """Okunabilirlik sınırını aşan çeviriyi iki dengeli satıra böler.

    Diyalog tireli satırlara ("- Geldin mi?" / "- Evet.") ve boşluksuz dillere dokunmaz;
    zaten sığmayacak kadar uzun metni olduğu gibi bırakır (logda uyarı olarak görünür).
    keep_together: satır sonunda bölünmemesi gereken çok kelimeli isimler (sözlükten).
    dialog: kaynakta tireli konuşma vardı; tireler kaldırılmış olsa da her satır ayrı kişidir, birleştirilmez.
    """
    lines = text.split("\n")
    if dialog and len(lines) > 1:
        return text
    broken_name = any("\n" in text[a:b] for a, b in _phrase_spans(text, keep_together))
    # 1-3 karakterlik taşma için kaynağın satır yapısı bozulmaz ("GÖREV: 14" / "ZAMANLI BOMBAYI…")
    limit = max_len + 3 if 1 < len(lines) <= max_lines else max_len
    if max_lines < 2 or (not broken_name and len(lines) <= max_lines
                         and all(visible_len(ln) <= limit for ln in lines)):
        return text
    if len(lines) > 1 and any(DASH_RE.match(TAG_RE.sub("", ln)) for ln in lines):
        return text
    if len(lines) > max_lines and PLACEHOLDER_RE.search(text):
        return text                        # Elfçe satır (⟦1⟧) başka satırla birleştirilmez
    joined = " ".join(ln.strip() for ln in lines)
    if visible_len(joined) > max_len * 2 + 10:
        return text
    if broken_name and visible_len(joined) <= max_len:
        return joined                      # tek satıra sığıyorsa ismi bölmeden tek satır
    protected = _phrase_spans(joined, keep_together)
    mid = len(joined) // 2
    spaces = [i for i, ch in enumerate(joined)
              if ch == " " and joined.count("<", 0, i) == joined.count(">", 0, i)
              and not any(a < i < b for a, b in protected)]
    if not spaces:
        return text
    cut = min(spaces, key=lambda i: abs(i - mid))
    return joined[:cut].rstrip() + "\n" + joined[cut + 1:].lstrip()


def strip_leaked_labels(src: Prepared, text: str) -> str:
    """Kaynakta hiç parantez kalmamışken model satır başına "(Edgar) " gibi bir etiket
    yazdıysa onu siler (etiketler kaldırıldığında modelin geri eklemesini engeller)."""
    if any(ch in src.send_text for ch in OPEN_CH):
        return text
    out = []
    for ln in text.split("\n"):
        end = match_bracket(ln.lstrip(), 0)
        if end is not None and ln.lstrip()[end:].strip():
            ln = ln.lstrip()[end:].lstrip()
        out.append(ln)
    return "\n".join(out)


_SENT_END = (".", "!", "?", "…", ":", ";", "\"", "”", "»", ")", "♪")
_SENT_SPLIT_RE = re.compile(r"(?<=[.!?…])\s+(?=[\"“«]?[A-ZÇĞİÖŞÜ0-9])")


def _cap(line: str) -> str:
    m = re.match(r"^((?:<[^>]+>|⟦\d+⟧|[\"“«'‘(¡¿\s])*)([a-zçğıöşü])", line)
    if not m:
        return line
    ch = "İ" if m.group(2) == "i" else m.group(2).upper()
    return line[:m.end(1)] + ch + line[m.end():]


def fix_dialog_lines(src_text: str, text: str) -> str:
    """Kaynakta her satırı ayrı bir kişiye ait diyalog bloğu (tireli ya da etiketli satırlar):
    - model iki kişinin sözünü tek satıra yazdıysa ve tek bir cümle sınırı varsa oradan bölünür
      ("Asıl soru bu. Peki şimdi ne yapıyoruz?" -> iki satır);
    - fazladan satır varsa cümle sonu olmayan satır sonrakiyle birleştirilir;
    - her satır büyük harfle başlar ("Frodo Bey, / ben iyiyim." -> "Frodo Bey / Ben iyiyim."),
      kaynakta virgül yokken satır sonuna eklenen virgül atılır."""
    src = [ln for ln in src_text.split("\n") if ln.strip()]
    lines = text.split("\n")
    if len(src) < 2:
        return text
    if len(lines) == 1 and len(src) == 2:
        parts = _SENT_SPLIT_RE.split(lines[0])
        if len(parts) == 2:
            lines = parts
    while len(lines) > len(src):
        i = next((k for k in range(len(lines) - 1)
                  if not TAG_RE.sub("", lines[k]).rstrip().endswith(_SENT_END)), None)
        if i is None:
            break
        lines[i:i + 2] = [lines[i].rstrip() + " " + lines[i + 1].lstrip()]
    if len(lines) == len(src):
        out = []
        for s_ln, t_ln in zip(src, lines):
            s_plain = TAG_RE.sub("", PLACEHOLDER_RE.sub("", s_ln)).strip()
            s_body = DASH_RE.sub("", s_plain)
            s_body = re.sub(r"^[（(\[][^）)\]]{1,20}[）)\]]\s*", "", s_body)
            if not s_body.startswith(("...", "…")) and not s_body[:1].islower():
                t_ln = _cap(t_ln)
            if t_ln.rstrip().endswith(",") and not s_body.rstrip().endswith((",", "、", "，")):
                t_ln = t_ln.rstrip()[:-1]
            out.append(t_ln)
        lines = out
    return "\n".join(lines)


def split_slash_lines(src_text: str, text: str) -> str:
    """Model iki satırı alt alta yazmak yerine " / " ile birleştirdiyse ("Eğleniyor muydun? / İmkânsız!")
    eksik satır sayısı kadar " / " alt satıra çevrilir. Kaynakta " / " varsa dokunulmaz."""
    missing = src_text.count("\n") - text.count("\n")
    if missing <= 0 or " / " not in text or " / " in src_text:
        return text
    return text.replace(" / ", "\n", missing)


def restore(src: Prepared, translated: str, max_len: int, max_lines: int, keep_together=()) -> str:
    text = normalize_model_text(translated)
    text = "\n".join(ln.strip() for ln in text.split("\n") if ln.strip())
    text = split_slash_lines(src.send_text, text)
    text = strip_leaked_labels(src, text)
    if src.strip_dashes:
        text = strip_dashes(text)
    if src.dialog:
        text = fix_dialog_lines(src.send_text, text)
    if not src.nowrap:
        text = rewrap(text, max_len, max_lines, keep_together, src.dialog)
    for tok, val in src.placeholders.items():
        text = text.replace(tok, val)
    return src.prefix + merge_tag_lines(text)
