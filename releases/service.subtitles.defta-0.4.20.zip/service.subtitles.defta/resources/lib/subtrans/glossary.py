"""Seri sözlüğü: isim ve terimlerin tek bir yazımda kalmasını sağlar.

Akış
1. Her dosya bir seriye bağlanır (klasör adı > dosya adı > kullanıcının yazdığı ad).
2. Çeviriden önce her bölüm için tek bir istekle isimler/terimler çıkarılır.
3. Yeni terimler seri sözlüğüne eklenir; MEVCUT terimler asla değiştirilmez
   (elle düzelttiğin yazım korunur).
4. Her parçaya yalnızca o parçada geçen terimler eklenir (token tasarrufu).

Sözlük dosyası: sozlukler/<seri-adi>.<dil>.json  — elle düzenlenebilir.
"""
from __future__ import annotations

import difflib
import json
import os
import re
import tempfile
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .postfix import fix_tr_apostrophes
from .textprep import PLACEHOLDER_RE, TAG_RE, conlang_key, norm_line
from .prompts import ANALYSIS_TASKS, CONLANG_SYSTEM, EXTRACT_SYSTEM  # noqa: F401  (metinler prompts.py'de)

# ---------------------------------------------------------------- seri adı tespiti

_SEASON_DIR_RE = re.compile(r"^(?:sezon|season|seizoen|staffel|saison|temporada|s)\s*\d+$", re.I)
_RELEASE_WORDS = (r"web-?rip|web-?dl|webdl|blu-?ray|bdrip|brrip|hdtv|dvdrip|x26[45]|h\.?26[45]|hevc|aac|"
                  r"netflix|nf|amzn|cr|dsnp|hulu|japanese|english|turkish|multi|dual|subbed|dubbed|"
                  r"proper|repack|extended|uncut|remastered|complete")
_CUT_RES = [
    re.compile(r"\bS\d{1,2}\s*E\d{1,4}\b", re.I),                 # S01E13
    re.compile(r"\b\d{1,2}x\d{2,3}\b", re.I),                       # 1x13
    re.compile(r"\s[-–]\s"),                                         # "Dizi - 13", "SPY FAMILY - MISSION 1"
    re.compile(r"\b(?:episode|ep|eps|bölüm|bolum|mission|chapter|part|vol|cilt)\b\.?\s*\d", re.I),
    re.compile(r"\b(?:19|20)\d{2}\b"),                               # yıl
    re.compile(r"\b(?:480|576|720|1080|2160)[pi]\b", re.I),
    re.compile(rf"\b(?:{_RELEASE_WORDS})\b", re.I),
    re.compile(r"\b\d{1,4}\b"),                                      # tek başına bölüm numarası
]


def guess_series_from_name(stem: str) -> str:
    s = re.sub(r"\[[^\]]*\]|\([^)]*\)|【[^】]*】", " ", stem)        # [Grup], (2001), 【...】
    s = re.sub(r"[._]+", " ", s)
    cut = len(s)
    for r in _CUT_RES:
        m = r.search(s)
        if m and m.start() > 0:
            cut = min(cut, m.start())
    name = re.sub(r"\s+", " ", s[:cut]).strip(" -–_:")
    if not name:
        name = re.sub(r"\s+", " ", s).strip(" -–_:") or stem
    if name.isupper() and len(name) > 3:
        name = name.title()
    return name


def series_from_path(rel: Path) -> str:
    """kaynak/Spy x Family/Sezon 1/E01.srt -> "Spy x Family"; kaynak/Spy.x.Family.S01E13.srt -> "Spy x Family"."""
    for part in rel.parts[:-1]:
        if not _SEASON_DIR_RE.match(part.strip()):
            return part.strip()
    stem = rel.name
    for _ in range(3):                      # .en.srt / .en.sdh.srt
        stem = Path(stem).stem
        if "." not in stem or len(stem.rsplit(".", 1)[1]) > 4:
            break
    return guess_series_from_name(stem)


def slugify(name: str) -> str:
    s = unicodedata.normalize("NFKC", name).lower()
    s = s.translate(str.maketrans("çğıöşü", "cgiosu"))
    s = re.sub(r"[^\w]+", "-", s, flags=re.UNICODE).strip("-")
    return s or "seri"


def _compact(slug: str) -> str:
    return slug.replace("-", "")


def similar(a: str, b: str) -> bool:
    """'spy-family' ~ 'spy-x-family' gibi aynı serinin farklı yazımlarını yakalar."""
    ca, cb = _compact(slugify(a)), _compact(slugify(b))
    if ca == cb:
        return True
    return min(len(ca), len(cb)) >= 5 and difflib.SequenceMatcher(None, ca, cb).ratio() >= 0.88


# ---------------------------------------------------------------- sözlük

GLOSSARY_SCHEMA = {
    "type": "object",
    "properties": {
        "terms": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source": {"type": "string"},
                    "target": {"type": "string"},
                    "type": {"type": "string"},
                },
                "required": ["source", "target", "type"],
                "additionalProperties": False,
            },
        },
        "keep_ids": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["terms", "keep_ids"],
    "additionalProperties": False,
}

# Bölüm analizi: sözlük + kurgusal dil satırlarının anlamı + sahne özetleri + hitap biçimi tek istekte
ANALYSIS_SCHEMA = {
    "type": "object",
    "properties": {
        "keep_ids": GLOSSARY_SCHEMA["properties"]["keep_ids"],
        "keep_meanings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"id": {"type": "string"}, "meaning": {"type": "string"}},
                "required": ["id", "meaning"],
                "additionalProperties": False,
            },
        },
        "terms": GLOSSARY_SCHEMA["properties"]["terms"],
        "scenes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"from_id": {"type": "integer"}, "to_id": {"type": "integer"},
                               "summary": {"type": "string"}},
                "required": ["from_id", "to_id", "summary"],
                "additionalProperties": False,
            },
        },
        "address": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"speaker": {"type": "string"}, "listener": {"type": "string"},
                               "form": {"type": "string", "enum": ["informal", "formal"]},
                               "note": {"type": "string"}},
                "required": ["speaker", "listener", "form", "note"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["keep_ids", "keep_meanings", "terms", "scenes", "address"],
    "additionalProperties": False,
}

_HONORIFIC_TAIL = re.compile(
    r"(?:[-\s](?:san|sama|kun|chan|dono|senpai|sensei|nii-?san|nee-?san|nii|nee))+$", re.I)
_LATIN_RE = re.compile(r"^[\W\dA-Za-zÀ-ÿĀ-žƀ-ɏ]+$")
# Hedef dili Latin alfabesiyle yazılmayan diller (bunlarda hedef yazım Latin olmak zorunda değil)
NON_LATIN_TARGETS = {"ja", "zh", "zh-cn", "zh-tw", "ko", "ru", "uk", "bg", "el", "ar", "fa", "he",
                     "hi", "th", "ka", "hy", "sr", "mk", "be", "kk"}
# Hiçbir zaman terim olamayacak sözcükler: sayı, zamir, ünlem ("One" her "one" ile eşleşmesin).
# Eski sürümün yazdığı bu tür kayıtlar yüklenirken de atılır.
# Aile sözcükleri de ad gibi büyük harfle yazılsa terim değildir ("Mum" -> Türkçede "mum" olur).
# Gerçek milliyetler (model bazen "race" diye önerip küçük harfe çeviriyordu: "italyan yemekleri")
NATIONALITIES = {"italian", "french", "german", "spanish", "english", "british", "american", "mexican", "japanese",
                 "chinese", "korean", "russian", "turkish", "greek", "indian", "irish", "scottish", "canadian",
                 "brazilian", "portuguese", "dutch", "polish", "swedish", "arab", "persian", "african", "european",
                 "asian", "australian", "egyptian", "israeli", "cuban", "vietnamese", "thai", "filipino"}
NEVER_TERMS = {
    "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "first", "last",
    "the", "a", "an", "i", "you", "he", "she", "we", "they", "it", "yes", "no", "hey", "oh",
    "mother", "father", "mom", "mum", "mummy", "mommy", "ma", "dad", "daddy", "mama", "papa", "pa",
    "granny", "grandma", "grandpa", "gran", "nan", "uncle", "aunt", "auntie",
    "sister", "brother", "son", "daughter", "anne", "baba", "annem", "babam", "abla", "ağabey", "abi",
}
# Modelin önerisi olarak tek başına sözlüğe alınmayan genel kelimeler ("men" her cümlede "insanlar"
# diye zorlanmasın). Elle eklenen kayıtlar korunur (Doctor Who için "Doctor -> Doktor" gibi).
GENERIC_WORDS = NEVER_TERMS | {
    "master", "lord", "lady", "sir", "madam", "king", "queen", "prince", "princess", "boss",
    "teacher", "doctor", "captain", "chief", "minister", "agent", "spy", "man", "woman", "boy", "girl",
    "ring", "rings", "sword", "dog", "cat", "house", "home", "city", "east", "west", "north", "south",
    "usta", "efendi", "bey", "hanım", "men", "women", "people", "folk", "folks", "child", "children",
    "friend", "friends",
    # Japonca kaynaktan gelen cins isimlerin Türkçe hedefleri (スパイ -> casus): terim değil
    "casus", "ajan", "katil", "kiralık katil", "suikastçı", "casus aleti", "istihbarat ajanı",
    "kadın istihbarat ajanı", "telepat", "asker", "polis", "öğretmen",
}


_KATAKANA_RE = re.compile(r"[\u30A0-\u30FFー・]+")

# İngilizce kaynakta "kurgusal dil" diye işaretlenen satırın gerçekten İngilizce olup olmadığını
# anlamak için sık kelimeler. Elfçede de geçen kısa kelimeler (a, i, in, an, or, le, be, ring) yok.
EN_COMMON = set("""
you your yours the is are was were there this that these those what who whom where when why how with
have has had not cannot can't can only will would should could shall see go come get let know don't
it's i'm i'll you're we're they're that's me my mine it he she him her his they them their we us our
of to and but from at by on into out up down here now then yes all just so do does did been being am
very too more some any never ever still back away over again because about after before nothing
something everything everyone anyone someone want need must may might
""".split())


# Kurgusal dillerde (Sindarin, Quenya, Kara Lisan, Klingonca...) bağımsız sözcük olarak geçmeyen,
# tek başına "bu satır İngilizce" dedirten sözcükler. ("a", "i", "in", "an", "am", "le" bilerek yok.)
STRONG_EN = set("""
the of and you your with is are was were this that what will have from for not my we they she his our
their there would should could
""".split())


def looks_english(line: str) -> bool:
    words = re.findall(r"[a-z']+", line.lower())
    if not words:
        return False
    if any(w in STRONG_EN for w in words):
        return True
    hits = sum(w in EN_COMMON for w in words)
    return hits >= 2 or (hits >= 1 and hits / len(words) >= 0.3)


# Kısa İngilizce satırlarda sık geçen, ortak listede olmayan sözcükler ("Behold...", "Hurry!")
EN_SHORT = set("""
behold hurry follow quick quickly run fly flee stop wait listen look help alas farewell welcome hail
please sorry thank thanks yes no hello goodbye stay hold fire open close kill die dead come go
""".split())
_NON_ASCII_LETTER_RE = re.compile(r"[À-ɏ]")
# Sözcük: harf, kesme ve bozuk karakter (�) — "Nazg�l" tek sözcük kalsın, "nazg" diye bölünmesin
_WORD_RE = re.compile(r"[^\W\d_][\w'\ufffd]*|\ufffd[\w'\ufffd]*")


def english_vocab(lines) -> set[str]:
    """Kaynak dosyada açıkça İngilizce olan satırlardaki sözcükler (dosyanın kendi sözlüğü)."""
    vocab: set[str] = set()
    for block in lines:
        for ln in TAG_RE.sub("", block).split("\n"):
            # "Noro lim! (Ride fast!)": parantez içi İngilizce anlamdır, dışı Elfçe; ikisi ayrı bakılır
            parts = re.findall(r"\(([^)]*)\)?", ln) + [re.sub(r"\([^)]*\)?", " ", ln)]
            for part in parts:
                if looks_english(part):
                    vocab.update(w for w in _WORD_RE.findall(part.lower()) if len(w) >= 2)
    return vocab


def looks_english_ctx(line: str, vocab: set[str] | None) -> bool:
    """looks_english + dosyanın kendi İngilizce sözcükleri: "Isildur, hurry! Follow me." gibi
    ortak listede yeterli sözcüğü olmayan İngilizce satırları da yakalar. Elfçe harfleri (î, û, ê...)
    taşıyan satırlar hiçbir zaman İngilizce sayılmaz."""
    if looks_english(line):
        return True
    plain = TAG_RE.sub("", line)
    if _NON_ASCII_LETTER_RE.search(plain):
        return False
    words = [w for w in _WORD_RE.findall(plain.lower()) if len(w) >= 2]
    if not words:
        return False
    if len(words) == 1 and vocab and words[0] in vocab:
        return True     # tek sözcük ve dosyanın İngilizce satırlarında geçiyor: isim ya da İngilizce ("Frodo!", "Lembas.")
    hits = sum(1 for w in words if w in EN_SHORT or (vocab and w in vocab))
    return hits / len(words) >= 0.6 and (hits >= 2 or (len(words) == 1 and words[0] in EN_SHORT))


_ROMAJI_SYL = r"(?:(?:ky|gy|sh|ch|j|ny|hy|by|py|my|ry|ts|[kgsztdnhbpmyrwf])?[aiueo]|n)"
_ROMAJI_RE = re.compile(rf"^(?:{_ROMAJI_SYL})+$")
_ROMAJI_PARTICLES = {"no", "wa", "ga", "wo", "ni", "de", "mo", "to", "ka", "yo", "ne", "e", "made", "kara", "dake"}


def looks_romaji(line: str) -> bool:
    """Latin harfleriyle yazılmış Japonca (romaji) — çoğunlukla anime şarkı sözü:
    "Fumareta Hana no Namae mo Shirazuni". Gerçek bir dildir, kurgusal dil gibi aynen bırakılmaz.
    Elfçe gibi dillerden ayırmak için: en az 3 sözcük, %85'i Japonca hece kalıbında ve en az bir edat."""
    plain = TAG_RE.sub("", line)
    if _NON_ASCII_LETTER_RE.search(plain):
        return False
    words = [w for w in re.findall(r"[a-z]+", plain.lower().replace("'", ""))]
    if len(words) < 3:
        return False
    ok = sum(1 for w in words if _ROMAJI_RE.match(w))
    return ok / len(words) >= 0.85 and any(w in _ROMAJI_PARTICLES for w in words)


def filter_keep_refs(refs: list[str], raw: dict[str, str], order: list[str], src_lang: str,
                     vocab: set[str] | None = None) -> tuple[list[str], list[str]]:
    """Modelin "kurgusal dil" dediği satırları denetler. İngilizce kaynakta İngilizce görünen
    satırlar reddedilir; çoğu reddedilen ardışık bir grup tümden reddedilir
    ("You cannot hide." / "I see you." / "...death." gibi). Dönüş: (kabul, red)."""
    refs = [r for r in dict.fromkeys(refs) if r in raw]
    # Kaynak hangi dilde olursa olsun İngilizce satır kurgusal dil sayılmaz
    # (Japonca animede İngilizce şarkı sözü de çevrilmeli).
    pos = {r: i for i, r in enumerate(order)}
    refs.sort(key=lambda r: pos.get(r, 0))
    runs: list[list[str]] = []
    for r in refs:
        if runs and pos.get(r, -9) - pos.get(runs[-1][-1], -9) <= 1:
            runs[-1].append(r)
        else:
            runs.append([r])
    ok, rejected = [], []
    for run in runs:
        bad = [r for r in run if looks_english_ctx(raw[r], vocab) or looks_romaji(raw[r])]
        if bad and len(bad) * 2 > len(run):
            rejected += run
        else:
            ok += [r for r in run if r not in bad]
            rejected += bad
    return ok, rejected


def _is_latin(s: str) -> bool:
    return bool(_LATIN_RE.match(s))


def _fold_marks(s: str) -> str:
    """Küçük harf, aksan/şapka işaretleri atılmış hâl ("Lothlórien" -> "lothlorien").
    cp1252 diye okunmuş dosyadaki "ï¿½" (UTF-8 "�" baytları) tek "�" sayılır."""
    s = s.replace("ï¿½", "\ufffd")
    return "".join(c for c in unicodedata.normalize("NFD", s.casefold()) if unicodedata.category(c) != "Mn")


def _appears_in(term: str, folded_source: str) -> bool:
    """Terim kaynak metinde geçiyor mu? Bozuk kodlamalı dosyalarda harf yerine gelen "�" her harfle eşleşir
    ("Amon S�l" ~ "Amon Sûl"); "the Shire" gibi yazımlarda baştaki tanımlık aranmaz."""
    t = _fold_marks(term)
    t = re.sub(r"^(the|a|an) ", "", t)
    pat = "".join(f"(?:{re.escape(c)}|\ufffd)" if c.isalpha() else re.escape(c) for c in t)
    return re.search(pat, folded_source) is not None


# Hitap ekleri ve Japonca akrabalık hitapları sözlüğe terim olarak girmez: çeviride hep aynen
# kalırlar (Sensei -> "Öğretmen", Onii -> "Ağabey" olup "Ağabey-chan" çıkmasın)
HONORIFIC_WORDS = {
    "sensei", "senpai", "sempai", "sama", "san", "kun", "chan", "dono", "kouhai", "kohai", "shishou",
    "onii", "onee", "nii", "nee", "oniisan", "oneesan", "oniichan", "oneechan", "niisan", "neesan",
    "niichan", "neechan", "oniisama", "oneesama", "aniki", "aneki", "anija", "nii-nii", "nee-nee",
    "先生", "先輩", "せんせい", "せんぱい", "様", "さま", "さん", "くん", "君", "ちゃん", "殿",
    "お兄", "お姉", "兄", "姉", "兄さん", "姉さん", "お兄さん", "お姉さん", "お兄ちゃん", "お姉ちゃん",
    "兄貴", "姉貴", "にい", "ねえ", "にいさん", "ねえさん", "おにい", "おねえ", "おにいちゃん", "おねえちゃん",
}


def _honorific(form: str) -> bool:
    f = form.strip().strip("-").lower()
    return f in HONORIFIC_WORDS or re.sub(r"[-\s]", "", f) in HONORIFIC_WORDS


_RUBY_RE = re.compile(r"[(（]([^)）]+)[)）]")


def expand_forms(form: str) -> list[str]:
    """Japonca altyazıdaki okunuş ekli yazımlar: "黄昏(たそがれ)" -> ["黄昏(たそがれ)", "黄昏", "たそがれ"].
    Böylece satırda yalnızca 黄昏 ya da yalnızca たそがれ geçtiğinde de sözlük eşleşir."""
    out = [form]
    if _is_latin(form) or not _RUBY_RE.search(form):
        return out
    base = _RUBY_RE.sub("", form).strip()
    if base and base not in out:
        out.append(base)
    m = re.fullmatch(r"(.+?)[(（]([^)）]+)[)）]", form.strip())
    if m and m.group(2).strip() not in out and len(m.group(2).strip()) >= 2:
        out.append(m.group(2).strip())
    return out


# Kurum, unvan ve terimlerde İngilizce kalmış hedef yazım (Türkçe sözlükte "Audit Bureau",
# "Intelligence Service", "F cipher" gibi): bunlar çevrilmeliydi. Kod adları (Operation Strix,
# Project Apple) bu listede olmayan sözcüklerle yazıldığı için etkilenmez.
EN_INSTITUTION_WORDS = set("""
academy agency bureau service services intelligence department office ministry school university college
police cipher council committee institute association society union army navy force forces guard guards
church order brotherhood league company corporation bank hospital station airport national international
central secret division unit squad team headquarters government party
""".split())
INSTITUTION_TYPES = {"organization", "title", "term", "place"}


# Küçük harfli (özel ad olmayan) hedefte İngilizce kalmış cins isim: "code name", "smuggling organization"
EN_COMMON_NOUNS = set("""
organization organisation name code group gang network syndicate ring spy agent operative assassin killer
psychic mission operation target client boss member members
""".split())
_EN_SUFFIX_RE = re.compile(r"[a-z]{3,}(?:ing|tion|sion|ness|ship|ity)$")


def english_institution(target: str, ttype: str) -> bool:
    if ttype not in INSTITUTION_TYPES:
        return False
    words = re.findall(r"[a-z]+", target.lower())
    if any(w in EN_INSTITUTION_WORDS for w in words):
        return True
    # Küçük harfli hedef ve Türkçe harf yok: İngilizce cins isim mi? (Operation Strix gibi adlar büyük harfli)
    if target == target.lower() and not re.search(r"[çğıöşüâîû]", target):
        return any(w in EN_COMMON_NOUNS or _EN_SUFFIX_RE.fullmatch(w) for w in words)
    return False


@dataclass
class Glossary:
    path: Path
    series: str
    target_lang: str
    terms: list[dict] = field(default_factory=list)       # {"target", "type", "forms": [...]}
    processed_files: list[str] = field(default_factory=list)
    existed: bool = False
    removed_on_load: int = 0
    keep_lines: list[str] = field(default_factory=list)   # Elfçe vb. satırlar: asla çevrilmez
    removed_keep: list[str] = field(default_factory=list)   # yüklenirken atılan İngilizce satırlar
    keep_tr: dict[str, str] = field(default_factory=dict)  # Elfçe satır -> altında gösterilecek Türkçesi
    lower_races: bool = False                             # Türkçe: ırk adları küçük harf (elf, hobbit)
    blocked: list[str] = field(default_factory=list)      # bir daha önerilmeyecek terimler (elle yazılır)
    _matchers: dict = field(default_factory=dict, repr=False)

    # ---- dosya

    @property
    def latin_target(self) -> bool:
        return self.target_lang.lower() not in NON_LATIN_TARGETS

    def valid_target(self, tgt: str) -> bool:
        """Türkçe gibi Latin alfabeli hedefte '黄昏' gibi Japonca harfli yazım kabul edilmez."""
        return bool(tgt.strip()) and (not self.latin_target or _is_latin(tgt))

    @classmethod
    def load_or_new(cls, folder: Path, series: str, target_lang: str) -> "Glossary":
        path = folder / f"{slugify(series)}.{target_lang.lower()}.json"
        g = cls(path=path, series=series, target_lang=target_lang.lower())
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            g.series = data.get("series", series)
            g.processed_files = list(data.get("processed_files", []))
            g.blocked = [str(x).strip() for x in data.get("blocked_terms", []) if str(x).strip()]
            blocked = {x.lower() for x in g.blocked}
            bad = 0
            for t in data.get("terms", []):
                if isinstance(t, dict) and str(t.get("target", "")).strip():
                    if any(_honorific(str(f)) for f in t.get("forms", [])):
                        continue            # eski sürümün aldığı "Sensei -> Öğretmen" gibi kayıt: sessizce at
                    tgt = str(t["target"]).strip()
                    forms = [str(f) for f in t.get("forms", [])
                             if str(f).strip() and str(f).strip().lower() not in NEVER_TERMS]
                    if tgt.lower() in blocked or any(f.lower() in blocked for f in forms):
                        continue            # kullanıcı engelledi
                    if not g.valid_target(tgt) or not forms or tgt.lower() in GENERIC_WORDS:
                        bad += 1            # bozuk kayıt ('黄昏 -> 黄昏', 'Mum', 'スパイ -> casus' gibi)
                        continue
                    if g.target_lang.startswith("tr") and english_institution(tgt, str(t.get("type", ""))):
                        bad += 1            # Japonca kaynaktan "監査局 -> Audit Bureau" gibi İngilizce kalmış kurum adı
                        continue
                    forms = list(dict.fromkeys(x for f in forms for x in expand_forms(f)))
                    g.terms.append({"target": tgt, "type": t.get("type", "term"), "forms": forms})
            g.removed_on_load = bad
            g.keep_lines = [str(x) for x in data.get("keep_verbatim", []) if str(x).strip()]
            english = [x for x in g.keep_lines if looks_english(norm_line(x))]
            if english:      # eski sürümün "Elfçe" sandığı İngilizce satırlar (şarkı sözü vb.) çevrilsin
                g.keep_lines = [x for x in g.keep_lines if x not in english]
                g.removed_keep = english
            g.keep_tr = {str(k): str(v) for k, v in (data.get("keep_verbatim_translations") or {}).items()
                         if str(k).strip() and str(v).strip()}   # boş kalanlar yeniden sorulur
            if bad or "keep_verbatim" not in data:
                # bölümler yeniden taransın: eksik terimler ve Elfçe satırlar doğru eklensin
                g.processed_files = []
            g.existed = True
        return g

    @staticmethod
    def term_order(t: dict) -> tuple:
        return (t.get("type", ""), t["target"].lower(), t["target"])

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Bellekteki sıra da dosyadaki gibi olsun: istek metni (ve önbellek anahtarı) sonraki çalışmada aynı kalır
        self.terms.sort(key=self.term_order)
        data = {
            "series": self.series,
            "target_language": self.target_lang,
            "updated": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "info": ("Elle düzenleyebilirsin. 'target' çeviride kullanılacak yazımdır, 'forms' kaynak "
                     "altyazıdaki yazımlarıdır. Var olan terimler otomatik olarak asla değiştirilmez. "
                     "Bir terimin bir daha hiç önerilmemesini istiyorsan kaynak ya da hedef yazımını "
                     "'blocked_terms' listesine yaz (yalnızca silersen sonraki bölümde yeniden önerilir)."),
            "processed_files": self.processed_files,
            "blocked_terms": self.blocked,
            "keep_verbatim_info": ("Bu satırlar kurgusal dildedir (Elfçe, Kara Lisan...): çeviriye hiç "
                                   "gönderilmez, harfi harfine aynen yazılır. Satır ekleyip silebilirsin."),
            "keep_verbatim": self.keep_lines,
            "keep_verbatim_translations_info": ("Elfçe satırın altında parantez içinde gösterilecek Türkçesi. "
                                                "Düzeltebilirsin; silersen yeniden sorulur. Anlamı komşu "
                                                "satırda zaten yazıyorsa script altına eklemez."),
            "keep_verbatim_translations": self.keep_tr,
            "terms": self.terms,
        }
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".tmp_", suffix=".json")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    # ---- eşleştirme

    def _matcher(self, form: str):
        m = self._matchers.get(form)
        if m is None:
            if _is_latin(form):
                # Tek kelimelik isimler büyük/küçük harfe duyarlı ("Strix" eşleşir, "one" eşleşmez)
                flags = re.I if len(form.split()) > 1 else 0
                m = re.compile(r"(?<!\w)" + re.escape(form) + r"(?!\w)", flags)
            elif _KATAKANA_RE.fullmatch(form):
                # ミリー, ファミリー'nin içinde eşleşmesin: önü/arkası katakana olmamalı
                m = re.compile(r"(?<![\u30A0-\u30FFー])" + re.escape(form) + r"(?![\u30A0-\u30FFー])")
            else:
                m = re.compile(re.escape(form))
            self._matchers[form] = m
        return m

    def prune_keep(self, vocab: set[str]) -> list[str]:
        """Kurgusal dil listesindeki aslında İngilizce olan satırları çıkarır (dosyanın İngilizce
        sözcükleriyle bakılır). Dönüş: çıkarılan satırlar."""
        bad = [x for x in self.keep_lines if looks_english_ctx(norm_line(x), vocab) or looks_romaji(x)]
        if bad:
            self.keep_lines = [x for x in self.keep_lines if x not in bad]
            for x in bad:
                self.keep_tr.pop(x, None)
        return bad

    def keep_keys(self) -> set[str]:
        return {k for k in (norm_line(x) for x in self.keep_lines) if k}

    def add_keep(self, lines: list[str]) -> int:
        keys = {conlang_key(x) for x in self.keep_lines}
        added = 0
        for ln in lines:
            k = conlang_key(ln)
            if k and k not in keys and len(k) >= 3:
                self.keep_lines.append(ln.strip())
                keys.add(k)
                added += 1
        return added

    def conlang_translation(self, line: str) -> str | None:
        """Önce birebir anahtar ("..." farkı dahil), yoksa noktalamasız eşleşme."""
        key, loose = conlang_key(line), norm_line(line)
        fallback = None
        for k, v in self.keep_tr.items():
            if conlang_key(k) == key:
                return v
            if fallback is None and norm_line(k) == loose:
                fallback = v
        return fallback

    def missing_translations(self) -> list[str]:
        have = {conlang_key(k) for k in self.keep_tr}
        return [ln for ln in self.keep_lines if conlang_key(ln) not in have]

    def count_in(self, term: dict, text: str) -> int:
        """Terimin kaynak yazımları metinde kaç kez geçiyor?"""
        return sum(len(self._matcher(f).findall(text)) for f in term["forms"])

    def relevant_terms(self, text: str) -> list[dict]:
        """Metinde geçen terimlerin kendisi (tür bilgisiyle)."""
        return [t for t in self.terms if any(self._matcher(f).search(text) for f in t["forms"])]

    def relevant(self, text: str, limit: int = 120) -> dict[str, str]:
        """Metinde geçen kaynak yazımları -> hedef yazım (parçaya eklenecek kısım)."""
        out: dict[str, str] = {}
        for t in self.terms:
            for f in t["forms"]:
                if f not in out and self._matcher(f).search(text):
                    out[f] = t["target"]
            if len(out) >= limit:
                break
        return out

    def entries_in(self, text: str) -> list[dict]:
        """Bu metinde geçen terimler (çıkarma isteğine 'sabit' olarak gönderilir)."""
        res = []
        for t in self.terms:
            if any(self._matcher(f).search(text) for f in t["forms"]):
                res.append({"target": t["target"], "type": t.get("type", "term"), "forms": t["forms"][:6]})
        return res

    # ---- birleştirme

    def _spelling_twin(self, tgt: str, ttype: str, src_fold: str | None = None) -> dict | None:
        """Aynı adın başka altyazı grubundaki yazımı (Conny/Connie Springer, Zhiganshina/Shiganshina,
        Bertholdt/Bertolt). Temkinli: yanlış birleştirme kalıcıdır (sözlükte hedef hiç değişmez).
        - aynı türden, aynı sözcük sayısında, yalnızca tek sözcüğü farklı, benzerlik ≥ 0,85
        - farklı sözcük en az 5 harf, biri ötekinin başı değil (Daniel/Danielle), ilk harfi aynı ya da
          yalnızca ilk harfi farklı (Hikaru/Kaoru, Eastford/Westford ayrı kalır)
        - var olan yazım bu bölümde de geçiyorsa ikisi ayrı kişidir (Anna ve Anne Smith aynı bölümde)"""
        import difflib
        low = _fold_marks(tgt).lower()
        words = low.split()
        if len(low) < 6:
            return None
        for t in self.terms:
            if t.get("type") != ttype:
                continue
            other = _fold_marks(t["target"]).lower()
            ow = other.split()
            if len(ow) != len(words):
                continue
            diff = [(a, b) for a, b in zip(words, ow) if a != b]
            if len(diff) != 1:
                continue
            a, b = diff[0]
            if min(len(a), len(b)) < 5 or a.startswith(b) or b.startswith(a):
                continue
            if a[0] != b[0] and a[1:] != b[1:]:
                continue
            if difflib.SequenceMatcher(None, low, other).ratio() < 0.85:
                continue
            if src_fold is not None and any(_appears_in(f, src_fold) for f in t["forms"]):
                continue
            return t
        return None

    def merge(self, proposed: list[dict], source_text: str | None = None) -> tuple[int, list[str]]:
        """Modelin önerdiği terimleri ekler. Var olan terimin hedefi asla değişmez.
        source_text: bölümün kaynak metni; Latin harfli bir terim bu metinde hiç geçmiyorsa alınmaz
        (model sistem istemindeki örnek adları, ör. "Westalis", bölümde varmış gibi önerebiliyor).
        Dönüş: (eklenen terim sayısı, çakışma notları)."""
        added, notes = 0, []
        src_fold = _fold_marks(source_text) if source_text is not None else None
        by_form = {f.lower(): t for t in self.terms for f in t["forms"]}
        by_target = {t["target"].lower(): t for t in self.terms}
        blocked = {x.lower() for x in self.blocked}
        series_words = slugify(self.series).split("-")
        for p in proposed:
            src = _HONORIFIC_TAIL.sub("", str(p.get("source", "")).strip())
            tgt = _HONORIFIC_TAIL.sub("", str(p.get("target", "")).strip())
            if not src or not tgt or len(src) > 60 or len(tgt) > 60:
                continue
            if src.lower() in blocked or tgt.lower() in blocked:
                continue
            if self.target_lang.startswith("tr"):
                tgt = fix_tr_apostrophes(tgt)           # "Proudfoot’lar" -> "Proudfootlar"
            if _honorific(src):
                continue                                # hitap eki: çeviride aynen kalır, terim değildir
            if src_fold is not None and _is_latin(src) and not _appears_in(src, src_fold):
                notes.append(f"'{src}' bu bölümde hiç geçmiyor, sözlüğe alınmadı")
                continue
            if src.lower() in NEVER_TERMS or (
                    (src.lower() in GENERIC_WORDS or tgt.lower() in GENERIC_WORDS) and src.lower() not in series_words):
                # Seri adındaki genel kelime bir addır ("Doctor Who" dizisinde "Doctor")
                notes.append(f"'{src}' genel bir kelime, sözlüğe alınmadı")
                continue
            if _is_latin(src) and src.islower() and tgt.lower() == src:
                tgt = src                               # "dachshund" cins isim: "Dachshund" diye büyütme
            if self.target_lang.startswith("tr") and english_institution(tgt, str(p.get("type", "")).lower()):
                notes.append(f"'{src}' için '{tgt}' önerildi: İngilizce kalmış, alınmadı (model çeviride Türkçesini yazar)")
                continue
            if not self.valid_target(tgt):
                notes.append(f"'{src}' için '{tgt}' önerildi: hedef dilin alfabesinde değil, alınmadı")
                continue
            existing = by_form.get(src.lower())
            if existing is not None:
                if existing["target"].lower() != tgt.lower():
                    notes.append(f"'{src}' için '{tgt}' önerildi, sözlükteki '{existing['target']}' korundu")
                continue
            same = by_target.get(tgt.lower())
            if same is not None:                       # aynı terimin yeni bir kaynak yazımı
                for f in expand_forms(src):
                    if f.lower() not in by_form:
                        same["forms"].append(f)
                        by_form[f.lower()] = same
                continue
            ttype = str(p.get("type", "term")).lower() or "term"
            if ttype in ("character", "place"):
                # Aynı adın başka altyazı grubundaki yazımı (Conny/Connie Springer, Zhiganshina/Shiganshina):
                # yeni terim açılmaz, var olan terime yeni kaynak yazımı olarak eklenir (bölümler arası tutarlılık)
                twin = self._spelling_twin(tgt, ttype, src_fold)
                if twin is not None:
                    for f in expand_forms(src):
                        if f.lower() not in by_form:
                            twin["forms"].append(f)
                            by_form[f.lower()] = twin
                    notes.append(f"'{src}' ('{tgt}') sözlükteki '{twin['target']}' ile aynı ad sayıldı")
                    continue
            if src.lower().rstrip("s") in NATIONALITIES:
                # Gerçek milliyet ırk da terim de değildir: model çeviride doğru yazar ("İtalyan yemekleri");
                # sözlükte "italyan" diye kalırsa her yere küçük harfle zorlanır
                notes.append(f"'{src}' bir milliyet, sözlüğe alınmadı")
                continue
            if ttype == "race" and self.lower_races:
                tgt = tgt.replace("I", "ı").replace("İ", "i").lower()
            t = {"target": tgt, "type": ttype,
                 "forms": [src] if src == tgt else [src, tgt] if _is_latin(tgt) and not _is_latin(src) else [src]}
            t["forms"] = list(dict.fromkeys(x for f in t["forms"] for x in expand_forms(f)
                                            if x.lower() not in by_form or x == f))
            self.terms.append(t)
            for f in t["forms"]:
                by_form[f.lower()] = t
            by_target[tgt.lower()] = t
            added += 1
        self._matchers.clear()
        return added, notes


# ---------------------------------------------------------------- çıkarma isteği

def extract_payload(series: str, fixed: list[dict], lines: list[tuple[str, str]],
                    max_chars: int = 60000) -> str:
    """lines: (referans, metin) çiftleri, örn. ("12.1", "Anya: Waku waku!")."""
    seen, out, size = set(), [], 0
    for ref, text in lines:
        k = text.strip()
        if not k or k in seen:
            continue
        seen.add(k)
        row = f"{ref} {k}"
        size += len(row) + 1
        if size > max_chars:
            break
        out.append(row)
    payload: dict = {}
    if fixed:
        payload["fixed_glossary"] = fixed
    payload["subtitle_text"] = "\n".join(out)
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def parse_analysis(data: dict) -> dict:
    """Bölüm analizinin terim dışı kısımları: {"meanings": {ref: anlam}, "scenes": [...], "address": [...]}."""
    out: dict = {"meanings": {}, "scenes": [], "address": []}
    if not isinstance(data, dict):
        return out
    for it in data.get("keep_meanings") or []:
        if isinstance(it, dict) and str(it.get("id", "")).strip() and str(it.get("meaning", "")).strip():
            out["meanings"][str(it["id"]).strip()] = str(it["meaning"]).strip()
    for it in data.get("scenes") or []:
        try:
            a, b = int(it.get("from_id")), int(it.get("to_id"))
        except (TypeError, ValueError, AttributeError):
            continue
        summ = str(it.get("summary", "")).strip()
        if summ and 0 < a <= b:
            out["scenes"].append({"from": a, "to": b, "summary": summ[:300]})
    for it in data.get("address") or []:
        if not isinstance(it, dict):
            continue
        sp, li, form = (str(it.get(k, "")).strip() for k in ("speaker", "listener", "form"))
        if sp and li and form in ("informal", "formal") and sp.casefold() != li.casefold():
            out["address"].append({"speaker": sp[:40], "listener": li[:40], "form": form,
                                   "note": str(it.get("note", "")).strip()[:80]})
    out["address"] = out["address"][:25]
    return out


def parse_terms(data: dict) -> tuple[list[dict], list[str]]:
    items = data.get("terms") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise ValueError("yanıtta 'terms' listesi yok")
    keep = data.get("keep_ids") or []
    keep = [str(x).strip() for x in keep if str(x).strip()] if isinstance(keep, list) else []
    return [it for it in items if isinstance(it, dict)], keep


# ---------------------------------------------------------------- kurgusal dil satırlarının anlamı

CONLANG_SCHEMA = {
    "type": "object",
    "properties": {
        "items": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"i": {"type": "integer"}, "translation": {"type": "string"},
                               "is_constructed_language": {"type": "boolean"}},
                "required": ["i", "translation", "is_constructed_language"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["items"],
    "additionalProperties": False,
}

def conlang_payload(lines: list[str], contexts: list[tuple[list[str], list[str]]],
                    hints: list[str] | None = None, glossary: dict[str, str] | None = None) -> str:
    items = []
    hints = hints or [""] * len(lines)
    for i, (ln, (before, after), hint) in enumerate(zip(lines, contexts, hints), 1):
        d: dict = {"i": i, "line": ln}
        if hint:
            d["given_meaning"] = hint
        if before:
            d["before"] = before
        if after:
            d["after"] = after
        items.append(d)
    payload: dict = {"glossary": glossary} if glossary else {}
    payload["lines"] = items
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


_CONLANG_WORD_RE = re.compile(r"[^\W\d_]+")


def conlang_candidate(line: str, terms_lower: set[str]) -> bool:
    """Model çeviride hiç dokunmadan bıraktıysa kurgusal dil olabilecek bir satır mı?
    ("Tangado haid!", "Leithio i philinn!" evet; "Frodo Baggins", "Ha ha ha", İngilizce satır hayır)."""
    raw = line.strip()
    if not raw or raw[0] in "[(（【" or PLACEHOLDER_RE.search(raw):
        return False
    key = norm_line(raw)
    words = _CONLANG_WORD_RE.findall(key)
    if len(words) < 2 or not any(len(w) >= 4 for w in words):
        return False
    if not all(re.fullmatch(r"[A-Za-zÀ-ɏ]+", w) for w in words):   # Latin harfli olmalı
        return False
    plain = TAG_RE.sub("", raw)
    if not any(w[:1].islower() for w in _CONLANG_WORD_RE.findall(plain)):
        return False                                     # hepsi büyük harfle başlıyor: isim
    if looks_english(key) or key in terms_lower or any(w in EN_EXTRA for w in words):
        return False
    tokens = [t.strip(".,!?;:\"“”()…-") for t in plain.lower().split()]
    if any(_EN_MORPH_RE.fullmatch(t) for t in tokens if t):
        return False                                     # He's, Bilbo's, fading, lately, information
    return True


# İngilizce biçimbirim: kısaltma ekleri ve sık sonekler (Sindarin/Quenya'da bu biçimde geçmez)
_EN_MORPH_RE = re.compile(r"[a-z]+'(?:s|re|ll|ve|d|t|m)|[a-z]{3,}(?:ing|tion|sion|ness|ment|ly)")


# Sonradan Elfçe taramasında İngilizce satırı elemek için ek sözcükler (Sindarin/Quenya ile
# çakışanlar bilerek yok: i, a, in, an, man, ring, lin, nin, nor, dor, tol, mae, ion ...)
EN_EXTRA = set("""
the to of for with without on off over under up out yes yeah okay now then there their they them
this that these those what when where which who whom whose why will would shall should was were
your yours yourself myself himself herself ourselves themselves you our ours its it's not no
very much many some something nothing anything one two three first last only also too still
just even ever never always again good bad great little small big old new young long short
time day night year world life death way thing things people man's men woman women child children
master secret ring's rings lord king queen friend friends home house land road water fire earth air
come came go went gone take took give gave make made see saw seen know knew think thought say said
tell told find found keep kept leave left help look looking want wanted need needed feel felt smell
hold hear heard speak spoke call called run ran fly flee stay stop wait follow fight kill die
dead alive back away down here gone please thank thanks sorry hello hey well right wrong true false
across sea sky star stars light dark heart love song sing night
welcome already afternoon morning evening dinner supper breakfast lunch tea needs enough foul bye
yesterday tomorrow today between school event grand fellow ask asked against during huh like likes looks
power grows yourselves amongst among creature odd strange quickly quiet everyone nobody somebody
""".split())
