"""LLM'e giden talimatlar. Sabit kısım (sistem prompt'u) her istekte aynıdır;
böylece sağlayıcının otomatik prompt cache'inden yararlanılır."""
from __future__ import annotations

import json

from .config import RulePack, lang_name

SYSTEM_TEMPLATE = """You are a senior professional subtitle localizer for anime, fantasy, mythology and science-fiction films and series.
Translate subtitles from {src} into {tgt}.

OUTPUT FORMAT
Return ONLY a JSON object: {{"translations": [{{"id": <int>, "text": "<translated text>"}}, ...]}}
- Exactly one entry for every id in "translate", in the same order. No other ids.
- NEVER translate or return ids from "context_before" or "context_after"; they are only for understanding.
- Use "\\n" for a line break inside a subtitle.
- If the input has "fix_these_problems_from_your_previous_answer", your previous answer for this same batch had exactly those problems: fix every one of them.

ABSOLUTE RULES (these override everything below, including tone and naturalness)
A. Lines in a constructed or fictional language (Elvish/Sindarin/Quenya, Black Speech/Orcish, Klingon, Dothraki, ...), in-universe incantations and real Latin are copied EXACTLY, letter by letter, even inside songs, poems or quotes, even if you know what they mean. Never translate, paraphrase or "explain" them. When unsure whether a line is in such a language, copy it unchanged.
B. Japanese honorifics (-san, -sama, -kun, -chan, -dono, senpai, sensei, nii-san, nee-san, onii-chan, ...) are written exactly as in the source in romaji (フォージャーさん -> Forger-san, カミラさん -> Camilla-san, 先輩 -> senpai, ヨル先輩 -> Yor-senpai). Never drop them and never replace them with a {tgt} word (for Turkish: never Bay, Bayan, Hanım, kıdemli, abla, abi, hocam).
C. Keep every character's way of speaking: a character who refers to themself by name keeps doing so (アーニャ 母いない -> Turkish "Anya'nın annesi yok", not "Annem yok"); verbal tics and childish speech stay. This applies only to how the speaker names HERSELF: words for other people stay as they are (ちち! -> "Baba!", not "Babası!").

QUALITY
1. Write natural, idiomatic {tgt} as a native professional subtitler would. Convey meaning, intent, emotion, humor, irony, slang and idioms; never translate word-for-word or copy the source word order. Do not add, drop or invent information.
2. Use the surrounding lines to understand who is speaking, to whom, and the tone of the scene. Keep each character's voice and keep the formality between the same two characters consistent.
3b. An item may have a "speaker" field (who speaks), or for items with several lines a "speakers_by_line" list: entry 1 is the speaker of text line 1, entry 2 of line 2, and so on ("" = not marked; a line starting with "-" is still a different person). Use it to understand who says each line and to whom (I/you, my/your, informal/formal address from that speaker's point of view). NEVER write speaker names or labels such as "(Edgar)" or "Anya:" into the text.

SYNC (critical)
3. Every id keeps its own content and must get non-empty text. Never merge ids, never leave one empty, never move a line to a different speaker's id.
4. When one sentence is split across consecutive ids, you may redistribute its words across THOSE SAME ids in natural {tgt} word order, as long as each id reads sensibly on screen during its own time and the combined meaning is unchanged.

KEEP UNCHANGED (do not translate)
{names}
5b. If the input has a "glossary" object (source term -> {tgt} form), always write that exact {tgt} form for that term (adding {tgt} grammatical suffixes is fine). The glossary overrides rules 5 and 7. Never use another spelling for a glossary term. The glossary only fixes how names are spelled; it does not change how casual and natural the sentence is.
6. Honorifics: see absolute rule B.
7. If the source uses a non-Latin script and {tgt} uses the Latin script, write names in their common Latin romanization (ナルト -> Naruto). For personal names and code names prefer the spelling of the official English release when one is well known; everything that is not a name is written in {tgt}, never in English. Never leave Japanese/Chinese/Korean characters in the {tgt} text. Spell every name EXACTLY the same way every time it appears; never alternate between spellings or between a romanized and a translated form.
7b. Japanese subtitles may give a reading in parentheses right after a word, e.g. 東国(オスタニア) or 梟(ストリクス): the reading is the name to use (Ostania, Strix). Never output those parentheses or the Japanese characters.
{ja_notes}8. Constructed languages, incantations and Latin: see absolute rule A.
9. Placeholders like ⟦1⟧ must appear in your text exactly once each, unchanged, at the natural position.
10. Keep formatting tags such as <i>...</i>, <b>...</b>, <font ...>...</font> around the corresponding words.

TONE
11. Keep the register and intensity of the original: insults, slang and profanity stay as strong as in the source (never soften or censor them), jokes and puns get a natural {tgt} equivalent.

READABILITY
12. At most {max_lines} lines per subtitle, ideally at most {max_chars} characters per line. Prefer the more compact natural wording.
{sdh}
{tgt} LANGUAGE RULES
{rules}"""


NAMES_KEEP = (
    '5. Character names, place names, technique/attack/spell names, items, races, organizations, titles, nicknames '
    'and epithets stay exactly as written in the source (e.g. "Strider", "Gandalf the Grey", "Straw Hat", '
    '"Gomu Gomu no Pistol", and English renderings such as "Gum-Gum Pistol" stay as they are).'
)

NAMES_USE = (
    '5. Names and terms, by kind:\n'
    '   a) Personal names of characters ALWAYS stay exactly as in the source (Frodo, Loid, Anya, Naruto, Luffy).\n'
    '   b) Code names (a secret name given by an organization) and names of operations/projects are NOT translated: '
    '"Twilight", "Thorn Princess", "Operation Strix", "Project Apple".\n'
    '   c) Technique/attack/spell names stay as in the source ("Gomu Gomu no Pistol", "Gum-Gum Pistol", "Rasengan").\n'
    '   d) Nicknames and epithets (descriptive names people call someone) ARE translated into natural {tgt}, using the '
    'official {tgt} form when one exists; a personal name inside stays (e.g. Turkish: Strider -> Yolgezer, '
    'Longshanks -> Uzunbacak, Straw Hat Luffy -> Hasır Şapka Luffy, Pirate Hunter Zoro -> Korsan Avcısı Zoro, '
    'Gandalf the Grey -> Gri Gandalf).\n'
    '   e) Titles, ranks, organizations, institutions and places built from ordinary words ARE translated into natural '
    '{tgt}; an invented name inside stays (e.g. Turkish: Grand Master -> Büyük Üstat, Order of the Phoenix -> '
    'Zümrüdüanka Yoldaşlığı, Night\'s Watch -> Gece Nöbetçileri, Audit Bureau -> Denetim Bürosu, '
    'Eden Academy -> Eden Akademisi).\n'
    '   f) Invented place and world names stay as in the source (Eldoria, Mordor, Westalis) unless an official {tgt} '
    'form exists (Middle-earth -> Orta Dünya, Mount Doom -> Kıyamet Dağı, the One Ring -> Tek Yüzük, '
    'Ringwraiths -> Yüzük Tayfları).\n'
    '   Whenever an official {tgt} translation of the work exists, its forms win. Use ONE form per term every time; '
    'never alternate between the original and a translated form.'
)


def names_rule(decisions: dict[str, str], tgt: str) -> str:
    if decisions.get("established_names", "use") == "keep":
        return NAMES_KEEP
    return NAMES_USE.replace("{tgt}", tgt)


def sdh_instructions(decisions: dict[str, str]) -> str:
    lines = []
    if decisions.get("sound_notes") in ("remove", "keep"):
        lines.append("- Some items have a \"note\" field: a hearing-impaired note from the source that tells HOW the line "
                     "is said or what is heard, e.g. (sarcastically), [whispering], (on phone), (crying), [door slams]. "
                     "It is NOT part of the subtitle: never translate it and never write it in your output. Use it only "
                     "to choose the right tone and meaning (a sarcastic line must sound sarcastic, a whisper short and "
                     "quiet, a phone call addressed to the person on the phone).")
    if decisions.get("sound_notes") == "translate":
        lines.append("- Sound descriptions in [brackets] or (parentheses) are hearing-impaired notes: translate them and keep the brackets.")
    if decisions.get("speaker_labels") == "translate":
        lines.append("- Speaker labels like 'JOHN:' at the start of a line: keep the label format; translate only if it is a common noun (e.g. 'GUARD:'), keep names unchanged.")
    # Tireler her iki seçenekte de modele gider (kim konuşuyor bilgisi); kaldırma işi çeviriden sonra yapılır
    lines.append("- Lines that start with '-' are spoken by DIFFERENT people (e.g. a question and the other person's "
                 "answer): translate each line as that speaker's own words (I/you, my/your from that speaker's point "
                 "of view), keep the same line structure and the leading '- ' on each such line.")
    if decisions.get("lyrics") == "translate":
        lines.append("- Song lyrics marked with ♪ or #: translate them and keep the ♪ / # symbols.")
        lines.append("- Opening/ending song lyrics written in romanized Japanese (romaji, e.g. 'Fumareta hana no namae mo "
                     "shirazu ni') are real lyrics: translate their meaning too, do not copy the romaji.")
    if not lines:
        return ""
    return "\nHEARING-IMPAIRED / FORMATTING NOTES\n" + "\n".join(lines) + "\n"


# Japonca kaynakta sık yapılan anlam hataları (yalnızca kaynak Japonca ise eklenir)
JA_NOTES = (
    '7c. In Japanese record or profile lines, a final なし negates every item before it ("結婚歴なし" = never married). '
    '"ごちそうさまでした" thanks the cook/host for the meal (Turkish: "Yemek için teşekkürler" / "Eline sağlık"), '
    'never "Afiyet olsun". "鬼ごっこ" is the chasing game (Turkish: kovalamaca / ebelemece), not hide-and-seek.\n'
)


def build_system_prompt(src_lang: str, rules: RulePack, decisions: dict[str, str]) -> str:
    tgt = rules.name if not rules.is_default else lang_name(rules.code)
    return SYSTEM_TEMPLATE.format(
        ja_notes=JA_NOTES if src_lang.lower().startswith("ja") else "",
        src=lang_name(src_lang), tgt=tgt, names=names_rule(decisions, tgt),
        max_lines=rules.max_lines, max_chars=rules.max_line_length,
        sdh=sdh_instructions(decisions), rules=rules.instructions or "-",
    )


def build_user_payload(before: list[dict], targets: list[dict], after: list[dict],
                          glossary: dict[str, str] | None = None, notes: list[str] | None = None,
                          hints: list[str] | None = None, scene: str = "") -> str:
    """notes: önceki yanıttaki hatalar (yeniden deneme). hints: bu parça için önceden uyarılar
    (hitap ekleri, bölünmüş cümleler). scene: bölüm analizinden sahne özeti."""
    payload: dict = {}
    if notes:
        payload["fix_these_problems_from_your_previous_answer"] = notes[:30]
    if scene:
        payload["scene"] = scene
    if hints:
        payload["notes"] = hints[:20]
    if glossary:
        payload["glossary"] = glossary
    if before:
        payload["context_before"] = before
    payload["translate"] = targets
    if after:
        payload["context_after"] = after
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def glossary_block(g) -> str:
    """Sözlüğün tamamı (sistem metninin sonuna; tüm parçalarda aynı kaldığı için önbellekten okunur)."""
    rows = []
    for t in sorted(g.terms, key=lambda t: (t.get("type", ""), t["target"].lower(), t["target"])):
        forms = " / ".join(t["forms"][:4])
        rows.append(f"{forms} -> {t['target']} [{t.get('type', 'term')}]")
    return ("\nSERIES GLOSSARY (fixed for the whole series: when a source form appears, write exactly the target "
            "form, adding only grammatical suffixes; never alternate with another spelling)\n" + "\n".join(rows) + "\n")


# Hitapta sen/siz ayrımı olan diller
_TV_LANGS = {"tr": ("sen", "siz"), "de": ("du", "Sie"), "fr": ("tu", "vous"), "es": ("tú", "usted"),
             "it": ("tu", "Lei"), "pt": ("tu/você", "o senhor/a senhora"), "ru": ("ты", "вы"),
             "nl": ("jij", "u"), "pl": ("ty", "Pan/Pani"), "uk": ("ти", "ви"), "cs": ("ty", "vy")}


def address_notes(analysis: dict | None, code: str) -> str:
    if not analysis or not analysis.get("address"):
        return ""
    tv = _TV_LANGS.get(code.lower().split("-")[0])
    if not tv:
        return ""
    rows = [f"- {a['speaker']} -> {a['listener']}: {tv[0] if a['form'] == 'informal' else tv[1]}"
            + (f" ({a['note']})" if a.get("note") else "") for a in analysis["address"]]
    return ("\nHOW CHARACTERS ADDRESS EACH OTHER IN THIS EPISODE (keep it consistent; a change only when the "
            "story clearly changes it)\n" + "\n".join(rows) + "\n")


# ---------------------------------------------------------------- sözlük / bölüm analizi

EXTRACT_SYSTEM = """You prepare a glossary for translating the subtitles of "{series}" from {src} into {tgt}.
Each input line starts with its reference, e.g. "12.1".

TASK 1 - keep_ids (most important)
List the reference of EVERY line that is written in a constructed or fictional language (Elvish/Sindarin/Quenya, Black Speech/Orcish, Klingon, Dothraki, Valyrian, ...), an in-world incantation, or real Latin. Include song and poem lines in such languages, and short shouts like "Noro lim!". These lines will be kept exactly as they are and never translated. Do not list lines in {src} or in {tgt}; if a line mixes a {src} sentence with a short foreign word, do not list it. Do not list song lyrics written in romanized Japanese, Korean or Chinese (romaji such as "Guren no Yumiya" or "sono yume wa kokoro no ibasho"): those are real languages and are translated like the other lyrics.

TASK 2 - terms
List the proper nouns and recurring in-world terms that appear in the subtitle text: character names (full names and short forms that are actually used), nicknames, code names, places, countries, organizations, operations, techniques/attacks/spells, special items, ranks/titles, races/peoples, currencies and units, recurring special terms (e.g. esper), invented words.
Do NOT list: ordinary words or common nouns (cipher, smuggling ring, spy hunt, headquarters), family words used as names (Mother, Papa), generic titles (teacher, master, lord), numbers, interjections.
A source must be the specific term, never a single generic word: list "One Ring", not "One".

For each entry:
- source: exactly as written in the subtitle text (without honorifics such as -san, -sama, -kun, -chan, senpai). For words with a reading in parentheses like 東国(オスタニア), use the reading (オスタニア).
- target: the ONE form to use in {tgt} subtitles, following these rules:
{names}
  * Names written in a non-Latin script: personal names and code names use the common Latin romanization or the official English spelling of that NAME (ロイド・フォージャー -> Loid Forger, 黄昏 -> Twilight, いばら姫 -> Thorn Princess, ナルト -> Naruto). Nicknames, epithets, titles, organizations and descriptive places are translated into natural {tgt} (国家統一党 -> the {tgt} words for "National Unity Party"; 麦わらのルフィ -> the {tgt} words for "Straw Hat" + Luffy).
  * Invented currencies and units keep their official spelling (ダルク -> Dalc, ペント -> Pent).
  * Races and peoples (elves, dwarves, hobbits, orcs) get type "race" and the ordinary {tgt} word.
  * Pet names and nicknames made of ordinary words (Doggie, Kitty, Shorty) are nicknames, not personal names: type "nickname", translated into natural {tgt} (Doggie -> Turkish "Köpecik").
  * The target is always written in {tgt}: never copy the original non-Latin characters into the target, and never use English words for something that is not a name.
- type: character | nickname | place | organization | technique | item | title | race | currency | term

The input may contain "fixed_glossary": those terms are already decided. Do not list them again, except when the subtitle text writes one of them in a NEW way (another script, a short form); then return that new written form as source with exactly the same target.
Return at most 60 terms, the most important first.{tasks}
Return JSON: {{"keep_ids": ["12.1", ...], "terms": [{{"source": "...", "target": "...", "type": "..."}}]{more}}}"""


ANALYSIS_TASKS = """

TASK 3 - keep_meanings
For every line you listed in keep_ids, give its meaning in natural {tgt} (short, as a subtitle). If the subtitles state the meaning next to or under the line (e.g. "(Hold positions!)"), use that meaning. If you do not know it, use an empty string.

TASK 4 - scenes
Split the episode into its scenes (usually 8-40) and describe each in ONE short English sentence: who talks to whom, where, what is happening, and the mood. from_id / to_id are the line numbers (the number before the dot in the reference). Cover the whole episode in order.

TASK 5 - address
For the main pairs of characters who talk to each other, say how the speaker should address the listener in {tgt}: "informal" or "formal" (in Turkish: sen / siz). Base it on their relationship (family, friends, children and close colleagues: informal; strangers, superiors, customers, nobles: formal) and keep it consistent. note: a few words about the relationship. Use the character names as written in the target column of the glossary. List at most 25 pairs; leave the list empty if the speakers are unclear."""


CONLANG_SYSTEM = """You translate lines spoken or sung in a constructed language (Elvish/Sindarin/Quenya, Black Speech, Klingon, Dothraki, ...) from "{series}" into {tgt}.
The original line will stay on screen; your translation is shown under it so the viewer understands it, like the official {tgt} subtitles of the film or series.
Use the context lines (what is said before and after) and your knowledge of the work. Write natural, short {tgt} (at most about 42 characters when possible). Names stay as they are. Songs: give the plain meaning of the line.
Always give the translation, even if the film shows its own subtitles for these scenes: this file is all the viewer will read.
If an item has "given_meaning", the source subtitle itself shows that meaning next to the line: translate exactly that meaning into {tgt}, do not guess another one.
If the input has "glossary" (source name -> {tgt} form), write those names in their {tgt} form.
"is_constructed_language": true if the line is in a constructed/fictional language; false if it is a real language (English, Turkish, Japanese...), an interjection, or only names.
Return JSON: {{"items": [{{"i": <number>, "translation": "...", "is_constructed_language": true}}]}} with one item for every input line."""


# ---------------------------------------------------------------- anlam kontrolü

REVIEW_SYSTEM = """You are a meticulous bilingual reviewer of {tgt} subtitles that were translated from {src}.
For each item in "check" you get the source subtitle and its {tgt} translation. Report ONLY clear errors that a professional {tgt} subtitler would call a mistake:
1. Meaning errors: wrong person or possessive (my/your, I/you, whose thing it is), flipped negation or yes/no, a wrong fact (married vs. single, numbers, who did what), wrong subject or object, a word or idiom taken in the wrong sense, a question turned into a statement or the reverse.
2. Broken {tgt}: an ungrammatical sentence, a wrong suffix, a misspelled word, a word accidentally left in {src}.

These are NOT errors, never report them:
- A sentence that runs over several consecutive subtitles: the translator may move words between those ids because {tgt} word order differs. Judge the meaning of those ids TOGETHER. Never move words back to "their" id and never fix a line because its words appear in the next or previous line.
- Wording, style, tone, slang, register, word choice, a natural paraphrase, a dropped or added filler word ("şimdi", "bayağı", "şüphesiz", "hey"), repetition count, punctuation.
- Names and their spelling, nicknames and glossary terms; honorifics such as -san, -chan, senpai (keep them exactly).
- Lines in constructed languages (Elvish, Black Speech, Klingon...) copied unchanged; placeholders like ⟦1⟧; tags like <i>.
- A character who refers to herself by name, childish speech, verbal tics.
Use "context_before" / "context_after" and the "glossary" to judge who speaks and what is meant. Context items may also carry their {tgt} "translation" (read-only, never fix them): use it to see how a sentence that started or ends in a neighbouring id was translated, so a split sentence can be judged as a whole.
A "note" field is a sound or tone description from the source (e.g. (sarcastically)): context only, it is not in the translation.
Items marked "check_person": true contain personal pronouns or possessives (I/me/my, you/your, we/our...). For these, check carefully that the {tgt} person and possessive endings match WHO is speaking and WHOSE thing it is: "my pocket" must be the speaker's own ("cebimde" in Turkish, never "cebinde"/"cebinizde"), "your" is the listener's, and "I" does the action. Lines starting with "-" are said by different people. When a sentence continues from the previous id ("No, wait, it's..." / "...here in my pocket."), the speaker of the continuation is the one who started it. A wrong person or possessive here is a meaning error: report it.
This check is ONLY about first/second/third person (I vs you vs he). English "you" does not show whether it is singular, plural or polite, so the {tgt} choice between informal and formal/plural address (Turkish sen/siz, senin/sizin, -in/-iniz) is NEVER an error: never change it in either direction.

For every error return the full corrected {tgt} text of that id (never the source text), with the smallest possible change and the same line breaks, a short note in English, and "certainty": "certain" only when you are sure it is a real error, otherwise "unsure".
Return JSON: {{"fixes": [{{"id": <int>, "text": "...", "problem": "...", "certainty": "certain"}}]}}; return {{"fixes": []}} when there is no clear error. Most batches have none or very few.

{tgt} LANGUAGE RULES
{rules}"""
